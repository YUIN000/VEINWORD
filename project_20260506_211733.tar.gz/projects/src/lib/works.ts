import { createClient } from '@/storage/database/supabase-client'

/**
 * 获取作品的点赞数、收藏数、浏览数
 */
export async function getWorkStats(workId: string) {
  const supabase = createClient()
  
  // 获取作品基本信息
  const { data: work, error: workError } = await supabase
    .from('works')
    .select('like_count, favorite_count, play_count')
    .eq('id', workId)
    .single()
  
  if (workError) {
    throw new Error(`获取作品统计失败: ${workError.message}`)
  }
  
  return {
    likeCount: work.like_count || 0,
    favoriteCount: work.favorite_count || 0,
    playCount: work.play_count || 0
  }
}

/**
 * 更新作品统计
 */
export async function updateWorkStats(workId: string, stats: {
  likeCount?: number
  favoriteCount?: number
  playCount?: number
}) {
  const supabase = createClient()
  
  const updates: Record<string, number> = {}
  
  if (stats.likeCount !== undefined) {
    updates.like_count = stats.likeCount
  }
  if (stats.favoriteCount !== undefined) {
    updates.favorite_count = stats.favoriteCount
  }
  if (stats.playCount !== undefined) {
    updates.play_count = stats.playCount
  }
  
  const { error } = await supabase
    .from('works')
    .update(updates)
    .eq('id', workId)
  
  if (error) {
    throw new Error(`更新作品统计失败: ${error.message}`)
  }
  
  return { success: true }
}

/**
 * 增加浏览数
 */
export async function incrementPlayCount(workId: string) {
  const supabase = createClient()
  
  const { data: work, error: fetchError } = await supabase
    .from('works')
    .select('play_count')
    .eq('id', workId)
    .single()
  
  if (fetchError) {
    throw new Error(`获取作品失败: ${fetchError.message}`)
  }
  
  const newCount = (work?.play_count || 0) + 1
  
  const { error } = await supabase
    .from('works')
    .update({ play_count: newCount })
    .eq('id', workId)
  
  if (error) {
    throw new Error(`更新浏览数失败: ${error.message}`)
  }
  
  return { success: true, playCount: newCount }
}
