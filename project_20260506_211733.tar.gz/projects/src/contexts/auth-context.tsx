'use client'

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { createClient } from '@/storage/database/supabase-client-browser'

interface User {
  id: string
  username: string
  email: string
  avatar_url?: string
  bio?: string
  created_at: string
}

interface AuthContextType {
  user: User | null
  profile: User | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string, username: string) => Promise<void>
  signOut: () => Promise<void>
  updateProfile: (data: Partial<User>) => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Generate a valid UUID v4
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

// Check if a string is a valid UUID
function isValidUUID(str: string): boolean {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  return uuidRegex.test(str)
}

// Demo user for preview
const DEMO_USER: User = {
  id: generateUUID(),
  username: '墨痕',
  email: 'demo@wenhen.com',
  avatar_url: undefined,
  bio: '文字落下的痕迹，是心灵的印记。',
  created_at: new Date().toISOString(),
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for stored user (demo mode)
    const storedUser = localStorage.getItem('wenhen_user')
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser)
      // Check if user has valid UUID
      if (!parsedUser.id || !isValidUUID(parsedUser.id)) {
        parsedUser.id = generateUUID()
        localStorage.setItem('wenhen_user', JSON.stringify(parsedUser))
      }
      setUser(parsedUser)
    }
    setIsLoading(false)
  }, [])

  const refreshProfile = async () => {
    // In demo mode, just reload from localStorage
    const storedUser = localStorage.getItem('wenhen_user')
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
  }

  const signIn = async (email: string, _password: string) => {
    setIsLoading(true)
    try {
      // Check if user is registered
      const registeredUsers = JSON.parse(localStorage.getItem('wenhen_registered_users') || '[]')
      const foundUser = registeredUsers.find((u: User) => u.email === email)
      
      if (foundUser) {
        // Check if user has valid UUID, if not generate one
        if (!foundUser.id || !isValidUUID(foundUser.id)) {
          foundUser.id = generateUUID()
          // Update in registered users list
          const idx = registeredUsers.findIndex((u: User) => u.email === email)
          if (idx !== -1) {
            registeredUsers[idx] = foundUser
            localStorage.setItem('wenhen_registered_users', JSON.stringify(registeredUsers))
          }
          // Ensure profile exists in Supabase
          try {
            const supabase = createClient()
            await supabase.from('profiles').upsert({
              id: foundUser.id,
              username: foundUser.username,
              email: foundUser.email,
              bio: foundUser.bio || '',
              created_at: foundUser.created_at,
            })
          } catch (e) {
            console.warn('Could not create profile in Supabase:', e)
          }
        }
        setUser(foundUser)
        localStorage.setItem('wenhen_user', JSON.stringify(foundUser))
      } else {
        throw new Error('该邮箱未注册，请先注册')
      }
    } finally {
      setIsLoading(false)
    }
  }

  const signUp = async (email: string, _password: string, username: string) => {
    setIsLoading(true)
    try {
      // Check if email already exists
      const registeredUsers = JSON.parse(localStorage.getItem('wenhen_registered_users') || '[]')
      if (registeredUsers.some((u: User) => u.email === email)) {
        throw new Error('该邮箱已被注册')
      }
      
      const newUser: User = {
        id: generateUUID(),
        username,
        email,
        avatar_url: undefined,
        bio: '',
        created_at: new Date().toISOString(),
      }
      
      // Save to registered users list
      registeredUsers.push(newUser)
      localStorage.setItem('wenhen_registered_users', JSON.stringify(registeredUsers))
      
      // Also create profile in Supabase
      try {
        const supabase = createClient()
        await supabase.from('profiles').upsert({
          id: newUser.id,
          username: newUser.username,
          email: newUser.email,
          bio: newUser.bio || '',
          created_at: newUser.created_at,
        })
      } catch (e) {
        // Ignore Supabase errors in demo mode
        console.warn('Could not create profile in Supabase:', e)
      }
      
      // Set as current user
      setUser(newUser)
      localStorage.setItem('wenhen_user', JSON.stringify(newUser))
    } finally {
      setIsLoading(false)
    }
  }

  const signOut = async () => {
    setUser(null)
    localStorage.removeItem('wenhen_user')
  }

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return
    const updatedUser = { ...user, ...data }
    setUser(updatedUser)
    localStorage.setItem('wenhen_user', JSON.stringify(updatedUser))
    
    // Also update in registered_users list
    const registeredUsers = JSON.parse(localStorage.getItem('wenhen_registered_users') || '[]')
    const index = registeredUsers.findIndex((u: User) => u.id === user.id)
    if (index !== -1) {
      registeredUsers[index] = updatedUser
      localStorage.setItem('wenhen_registered_users', JSON.stringify(registeredUsers))
    }
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile: user, // In demo mode, profile equals user
      loading, 
      signIn, 
      signUp, 
      signOut, 
      updateProfile,
      refreshProfile 
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
