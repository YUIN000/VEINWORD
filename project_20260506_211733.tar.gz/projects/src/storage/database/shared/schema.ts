import { pgTable, varchar, text, timestamp, boolean, integer, jsonb, index, uuid, serial } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"

// 健康检查表（系统内置，禁止删除）
export const healthCheck = pgTable("health_check", {
  id: serial().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
})

// 用户资料表
export const profiles = pgTable(
  "profiles",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    username: varchar("username", { length: 50 }).notNull().unique(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    avatar_key: varchar("avatar_key", { length: 500 }),
    bio: text("bio"),
    is_ai_free_pledge: boolean("is_ai_free_pledge").default(true).notNull(),
    total_words: integer("total_words").default(0).notNull(),
    total_works: integer("total_works").default(0).notNull(),
    total_plays: integer("total_plays").default(0).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("profiles_username_idx").on(table.username),
    index("profiles_email_idx").on(table.email),
  ]
)

// 作品表
export const works = pgTable(
  "works",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().references(() => profiles.id),
    title: varchar("title", { length: 200 }).notNull(),
    content: text("content"),
    genre: varchar("genre", { length: 20 }).notNull().default("essay"), // poetry/essay/short_story/novel/letter/script/diary
    tags: text("tags").array(),
    status: varchar("status", { length: 20 }).default("draft").notNull(), // draft/published/private
    is_ai_free: boolean("is_ai_free").default(true).notNull(),
    word_count: integer("word_count").default(0).notNull(),
    play_count: integer("play_count").default(0).notNull(),
    like_count: integer("like_count").default(0).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("works_user_id_idx").on(table.user_id),
    index("works_genre_idx").on(table.genre),
    index("works_status_idx").on(table.status),
    index("works_created_at_idx").on(table.created_at),
  ]
)

// 写作回放记录表
export const writingPlays = pgTable(
  "writing_plays",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    work_id: uuid("work_id").notNull().references(() => works.id, { onDelete: "cascade" }),
    user_id: uuid("user_id").notNull().references(() => profiles.id),
    play_data: jsonb("play_data").notNull(), // 存储回放操作序列
    duration: integer("duration").default(0).notNull(), // 回放时长（秒）
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("writing_plays_work_id_idx").on(table.work_id),
    index("writing_plays_user_id_idx").on(table.user_id),
  ]
)

// 旁注表（创作碎碎念）
export const marginalNotes = pgTable(
  "marginal_notes",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    work_id: uuid("work_id").notNull().references(() => works.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    timestamp: integer("timestamp").notNull().default(0), // 对应创作时间点（毫秒）
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("marginal_notes_work_id_idx").on(table.work_id),
    index("marginal_notes_timestamp_idx").on(table.timestamp),
  ]
)

// 阅读设置表
export const readingSettings = pgTable(
  "reading_settings",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().references(() => profiles.id).unique(),
    font_family: varchar("font_family", { length: 100 }).default("Noto Serif SC").notNull(),
    font_size: integer("font_size").default(18).notNull(),
    line_height: integer("line_height").default(2).notNull(), // 存储为百分比 200 = 2倍
    background_color: varchar("background_color", { length: 20 }).default("paper").notNull(), // paper/night/ink/gray
    updated_at: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("reading_settings_user_id_idx").on(table.user_id),
  ]
)

// 作品收藏表
export const workLikes = pgTable(
  "work_likes",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    work_id: uuid("work_id").notNull().references(() => works.id, { onDelete: "cascade" }),
    user_id: uuid("user_id").notNull().references(() => profiles.id),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("work_likes_work_id_idx").on(table.work_id),
    index("work_likes_user_id_idx").on(table.user_id),
  ]
)

// 回放收藏表
export const playFavorites = pgTable(
  "play_favorites",
  {
    id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
    play_id: uuid("play_id").notNull().references(() => writingPlays.id, { onDelete: "cascade" }),
    user_id: uuid("user_id").notNull().references(() => profiles.id),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("play_favorites_play_id_idx").on(table.play_id),
    index("play_favorites_user_id_idx").on(table.user_id),
  ]
)
