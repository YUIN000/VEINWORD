'use client'

import { createClient as createSupabaseClient, SupabaseClient } from '@supabase/supabase-js'

// Environment check function to detect changes
const getSupabaseConfig = () => {
  return {
    url: process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL || 'https://placeholder.supabase.co',
    key: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.COZE_SUPABASE_ANON_KEY || 'placeholder-anon-key',
  }
}

let supabaseClient: SupabaseClient | null = null
let currentConfig = ''

export function createClient(): SupabaseClient {
  const config = getSupabaseConfig()
  const configKey = `${config.url}:${config.key}`
  
  // Re-create client if config changed
  if (supabaseClient && currentConfig !== configKey) {
    supabaseClient = null
  }
  
  if (supabaseClient) return supabaseClient

  supabaseClient = createSupabaseClient(config.url, config.key)
  currentConfig = configKey
  return supabaseClient
}

// Demo mode utilities
export const isDemoMode = () => {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL
  return !url || url === 'https://placeholder.supabase.co'
}

// Local storage helpers for demo mode
export const localStorage = {
  getUser: () => {
    if (typeof window === 'undefined') return null
    const stored = window.localStorage.getItem('wenhen_user')
    return stored ? JSON.parse(stored) : null
  },
  setUser: (user: Record<string, unknown>) => {
    if (typeof window === 'undefined') return
    window.localStorage.setItem('wenhen_user', JSON.stringify(user))
  },
  removeUser: () => {
    if (typeof window === 'undefined') return
    window.localStorage.removeItem('wenhen_user')
  },
  getWorks: () => {
    if (typeof window === 'undefined') return []
    const stored = window.localStorage.getItem('wenhen_works')
    return stored ? JSON.parse(stored) : []
  },
  setWorks: (works: Record<string, unknown>[]) => {
    if (typeof window === 'undefined') return
    window.localStorage.setItem('wenhen_works', JSON.stringify(works))
  },
  getFavorites: () => {
    if (typeof window === 'undefined') return []
    const stored = window.localStorage.getItem('wenhen_favorites')
    return stored ? JSON.parse(stored) : []
  },
  setFavorites: (favorites: Record<string, unknown>[]) => {
    if (typeof window === 'undefined') return
    window.localStorage.setItem('wenhen_favorites', JSON.stringify(favorites))
  },
  getLikes: () => {
    if (typeof window === 'undefined') return []
    const stored = window.localStorage.getItem('wenhen_likes')
    return stored ? JSON.parse(stored) : []
  },
  setLikes: (likes: Record<string, unknown>[]) => {
    if (typeof window === 'undefined') return
    window.localStorage.setItem('wenhen_likes', JSON.stringify(likes))
  },
}
