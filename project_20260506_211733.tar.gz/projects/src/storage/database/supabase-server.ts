// Server-side Supabase client
export { getSupabaseClient as createClient } from './supabase-client'
