'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { 
  ChevronLeft,
  Star,
  Play,
  Type,
  Settings,
  X,
  StarOff,
  Eye,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useRouter } from 'next/navigation'

// 阅读主题
const readerThemes = [
  { id: 'paper', name: '宣纸白', bg: '#F5F1E8', text: '#2C2416' },
  { id: 'night', name: '月夜蓝', bg: '#1A1D29', text: '#E8E4D9' },
  { id: 'ink', name: '墨染黑', bg: '#0D0D0D', text: '#D4C5A9' },
  { id: 'gray', name: '素雅灰', bg: '#F0EDE8', text: '#333333' },
] as const

type ReaderTheme = typeof readerThemes[number]['id']

// 字体选项
const fontFamilies = [
  { id: 'noto-serif', name: '思源宋体', family: "'Noto Serif SC', 'Songti SC', serif" },
  { id: 'simsun', name: '宋体', family: "'SimSun', 'STSong', serif" },
  { id: 'kaiti', name: '楷体', family: "'KaiTi', 'STKaiti', serif" },
  { id: 'heiti', name: '黑体', family: "'Heiti SC', 'Microsoft YaHei', sans-serif" },
] as const

type FontFamily = typeof fontFamilies[number]['id']

interface ReaderSettings {
  theme: ReaderTheme
  fontSize: number
  fontFamily: FontFamily
}

// localStorage key
const READER_SETTINGS_KEY = 'wenhen_reader_settings'

// 获取保存的阅读设置
function getSavedSettings(): ReaderSettings {
  if (typeof window === 'undefined') {
    return { theme: 'paper', fontSize: 18, fontFamily: 'noto-serif' }
  }
  try {
    const saved = localStorage.getItem(READER_SETTINGS_KEY)
    if (saved) {
      return JSON.parse(saved)
    }
  } catch (e) {
    console.error('Failed to load reader settings:', e)
  }
  return { theme: 'paper', fontSize: 18, fontFamily: 'noto-serif' }
}

// 保存阅读设置
function saveSettings(settings: ReaderSettings) {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(READER_SETTINGS_KEY, JSON.stringify(settings))
  } catch (e) {
    console.error('Failed to save reader settings:', e)
  }
}

interface ReaderContentProps {
  title: string
  author: string
  authorId?: string
  content: string
  genre: string
  createdAt: string
  wordCount: number
  playCount: number
  likeCount: number
  hasPlayback: boolean
  operations?: any[]
  workId?: string
}

export function ReaderContent({
  title,
  author,
  authorId,
  content,
  genre,
  createdAt,
  wordCount,
  playCount,
  likeCount,
  hasPlayback,
  operations,
  workId,
}: ReaderContentProps) {
  const router = useRouter()
  
  // 从localStorage加载设置
  const [settings, setSettings] = useState<ReaderSettings>(getSavedSettings)
  const [showSettings, setShowSettings] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [isFavorited, setIsFavorited] = useState(false)
  const [currentLikeCount, setCurrentLikeCount] = useState(likeCount)
  const [showFavoriteToast, setShowFavoriteToast] = useState(false)
  
  // 阅读进度
  const [readingProgress, setReadingProgress] = useState(0)
  const contentRef = useRef<HTMLDivElement>(null)

  const currentTheme = readerThemes.find(t => t.id === settings.theme) || readerThemes[0]
  const currentFont = fontFamilies.find(f => f.id === settings.fontFamily) || fontFamilies[0]

  // 保存设置到localStorage
  const updateSetting = useCallback(<K extends keyof ReaderSettings>(
    key: K, 
    value: ReaderSettings[K]
  ) => {
    setSettings(prev => {
      const newSettings = { ...prev, [key]: value }
      saveSettings(newSettings)
      return newSettings
    })
  }, [])

  // 设置默认行距（固定为2）
  const lineHeight = 2

  const handleLike = async () => {
    const newLiked = !isLiked
    setIsLiked(newLiked)
    setCurrentLikeCount(prev => newLiked ? prev + 1 : prev - 1)
    
    if (workId) {
      try {
        await fetch('/api/likes', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ workId, liked: newLiked }),
        })
      } catch (error) {
        console.error('Failed to update like:', error)
      }
    }
  }

  const handleFavorite = async () => {
    const newFavorited = !isFavorited
    setIsFavorited(newFavorited)
    setShowFavoriteToast(true)
    setTimeout(() => setShowFavoriteToast(false), 2000)
    
    if (workId) {
      try {
        await fetch('/api/favorites', {
          method: newFavorited ? 'POST' : 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ workId }),
        })
      } catch (error) {
        console.error('Failed to update favorite:', error)
      }
    }
  }

  const handlePlayback = () => {
    if (workId) {
      router.push(`/read/${workId}?playback=true`)
    }
  }

  // 监听滚动计算阅读进度
  useEffect(() => {
    const handleScroll = () => {
      if (contentRef.current) {
        const { scrollTop, scrollHeight, clientHeight } = contentRef.current
        const progress = Math.round((scrollTop / (scrollHeight - clientHeight)) * 100) || 0
        setReadingProgress(Math.min(100, Math.max(0, progress)))
      }
    }

    const contentEl = contentRef.current
    if (contentEl) {
      contentEl.addEventListener('scroll', handleScroll)
      return () => contentEl.removeEventListener('scroll', handleScroll)
    }
  }, [])

  return (
    <div 
      className="min-h-screen transition-colors duration-300"
      style={{ backgroundColor: currentTheme.bg }}
      data-reader-theme={settings.theme}
    >
      {/* Favorite Toast */}
      {showFavoriteToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-accent text-accent-foreground rounded-full text-sm animate-fade-in">
          {isFavorited ? '已添加到收藏' : '已取消收藏'}
        </div>
      )}

      {/* Header */}
      <header className="sticky top-16 z-40 backdrop-blur-lg bg-background/80 border-b border-border">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => router.back()}
              className="gap-1"
            >
              <ChevronLeft className="h-4 w-4" />
              返回
            </Button>
            
            <div className="flex items-center gap-1">
              {hasPlayback && (
                <Button 
                  variant="ghost" 
                  size="icon"
                  onClick={() => {
                    if (workId && operations?.length) {
                      const replayData = {
                        workId,
                        operations,
                        title
                      }
                      localStorage.setItem(`wenhen_replay_${workId}`, JSON.stringify(replayData))
                      window.dispatchEvent(new CustomEvent('storage', { 
                        detail: { key: `wenhen_replay_${workId}` }
                      }))
                      router.push(`/write?replay=${workId}`)
                    }
                  }}
                  title="观看写作回放"
                >
                  <Play className="h-5 w-5 text-primary" />
                </Button>
              )}
              
              <Button 
                variant="ghost" 
                size="icon"
                onClick={handleLike}
                className={cn(isLiked && 'text-red-500')}
              >
                <Star className={cn("h-5 w-5", isLiked && "fill-yellow-500 text-yellow-500")} />
              </Button>
              
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowSettings(!showSettings)}
                className={cn(showSettings && 'bg-muted')}
              >
                <Settings className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Settings Panel - With Font Selection and Live Preview */}
      {showSettings && (
        <div 
          className="fixed right-4 top-32 z-50 w-72 p-4 rounded-lg shadow-lg border bg-card"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-serif font-semibold text-foreground">
              阅读设置
            </h3>
            <Button 
              variant="ghost" 
              size="icon"
              className="h-6 w-6"
              onClick={() => setShowSettings(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Theme Selection */}
          <div className="mb-4">
            <label className="text-sm mb-2 block text-foreground">
              阅读主题
            </label>
            <div className="flex gap-2">
              {readerThemes.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => updateSetting('theme', theme.id)}
                  className={cn(
                    "w-8 h-8 rounded-full border-2 transition-transform hover:scale-110",
                    settings.theme === theme.id && "border-primary scale-110"
                  )}
                  style={{ backgroundColor: theme.bg }}
                  title={theme.name}
                />
              ))}
            </div>
          </div>

          {/* Font Family Selection */}
          <div className="mb-4">
            <label className="text-sm mb-2 block text-foreground">
              正文字体
            </label>
            <div className="grid grid-cols-2 gap-2">
              {fontFamilies.map((font) => (
                <button
                  key={font.id}
                  onClick={() => updateSetting('fontFamily', font.id)}
                  className={cn(
                    "px-3 py-2 text-sm rounded-md border transition-all text-center",
                    settings.fontFamily === font.id 
                      ? "border-primary bg-primary/10 text-primary" 
                      : "border-border hover:border-primary/50"
                  )}
                  style={{ fontFamily: font.family }}
                >
                  {font.name}
                </button>
              ))}
            </div>
          </div>

          {/* Font Size */}
          <div className="mb-4">
            <label className="text-sm mb-2 block text-foreground">
              <Type className="h-4 w-4 inline mr-1" />
              字体大小：{settings.fontSize}px
            </label>
            <Slider
              value={[settings.fontSize]}
              min={14}
              max={28}
              step={1}
              onValueChange={(values) => updateSetting('fontSize', values[0])}
              className="w-full"
            />
          </div>

          {/* Live Preview */}
          <div className="p-3 rounded-md border border-dashed" style={{ backgroundColor: currentTheme.bg }}>
            <p 
              className="text-xs mb-1" 
              style={{ color: `${currentTheme.text}60` }}
            >
              预览效果
            </p>
            <p 
              style={{
                fontSize: `${settings.fontSize}px`,
                lineHeight: 1.8,
                fontFamily: currentFont.family,
                color: currentTheme.text,
              }}
            >
              落霞与孤鹜齐飞，秋水共长天一色。
            </p>
          </div>
        </div>
      )}

      {/* Reading Progress Bar */}
      <div className="fixed top-16 left-0 right-0 h-1 bg-muted z-40">
        <div 
          className="h-full bg-primary transition-all duration-300"
          style={{ width: `${readingProgress}%` }}
        />
      </div>

      {/* Content */}
      <article 
        ref={contentRef}
        className="container mx-auto px-4 pt-24 pb-8 max-w-2xl overflow-y-auto"
        style={{ maxHeight: 'calc(100vh - 120px)' }}
      >
        {/* Title & Meta */}
        <header className="mb-8 text-center">
          <h1 
            className="text-3xl font-serif font-bold mb-4"
            style={{ color: currentTheme.text }}
          >
            {title}
          </h1>
          <div 
            className="flex items-center justify-center gap-4 text-sm flex-wrap"
            style={{ color: `${currentTheme.text}80` }}
          >
            <Link href={`/author/${authorId}`} className="hover:underline">@{author}</Link>
            <span>|</span>
            <span>{genre}</span>
            <span>|</span>
            <span>{wordCount} 字</span>
          </div>
        </header>

        {/* Divider */}
        <div className="classic-divider mb-8" style={{ color: `${currentTheme.text}30` }}>
          <span>◆</span>
        </div>

        {/* Main Content */}
        <div 
          className="reader-content"
          style={{
            fontSize: `${settings.fontSize}px`,
            lineHeight: lineHeight,
            fontFamily: currentFont.family,
            color: currentTheme.text,
          }}
        >
          {content.split('\n').map((paragraph, index) => (
            <p key={index} className="mb-4 last:mb-0">
              {paragraph || '\u00A0'}
            </p>
          ))}
        </div>

        {/* Footer */}
        <footer className="mt-12 pt-8 border-t text-center">
          <div 
            className="flex items-center justify-center gap-6 text-sm mb-4 flex-wrap"
            style={{ color: `${currentTheme.text}60` }}
          >
            <button 
              onClick={handleLike}
              className={cn(
                "flex items-center gap-1 hover:text-red-500 transition-colors",
                isLiked && "text-red-500"
              )}
            >
              <Star className={cn("h-4 w-4", isLiked && "fill-yellow-500 text-yellow-500")} />
              {currentLikeCount} 喜欢
            </button>
            <span>|</span>
            <span>{playCount} 阅读</span>
          </div>
          
          {/* Reading Progress Info */}
          <div className="mb-4">
            <div className="flex items-center justify-center gap-2 text-sm" style={{ color: `${currentTheme.text}60` }}>
              <Eye className="h-4 w-4" />
              <span>阅读进度：{readingProgress}%</span>
            </div>
          </div>
          
          <p 
            className="text-xs italic"
            style={{ color: `${currentTheme.text}40` }}
          >
            发布于 {createdAt}
          </p>
        </footer>
      </article>
    </div>
  )
}
