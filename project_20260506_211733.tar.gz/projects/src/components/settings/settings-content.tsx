'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/contexts/auth-context'
import { createClient as supabaseBrowser } from '@/storage/database/supabase-client-browser'
import {
  User,
  Save,
  Camera,
  Check,
  AlertCircle,
  Loader2,
  Trash2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

export default function SettingsContent() {
  const router = useRouter()
  const { user, profile, loading: authLoading, refreshProfile } = useAuth()
  const [username, setUsername] = useState('')
  const [bio, setBio] = useState('')
  const [avatar, setAvatar] = useState('')
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    if (profile) {
      setUsername(profile.username || '')
      setBio(profile.bio || '')
      setAvatar(profile.avatar_url || '')
    }
  }, [profile])

  const handleSave = async () => {
    if (!user) return
    if (!username.trim()) {
      setError('请输入用户名')
      return
    }
    if (username.length < 2 || username.length > 20) {
      setError('用户名长度需在2-20个字符之间')
      return
    }

    setIsSaving(true)
    setError('')
    setSuccess(false)

    try {
      const { error } = await supabaseBrowser()
        .from('profiles')
        .upsert({
          id: user.id,
          username: username.trim(),
          bio: bio.trim(),
          avatar_url: avatar || null,
          updated_at: new Date().toISOString()
        })

      if (error) throw error

      // 同时更新 localStorage 中的用户数据
      const storedUser = localStorage.getItem('wenhen_user')
      if (storedUser) {
        const updatedUser = {
          ...JSON.parse(storedUser),
          username: username.trim(),
          bio: bio.trim(),
          avatar_url: avatar || undefined
        }
        localStorage.setItem('wenhen_user', JSON.stringify(updatedUser))
        
        // 更新已注册用户列表
        const registeredUsers = JSON.parse(localStorage.getItem('wenhen_registered_users') || '[]')
        const updatedRegisteredUsers = registeredUsers.map((u: { id: string }) => 
          u.id === user.id ? updatedUser : u
        )
        localStorage.setItem('wenhen_registered_users', JSON.stringify(updatedRegisteredUsers))
      }
      
      await refreshProfile()
      setSuccess(true)
      toast.success('保存成功')
      // 1秒后自动跳转到个人主页
      setTimeout(() => {
        router.push('/profile')
        router.refresh()
      }, 1000)
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : '保存失败'
      setError(errorMessage)
      toast.error('保存失败', { description: errorMessage })
    } finally {
      setIsSaving(false)
    }
  }

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <AlertCircle className="h-12 w-12 text-muted-foreground" />
        <p className="text-muted-foreground">请先登录</p>
        <Button asChild>
          <a href="/login">前往登录</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <div className="mb-8">
        <h1 className="text-3xl font-serif font-bold mb-2">账号设置</h1>
        <p className="text-muted-foreground">管理您的个人信息和账号设置</p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-center gap-3">
          <AlertCircle className="h-5 w-5 text-destructive" />
          <span className="text-sm text-destructive">{error}</span>
        </div>
      )}

      <div className="space-y-6">
        {/* 头像设置 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Camera className="h-5 w-5" />
              头像设置
            </CardTitle>
            <CardDescription>
              设置您的个人头像，展示您的独特风格
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-6">
              <div className="relative">
                {avatar ? (
                  <img
                    src={avatar}
                    alt="头像"
                    className="w-24 h-24 rounded-full object-cover border-2 border-border"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center border-2 border-border">
                    <User className="h-10 w-10 text-muted-foreground" />
                  </div>
                )}
              </div>
              <div className="flex-1 space-y-2">
                <div>
                  <label className="text-sm font-medium mb-1 block">头像链接</label>
                  <Input
                    placeholder="输入头像图片URL"
                    value={avatar}
                    onChange={(e) => setAvatar(e.target.value)}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  支持 JPG、PNG、GIF 格式，建议尺寸 200x200
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 基本信息 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-5 w-5" />
              基本信息
            </CardTitle>
            <CardDescription>
              修改您的用户名和个人简介
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">
                用户名 <span className="text-destructive">*</span>
              </label>
              <Input
                placeholder="请输入用户名"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                maxLength={20}
              />
              <div className="flex justify-between mt-1">
                <span className="text-xs text-muted-foreground">2-20个字符</span>
                <span className={cn(
                  "text-xs",
                  username.length < 2 ? "text-muted-foreground" : "text-green-600"
                )}>
                  {username.length}/20
                </span>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">
                个人简介
              </label>
              <Textarea
                placeholder="向大家介绍一下自己..."
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={200}
                rows={4}
              />
              <div className="flex justify-end mt-1">
                <span className="text-xs text-muted-foreground">
                  {bio.length}/200
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 账号信息 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">账号信息</CardTitle>
            <CardDescription>
              您的账号基本信息
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-muted-foreground">邮箱</span>
              <span className="font-medium">{user.email}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-border">
              <span className="text-muted-foreground">用户ID</span>
              <span className="font-mono text-sm text-muted-foreground">
                {user.id.slice(0, 8)}...
              </span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-muted-foreground">注册时间</span>
              <span className="text-sm">
                {profile?.created_at
                  ? new Date(profile.created_at).toLocaleDateString('zh-CN')
                  : '-'}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* 保存按钮 */}
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className={cn(
            'w-full h-12 text-lg gap-2 transition-all',
            success && 'bg-green-600 hover:bg-green-600'
          )}
        >
          {isSaving ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              保存中...
            </>
          ) : success ? (
            <>
              <Check className="h-5 w-5" />
              保存成功
            </>
          ) : (
            <>
              <Save className="h-5 w-5" />
              保存设置
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
