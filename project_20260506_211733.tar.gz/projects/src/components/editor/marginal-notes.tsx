'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { 
  MessageSquare, 
  Plus, 
  Trash2, 
  Edit2,
  Clock,
  Check
} from 'lucide-react'

interface MarginalNote {
  id: string
  content: string
  timestamp: number // 对应创作时间点（毫秒）
  createdAt: Date
  isEditing?: boolean
}

interface MarginalNotesPanelProps {
  notes: MarginalNote[]
  onAddNote: (content: string, timestamp: number) => void
  onUpdateNote: (id: string, content: string) => void
  onDeleteNote: (id: string) => void
  currentTime?: number // 当前创作时间
}

// 格式化时间戳为可读格式
const formatTimestamp = (ms: number) => {
  const seconds = Math.floor(ms / 1000)
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
}

export function MarginalNotesPanel({
  notes,
  onAddNote,
  onUpdateNote,
  onDeleteNote,
  currentTime = 0,
}: MarginalNotesPanelProps) {
  const [newNoteContent, setNewNoteContent] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingContent, setEditingContent] = useState('')

  const handleAddNote = () => {
    if (!newNoteContent.trim()) return
    onAddNote(newNoteContent.trim(), currentTime)
    setNewNoteContent('')
  }

  const handleStartEdit = (note: MarginalNote) => {
    setEditingId(note.id)
    setEditingContent(note.content)
  }

  const handleSaveEdit = (id: string) => {
    if (!editingContent.trim()) return
    onUpdateNote(id, editingContent.trim())
    setEditingId(null)
    setEditingContent('')
  }

  const handleCancelEdit = () => {
    setEditingId(null)
    setEditingContent('')
  }

  // 按时间戳排序
  const sortedNotes = [...notes].sort((a, b) => a.timestamp - b.timestamp)

  return (
    <div className="h-full flex flex-col bg-card rounded-lg border border-border">
      {/* Header */}
      <div className="flex items-center gap-2 p-4 border-b border-border">
        <MessageSquare className="h-5 w-5 text-accent" />
        <h3 className="font-serif font-semibold">旁注</h3>
        <span className="ml-auto text-xs text-muted-foreground">
          {notes.length} 条
        </span>
      </div>

      {/* Add Note Form */}
      <div className="p-4 border-b border-border space-y-3">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          <span>当前位置：{formatTimestamp(currentTime)}</span>
        </div>
        <Textarea
          value={newNoteContent}
          onChange={(e) => setNewNoteContent(e.target.value)}
          placeholder="记录此刻的想法..."
          className="min-h-[80px] resize-none text-sm"
        />
        <Button 
          onClick={handleAddNote} 
          size="sm" 
          className="w-full gap-1"
          disabled={!newNoteContent.trim()}
        >
          <Plus className="h-4 w-4" />
          添加旁注
        </Button>
      </div>

      {/* Notes List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {sortedNotes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-30" />
            <p className="text-sm">暂无旁注</p>
            <p className="text-xs">记录创作时的碎碎念</p>
          </div>
        ) : (
          sortedNotes.map((note) => (
            <div key={note.id} className="marginal-note group">
              {/* Timestamp Badge */}
              <div className="flex items-center justify-between mb-2">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-accent/10 text-accent text-xs rounded-full">
                  <Clock className="h-3 w-3" />
                  {formatTimestamp(note.timestamp)}
                </span>
                
                {editingId === note.id ? (
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => handleSaveEdit(note.id)}
                    >
                      <Check className="h-3 w-3 text-green-500" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={handleCancelEdit}
                    >
                      <span className="text-xs">取消</span>
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => handleStartEdit(note)}
                    >
                      <Edit2 className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => onDeleteNote(note.id)}
                    >
                      <Trash2 className="h-3 w-3 text-destructive" />
                    </Button>
                  </div>
                )}
              </div>

              {/* Content */}
              {editingId === note.id ? (
                <Textarea
                  value={editingContent}
                  onChange={(e) => setEditingContent(e.target.value)}
                  className="min-h-[60px] resize-none text-sm"
                  autoFocus
                />
              ) : (
                <p className="text-sm leading-relaxed">{note.content}</p>
              )}
            </div>
          ))
        )}
      </div>

      {/* Tips */}
      <div className="p-4 border-t border-border bg-muted/30">
        <p className="text-xs text-muted-foreground">
          旁注会与回放同步显示，帮助回顾创作灵感
        </p>
      </div>
    </div>
  )
}

// 旁注时间线组件 - 用于在回放时显示
export function MarginalNotesTimeline({ 
  notes, 
  currentTime,
  onSeekTo 
}: { 
  notes: MarginalNote[]
  currentTime: number
  onSeekTo: (timestamp: number) => void
}) {
  const sortedNotes = [...notes].sort((a, b) => a.timestamp - b.timestamp)
  
  // 获取当前时间点附近的旁注
  const nearbyNotes = sortedNotes.filter(note => {
    const diff = Math.abs(note.timestamp / 1000 - currentTime)
    return diff < 10 // 前后10秒内的旁注
  })

  if (nearbyNotes.length === 0) return null

  return (
    <div className="absolute right-4 top-1/2 -translate-y-1/2 w-64 space-y-2">
      {nearbyNotes.map((note) => (
        <div 
          key={note.id}
          className="marginal-note cursor-pointer hover:bg-muted/80 transition-colors"
          onClick={() => onSeekTo(note.timestamp / 1000)}
        >
          <span className="text-xs text-accent mb-1 block">
            {formatTimestamp(note.timestamp)}
          </span>
          <p className="text-sm">{note.content}</p>
        </div>
      ))}
    </div>
  )
}
