'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent } from '@/components/ui/card'
import { useAuth } from '@/contexts/auth-context'
import { 
  Save, 
  Play, 
  Pause,
  RotateCcw,
  MessageSquare,
  Clock,
  AlertCircle,
  SkipBack,
  SkipForward,
  Volume2,
  Circle,
  Check,
  Cloud,
  FileText,
  Sparkles,
  BookOpen,
  Feather,
  Heart,
  Send,
} from 'lucide-react'

// ==================== 类型定义 ====================

// 写作操作类型
type OperationType = 'input' | 'paste' | 'paste-truncated' | 'key' | 'snapshot'

// 写作操作接口 - 完整记录（精确到毫秒）
interface Operation {
  t: number                    // 时间戳（相对于开始写作的毫秒数，毫秒级精度）
  type: OperationType          // 操作类型
  pos: number                  // 光标位置
  val: string                  // 当前编辑器全文快照
  data?: string                // 输入/粘贴的字符
  key?: string                 // 按键名称
  length?: number              // 删除的字符数
}

// 回放操作接口
interface ReplayAction {
  t: number
  val: string
  pos: number
  delta?: string
  isDelete?: boolean
}

// 操作存储数据结构（包含元数据）
interface OperationsStorage {
  operations: Operation[]
  writingStartedAt: string      // ISO时间字符串
  writingDuration: number       // 总写作时长（毫秒）
}

// 题材类型
type Genre = 'poetry' | 'essay' | 'story' | 'novel' | 'letter' | 'script'

// 可见范围类型
type Visibility = 'public' | 'private' | 'followers'

const genreLabels: Record<Genre, string> = {
  poetry: '诗歌',
  essay: '随笔',
  story: '短故事',
  novel: '小说',
  letter: '书信',
  script: '剧本',
}

const genreDescriptions: Record<Genre, string> = {
  poetry: '凝练的语言，抒发情感与意境',
  essay: '自由的笔触，记录生活与思考',
  story: '完整的故事，讲述人间百态',
  novel: '长篇叙事，展现人物与世界观',
  letter: '真挚的情感，传递思念与祝福',
  script: '戏剧冲突，对话与场景描写',
}

const genreIcons: Record<Genre, React.ReactNode> = {
  poetry: <Feather className="h-4 w-4" />,
  essay: <FileText className="h-4 w-4" />,
  story: <BookOpen className="h-4 w-4" />,
  novel: <BookOpen className="h-4 w-4" />,
  letter: <Heart className="h-4 w-4" />,
  script: <Sparkles className="h-4 w-4" />,
}

const PASTE_LIMIT = 10
const STORAGE_KEY_PREFIX = 'wenhen_operations_'
const AUTOSAVE_KEY = 'wenhen_autosave_'

interface WritingEditorProps {
  workId?: string
  initialTitle?: string
  initialContent?: string
  initialGenre?: Genre
  initialOperations?: Operation[]
  onSave?: (title: string, content: string, genre: Genre, operations: Operation[]) => Promise<void>
  onPublish?: (title: string, content: string, genre: Genre, operations: Operation[]) => Promise<void>
}

export function WritingEditor({
  workId,
  initialTitle = '',
  initialContent = '',
  initialGenre = 'essay',
  initialOperations = [],
  onSave,
  onPublish,
}: WritingEditorProps) {
	// ==================== Router ====================
	const router = useRouter()
  // ==================== Auth ====================
  const { user } = useAuth()
  // ==================== 状态 ====================
  const [title, setTitle] = useState(initialTitle)
  const [content, setContent] = useState(initialContent)
  const [genre, setGenre] = useState<Genre>(initialGenre)
  
  // 录制状态
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [operationCount, setOperationCount] = useState(0)
  
  // 回放状态
  const [isPlaying, setIsPlaying] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [replayProgress, setReplayProgress] = useState(0)
  const [currentReplayIndex, setCurrentReplayIndex] = useState(0)
  const [totalReplayOps, setTotalReplayOps] = useState(0)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [showCursor, setShowCursor] = useState(true)
  const [currentReplayTime, setCurrentReplayTime] = useState(0)
  const speedOptions = [1, 2, 4, 8]
  
  // 旁注
  const [showMarginalNotes, setShowMarginalNotes] = useState(false)
  const [marginalNotes, setMarginalNotes] = useState<Array<{time: number, content: string}>>([])
  const [marginalNote, setMarginalNote] = useState('')
  
  // 警告/提示
  const [showAlert, setShowAlert] = useState(false)
  const [alertMessage, setAlertMessage] = useState('')
  const [alertType, setAlertType] = useState<'info' | 'success' | 'error'>('info')
  
  // 自动保存状态
  const [isSaving, setIsSaving] = useState(false)
  const [lastSaveTime, setLastSaveTime] = useState<Date | null>(null)
  const [isDirty, setIsDirty] = useState(false)
  
  // 发布状态
  const [isPublishing, setIsPublishing] = useState(false)
  const [showPublishConfirm, setShowPublishConfirm] = useState(false)
  const [visibility, setVisibility] = useState<Visibility>('public')
  
  // 小说章节状态
  const [chapters, setChapters] = useState<Array<{id: string, title: string, content: string}>>([])
  const [currentChapterId, setCurrentChapterId] = useState<string>('')
  const [showChapterPanel, setShowChapterPanel] = useState(false)
  const [newChapterTitle, setNewChapterTitle] = useState('')
  
  // 诗歌格式状态
  const [poetryFormat, setPoetryFormat] = useState<string>('free')
  
  // 剧本状态
  const [scenes, setScenes] = useState<Array<{id: string, title: string}>>([])
  const [currentSceneId, setCurrentSceneId] = useState<string>('')
  const [showScriptPanel, setShowScriptPanel] = useState(false)
  const [newSceneTitle, setNewSceneTitle] = useState('')
  
  // 光标位置
  const [cursorPos, setCursorPos] = useState(0)

  // ==================== REFS ====================
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  
  // 录制相关refs
  const operationsRef = useRef<Operation[]>(initialOperations)
  const startTimeRef = useRef<number>(0)
  const recordingTimerRef = useRef<number | null>(null)
  const lastSnapshotRef = useRef<string>('')
  const writingStartedAtRef = useRef<string>('') // 写作开始时间（ISO字符串）
  
  // 回放相关refs
  const replayOpsRef = useRef<ReplayAction[]>([])
  const replayIndexRef = useRef<number>(0)
  const replayTimerRef = useRef<number | null>(null)
  const isPlayingRef = useRef(false)
  const isPausedRef = useRef(false)
  const playbackSpeedRef = useRef(1)
  const cursorBlinkRef = useRef<number | null>(null)
  const replayContentRef = useRef<string>('')
  
  // 自动保存ref
  const autosaveTimerRef = useRef<number | null>(null)
  const lastContentRef = useRef(content)
  const lastTitleRef = useRef(title)

  // ==================== 计算属性 ====================
  const wordCount = content.replace(/\s/g, '').length
  const paragraphCount = content.split('\n').filter(p => p.trim().length > 0).length
  const readingTime = Math.max(1, Math.ceil(wordCount / 300))
  const hasUnsavedChanges = isDirty || content !== lastContentRef.current || title !== lastTitleRef.current

  // ==================== 工具函数 ====================
  
  // 插入文本到光标位置
  const insertAtCursor = useCallback((before: string, after: string = '') => {
    const textarea = document.getElementById('content-editor') as HTMLTextAreaElement
    if (!textarea) return
    
    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = content.substring(start, end)
    
    const newText = content.substring(0, start) + before + selectedText + after + content.substring(end)
    setContent(newText)
    
    // 设置光标位置
    setTimeout(() => {
      textarea.focus()
      const newCursorPos = start + before.length + selectedText.length
      textarea.setSelectionRange(newCursorPos, newCursorPos)
    }, 0)
  }, [content])
  
  // 格式化快捷操作
  const formatOptions = [
    { label: '标题', before: '【', after: '】', action: () => insertAtCursor('【', '】') },
    { label: '引用', before: '「', after: '」', action: () => insertAtCursor('「', '」') },
    { label: '分隔', before: '\n——\n', after: '', action: () => insertAtCursor('\n——\n') },
  ]
  
  // ==================== 章节管理（小说） ====================
  const addChapter = () => {
    if (!newChapterTitle.trim()) return
    const id = Date.now().toString()
    const newChapter = { id, title: newChapterTitle.trim(), content: '' }
    setChapters([...chapters, newChapter])
    setCurrentChapterId(id)
    setContent('')
    setNewChapterTitle('')
  }
  
  const switchChapter = (chapterId: string) => {
    // 保存当前章节内容
    if (currentChapterId) {
      setChapters(chapters.map(ch => 
        ch.id === currentChapterId ? { ...ch, content } : ch
      ))
    }
    // 切换到新章节
    const chapter = chapters.find(ch => ch.id === chapterId)
    if (chapter) {
      setCurrentChapterId(chapterId)
      setContent(chapter.content)
    }
  }
  
  const deleteChapter = (chapterId: string) => {
    if (!confirm('确定删除此章节？')) return
    const newChapters = chapters.filter(ch => ch.id !== chapterId)
    setChapters(newChapters)
    if (currentChapterId === chapterId) {
      if (newChapters.length > 0) {
        setCurrentChapterId(newChapters[0].id)
        setContent(newChapters[0].content)
      } else {
        setCurrentChapterId('')
        setContent('')
      }
    }
  }
  
  const updateChapterTitle = (chapterId: string, newTitle: string) => {
    setChapters(chapters.map(ch => 
      ch.id === chapterId ? { ...ch, title: newTitle } : ch
    ))
  }
  
  const insertChapterDivider = () => {
    insertAtCursor('\n\n【第' + (chapters.length + 1) + '章】\n\n')
  }
  
  // ==================== 场景管理（剧本/短故事） ====================
  const addScene = () => {
    if (!newSceneTitle.trim()) return
    const id = Date.now().toString()
    const newScene = { id, title: newSceneTitle.trim() }
    setScenes([...scenes, newScene])
    setNewSceneTitle('')
  }
  
  const deleteScene = (sceneId: string) => {
    if (!confirm('确定删除此场景？')) return
    setScenes(scenes.filter(s => s.id !== sceneId))
  }
  
  const insertSceneHeader = (sceneTitle: string) => {
    insertAtCursor(`\n\n【${sceneTitle}】\n`)
  }
  
  // ==================== 诗歌格式 ====================
  const poetryTemplates: Record<string, {label: string, content: string}> = {
    five: { label: '五言绝句', content: '【标题】\n\n第一句\n第二句\n第三句\n第四句' },
    seven: { label: '七言律诗', content: '【标题】\n\n第一句\n第二句\n第三句\n第四句\n第五句\n第六句\n第七句\n第八句' },
    lüshi: { label: '五言律诗', content: '【标题】\n\n第一句\n第二句\n第三句\n第四句\n第五句\n第六句\n第七句\n第八句' },
    free: { label: '自由诗', content: '' },
  }
  
  const applyPoetryTemplate = (templateKey: string) => {
    const template = poetryTemplates[templateKey]
    if (template && template.content) {
      setContent(template.content)
      setPoetryFormat(templateKey)
    } else {
      setPoetryFormat(templateKey)
    }
  }
  
  // ==================== 剧本格式 ====================
  const insertCharacterDialogue = (characterName: string) => {
    insertAtCursor(`\n【${characterName}】\n（内心）\n「」\n`)
  }
  
  const insertStageDirection = () => {
    insertAtCursor('\n（舞台指示：）\n')
  }
  
  const insertScriptCharacter = () => {
    insertAtCursor('\n【角色名】：\n')
  }
  
  const getTimestamp = () => performance.now()
  
  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000)
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const formatTimestamp = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000)
    const mins = Math.floor(totalSeconds / 60)
    const secs = totalSeconds % 60
    const millis = Math.floor(ms % 1000)
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${millis.toString().padStart(3, '0')}`
  }

  // 保存操作到localStorage（包含元数据）
  const saveOperationsToStorage = useCallback(() => {
    if (workId && operationsRef.current.length > 0) {
      const storageData: OperationsStorage = {
        operations: operationsRef.current,
        writingStartedAt: writingStartedAtRef.current,
        writingDuration: recordingTime
      }
      localStorage.setItem(
        `${STORAGE_KEY_PREFIX}${workId}`,
        JSON.stringify(storageData)
      )
    }
  }, [workId, recordingTime])

  // 从localStorage加载操作（支持续写）
  const loadOperationsFromStorage = useCallback((): OperationsStorage | null => {
    if (workId) {
      const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}${workId}`)
      if (saved) {
        try {
          return JSON.parse(saved) as OperationsStorage
        } catch {
          return null
        }
      }
    }
    return null
  }, [workId])

  // 自动保存草稿
  const autosave = useCallback(() => {
    if (workId && (content || title)) {
      const draft = {
        title,
        content,
        genre,
        operations: operationsRef.current,
        writingStartedAt: writingStartedAtRef.current,
        writingDuration: recordingTime,
        marginalNotes,
        updatedAt: new Date().toISOString()
      }
      localStorage.setItem(`${AUTOSAVE_KEY}${workId}`, JSON.stringify(draft))
      setLastSaveTime(new Date())
      setIsDirty(false)
      lastContentRef.current = content
      lastTitleRef.current = title
    }
  }, [workId, title, content, genre, marginalNotes, recordingTime])

  // 加载草稿
  const loadDraft = useCallback(() => {
    if (workId) {
      const saved = localStorage.getItem(`${AUTOSAVE_KEY}${workId}`)
      if (saved) {
        try {
          const draft = JSON.parse(saved)
          if (draft.content && !initialContent) {
            setTitle(draft.title || '')
            setContent(draft.content)
            setGenre(draft.genre || 'essay')
            operationsRef.current = draft.operations || []
            writingStartedAtRef.current = draft.writingStartedAt || new Date().toISOString()
            setMarginalNotes(draft.marginalNotes || [])
            setOperationCount(draft.operations?.length || 0)
            setRecordingTime(draft.writingDuration || 0)
            lastContentRef.current = draft.content
            lastTitleRef.current = draft.title || ''
            return true
          }
        } catch {
          return false
        }
      }
    }
    return false
  }, [workId, initialContent])

  // ==================== 录制功能 ====================

  const startRecording = useCallback(() => {
    if (isRecording) return
    
    // 如果是续写，保持原有的开始时间
    if (!writingStartedAtRef.current) {
      writingStartedAtRef.current = new Date().toISOString()
    }
    
    operationsRef.current = []
    startTimeRef.current = getTimestamp()
    lastSnapshotRef.current = content
    setIsRecording(true)
    setRecordingTime(0)
    setOperationCount(0)
    
    const updateTime = () => {
      setRecordingTime(getTimestamp() - startTimeRef.current)
      recordingTimerRef.current = requestAnimationFrame(updateTime)
    }
    recordingTimerRef.current = requestAnimationFrame(updateTime)
  }, [isRecording, content])

  const stopRecording = useCallback(() => {
    if (!isRecording) return
    
    setIsRecording(false)
    if (recordingTimerRef.current) {
      cancelAnimationFrame(recordingTimerRef.current)
      recordingTimerRef.current = null
    }
    saveOperationsToStorage()
  }, [isRecording, saveOperationsToStorage])

  const recordOperation = useCallback((
    type: Operation['type'],
    newContent: string,
    pos: number,
    data?: string,
    key?: string
  ) => {
    if (!isRecording) return
    
    const currentTime = getTimestamp() - startTimeRef.current
    
    const op: Operation = {
      t: currentTime,
      type,
      pos,
      val: newContent,
      data,
      key
    }
    
    operationsRef.current.push(op)
    lastSnapshotRef.current = newContent
    setOperationCount(operationsRef.current.length)
    setIsDirty(true)
  }, [isRecording])

  // ==================== 输入处理 ====================

  const handleInput = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value
    const oldContent = content
    const pos = textareaRef.current?.selectionStart || 0
    
    // 只要有输入就自动开始录制
    if (!isRecording) {
      startRecording()
    }
    
    if (newContent !== oldContent) {
      recordOperation('input', newContent, pos, newContent.slice(oldContent.length))
    }
    
    setContent(newContent)
    setCursorPos(pos)
  }, [content, isRecording, startRecording, recordOperation])

  const handleKeyDown = useCallback((e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (!isRecording) {
      if (content.length > 0 && ['Backspace', 'Delete', 'Enter'].includes(e.key)) {
        startRecording()
        return
      }
    }
    
    const pos = textareaRef.current?.selectionStart || 0
    
    if (['Backspace', 'Delete', 'Enter'].includes(e.key)) {
      e.preventDefault()
      
      let newContent = content
      let newPos = pos
      
      if (e.key === 'Backspace' && pos > 0) {
        newContent = content.slice(0, pos - 1) + content.slice(pos)
        newPos = pos - 1
        recordOperation('key', newContent, newPos, undefined, 'Backspace')
      } else if (e.key === 'Delete' && pos < content.length) {
        newContent = content.slice(0, pos) + content.slice(pos + 1)
        newPos = pos
        recordOperation('key', newContent, newPos, undefined, 'Delete')
      } else if (e.key === 'Enter') {
        newContent = content.slice(0, pos) + '\n' + content.slice(pos)
        newPos = pos + 1
        recordOperation('key', newContent, newPos, undefined, 'Enter')
      }
      
      setContent(newContent)
      setCursorPos(newPos)
    }
  }, [content, isRecording, startRecording, recordOperation])

  const handlePaste = useCallback((e: React.ClipboardEvent) => {
    e.preventDefault()
    const pastedText = e.clipboardData.getData('text/plain')
    const pos = textareaRef.current?.selectionStart || 0
    
    if (!isRecording) {
      startRecording()
    }
    
    let truncated = false
    let finalText = pastedText
    
    if (pastedText.length > PASTE_LIMIT) {
      setAlertMessage(`粘贴超过${PASTE_LIMIT}字限制，已截断。请手动输入以保持原创。`)
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 4000)
      finalText = pastedText.slice(0, PASTE_LIMIT)
      truncated = true
    }
    
    const newContent = content.slice(0, pos) + finalText + content.slice(pos)
    
    recordOperation(
      truncated ? 'paste-truncated' : 'paste',
      newContent,
      pos + finalText.length,
      finalText
    )
    
    setContent(newContent)
    setCursorPos(pos + finalText.length)
  }, [content, isRecording, startRecording, recordOperation])

  // ==================== 回放功能 ====================

  const buildReplayOps = useCallback((operations: Operation[]): ReplayAction[] => {
    if (operations.length === 0) return []
    
    const replayOps: ReplayAction[] = []
    let lastVal = ''
    let lastPos = 0
    
    for (const op of operations) {
      if (op.val !== undefined) {
        let delta = ''
        let isDelete = false
        
        if (op.val.length > lastVal.length) {
          delta = op.val.slice(lastVal.length)
        } else if (op.val.length < lastVal.length) {
          delta = lastVal.slice(op.val.length)
          isDelete = true
        }
        
        replayOps.push({
          t: op.t,
          val: op.val,
          pos: op.pos,
          delta,
          isDelete
        })
        
        lastVal = op.val
        lastPos = op.pos
      }
    }
    
    return replayOps
  }, [])

  const generateReplayFromContent = useCallback((text: string): ReplayAction[] => {
    if (!text) return []
    
    const replayOps: ReplayAction[] = []
    let currentVal = ''
    const estimatedInterval = 200
    
    for (let i = 0; i < text.length; i++) {
      currentVal += text[i]
      replayOps.push({
        t: i * estimatedInterval,
        val: currentVal,
        pos: i + 1,
        delta: text[i],
        isDelete: false
      })
    }
    
    return replayOps
  }, [])

  const executeReplayStep = useCallback(() => {
    if (!isPlayingRef.current || isPausedRef.current) return
    
    const ops = replayOpsRef.current
    const index = replayIndexRef.current
    
    if (index >= ops.length) {
      const lastOp = ops[ops.length - 1]
      if (lastOp) {
        replayContentRef.current = lastOp.val
        setContent(lastOp.val)
        setCursorPos(lastOp.pos)
      }
      
      setIsPlaying(false)
      setIsPaused(false)
      isPlayingRef.current = false
      setReplayProgress(100)
      
      if (cursorBlinkRef.current) {
        clearInterval(cursorBlinkRef.current)
        cursorBlinkRef.current = null
      }
      setShowCursor(true)
      return
    }
    
    const currentOp = ops[index]
    const nextOp = ops[index + 1]
    
    replayContentRef.current = currentOp.val
    setContent(currentOp.val)
    setCursorPos(currentOp.pos)
    
    const progress = ((index + 1) / ops.length) * 100
    setReplayProgress(progress)
    setCurrentReplayIndex(index + 1)
    // Calculate current replay time based on progress
    setCurrentReplayTime(Math.floor((progress / 100) * recordingTime))
    
    replayIndexRef.current = index + 1
    
    let delay = 100
    if (nextOp) {
      const realInterval = nextOp.t - currentOp.t
      const adjustedInterval = realInterval / playbackSpeedRef.current
      delay = Math.max(10, Math.min(adjustedInterval, 1000 / playbackSpeedRef.current))
    }
    
    if (cursorBlinkRef.current) {
      clearInterval(cursorBlinkRef.current)
    }
    setShowCursor(true)
    cursorBlinkRef.current = window.setInterval(() => {
      setShowCursor(prev => !prev)
    }, 400)
    
    replayTimerRef.current = window.setTimeout(executeReplayStep, delay)
  }, [])

  const startReplay = useCallback(() => {
    let ops: ReplayAction[]
    
    if (operationsRef.current.length > 0) {
      ops = buildReplayOps(operationsRef.current)
    } else if (content) {
      ops = generateReplayFromContent(content)
    } else {
      return
    }
    
    if (ops.length === 0) return
    
    replayOpsRef.current = ops
    replayIndexRef.current = 0
    isPlayingRef.current = true
    isPausedRef.current = false
    playbackSpeedRef.current = playbackSpeed
    
    setIsPlaying(true)
    setIsPaused(false)
    setReplayProgress(0)
    setCurrentReplayIndex(0)
    setTotalReplayOps(ops.length)
    setContent('')
    
    executeReplayStep()
  }, [content, buildReplayOps, generateReplayFromContent, playbackSpeed, executeReplayStep])

  const stopReplay = useCallback(() => {
    if (replayTimerRef.current) {
      clearTimeout(replayTimerRef.current)
      replayTimerRef.current = null
    }
    
    if (cursorBlinkRef.current) {
      clearInterval(cursorBlinkRef.current)
      cursorBlinkRef.current = null
    }
    
    isPlayingRef.current = false
    isPausedRef.current = false
    replayIndexRef.current = 0
    
    setIsPlaying(false)
    setIsPaused(false)
    setReplayProgress(0)
    setCurrentReplayIndex(0)
    setShowCursor(true)
  }, [])

  const toggleReplayPause = useCallback(() => {
    isPausedRef.current = !isPausedRef.current
    setIsPaused(isPausedRef.current)
    
    if (!isPausedRef.current) {
      executeReplayStep()
    }
  }, [executeReplayStep])

  const cycleReplaySpeed = useCallback(() => {
    const currentIndex = speedOptions.indexOf(playbackSpeed)
    const nextIndex = (currentIndex + 1) % speedOptions.length
    const newSpeed = speedOptions[nextIndex]
    playbackSpeedRef.current = newSpeed
    setPlaybackSpeed(newSpeed)
  }, [playbackSpeed])

  const handleReplaySeek = useCallback((value: number[]) => {
    const pct = value[0]
    setReplayProgress(pct)
    
    const ops = replayOpsRef.current
    if (ops.length === 0) return
    
    const index = Math.floor((pct / 100) * ops.length)
    replayIndexRef.current = index
    
    const op = ops[index]
    if (op) {
      setContent(op.val)
      setCursorPos(op.pos)
    }
    setCurrentReplayIndex(index)
  }, [])

  const stepReplayForward = useCallback(() => {
    const ops = replayOpsRef.current
    let index = replayIndexRef.current
    
    if (index < ops.length) {
      const op = ops[index]
      setContent(op.val)
      setCursorPos(op.pos)
      
      const progress = ((index + 1) / ops.length) * 100
      setReplayProgress(progress)
      setCurrentReplayIndex(index + 1)
      replayIndexRef.current = index + 1
    }
  }, [])

  const stepReplayBackward = useCallback(() => {
    let index = replayIndexRef.current - 1
    if (index < 0) index = 0
    
    const ops = replayOpsRef.current
    const op = ops[index]
    if (op) {
      setContent(op.val)
      setCursorPos(op.pos)
      
      const progress = ((index + 1) / ops.length) * 100
      setReplayProgress(progress)
      setCurrentReplayIndex(index + 1)
      replayIndexRef.current = index
    }
  }, [])

  // ==================== 旁注功能 ====================

  const addMarginalNote = useCallback(() => {
    if (!marginalNote.trim()) return
    
    const note = {
      time: recordingTime,
      content: marginalNote.trim()
    }
    
    setMarginalNotes(prev => [...prev, note])
    setMarginalNote('')
  }, [marginalNote, recordingTime])

  // ==================== 保存与发布 ====================

  const handleSave = useCallback(async () => {
    // 保存时自动停止录制
    if (isRecording) {
      stopRecording()
    }
    
    if (!title.trim()) {
      setAlertMessage('请输入作品标题')
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 3000)
      return
    }
    
    setIsSaving(true)
    try {
      await onSave?.(title, content, genre, operationsRef.current)
      autosave()
      setAlertMessage('保存成功')
      setAlertType('success')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 2000)
    } catch {
      setAlertMessage('保存失败，请重试')
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 3000)
    } finally {
      setIsSaving(false)
    }
  }, [title, content, genre, isRecording, stopRecording, onSave, autosave])

  // 存草稿 - 保存当前内容为草稿状态
  const handleSaveDraft = useCallback(async () => {
    setIsSaving(true)
    try {
      // 保存到本地存储作为草稿
      const draftData = {
        title,
        content,
        genre,
        operations: operationsRef.current,
        marginalNotes,
        savedAt: new Date().toISOString()
      }
      localStorage.setItem(`wenhen_draft_${workId || 'new'}`, JSON.stringify(draftData))
      
      setAlertMessage('已存草稿')
      setAlertType('success')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 2000)
    } catch {
      setAlertMessage('存草稿失败')
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 3000)
    } finally {
      setIsSaving(false)
    }
  }, [title, content, genre, operationsRef, marginalNotes, workId])

  const handlePublish = useCallback(async () => {
    // 发布时自动停止录制
    if (isRecording) {
      stopRecording()
    }
    
    if (!title.trim()) {
      setAlertMessage('请输入作品标题')
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 3000)
      return
    }
    
    if (!content.trim()) {
      setAlertMessage('请输入作品内容')
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 3000)
      return
    }
    
    setIsPublishing(true)
    try {
      // 直接使用 localStorage 保存作品
      const works = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
      const work = {
        id: `work-${Date.now()}`,
        title: title.trim(),
        content: content,
        genre: genre,
        author: user?.username || '佚名',
        authorId: user?.id || 'anonymous',
        date: new Date().toISOString(),
        operations: operationsRef.current || [],
        sidenotes: marginalNotes || [],
        wordCount: content.length,
        playCount: 0,
        likeCount: 0,
        favoriteCount: 0,
        tags: [],
        visibility: visibility,
        status: 'published',
      }
      works.unshift(work)
      localStorage.setItem('wenhen_works', JSON.stringify(works))
      
      // 调用可选的 onPublish 回调
      await onPublish?.(title, content, genre, operationsRef.current)
      
      // 发布成功后清除草稿
      localStorage.removeItem(`${AUTOSAVE_KEY}${workId}`)
      setAlertMessage('发布成功')
      setAlertType('success')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 2000)
      setShowPublishConfirm(false)
      // 触发作品库刷新
      localStorage.setItem('wenhen_work_published', Date.now().toString())
      // 发布成功后跳转首页
      setTimeout(() => router.push('/'), 1000)
    } catch (err) {
      console.error('Publish failed:', err)
      setAlertMessage('发布失败，请重试')
      setAlertType('error')
      setShowAlert(true)
      setTimeout(() => setShowAlert(false), 3000)
    } finally {
      setIsPublishing(false)
    }
  }, [title, content, genre, user, isRecording, stopRecording, onPublish, workId, operationsRef, marginalNotes, router, visibility])

  // ==================== 生命周期 ====================

  // 加载草稿或编辑作品
  useEffect(() => {
    // 检查是否有编辑作品数据
    const editWorkData = sessionStorage.getItem('edit_work')
    if (editWorkData) {
      try {
        const work = JSON.parse(editWorkData)
        setTitle(work.title || '')
        setContent(work.content || '')
        if (work.genre) setGenre(work.genre as Genre)
        if (work.visibility) setVisibility(work.visibility as Visibility)
        if (work.operations) {
          operationsRef.current = work.operations
          setOperationCount(work.operations.length)
        }
        sessionStorage.removeItem('edit_work')
        return
      } catch (e) {
        console.error('Failed to parse edit work data:', e)
      }
    }
    
    // 否则加载草稿
    loadDraft()
  }, [loadDraft])

  useEffect(() => {
    if (workId) {
      const storageData = loadOperationsFromStorage()
      if (storageData && storageData.operations.length > 0) {
        operationsRef.current = storageData.operations
        writingStartedAtRef.current = storageData.writingStartedAt
        setOperationCount(storageData.operations.length)
        setRecordingTime(storageData.writingDuration || 0)
      }
    }
  }, [workId, loadOperationsFromStorage])

  useEffect(() => {
    const interval = setInterval(autosave, 30000)
    return () => clearInterval(interval)
  }, [autosave])

  useEffect(() => {
    const handleBeforeUnload = () => {
      if (hasUnsavedChanges) {
        autosave()
      }
    }
    window.addEventListener('beforeunload', handleBeforeUnload)
    return () => window.removeEventListener('beforeunload', handleBeforeUnload)
  }, [hasUnsavedChanges, autosave])

  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) {
        cancelAnimationFrame(recordingTimerRef.current)
      }
      if (replayTimerRef.current) {
        clearTimeout(replayTimerRef.current)
      }
      if (cursorBlinkRef.current) {
        clearInterval(cursorBlinkRef.current)
      }
    }
  }, [])

  // ==================== 渲染 ====================

  return (
    <div className="min-h-screen bg-gradient-to-b from-muted/20 to-background pt-16">
      {/* 顶部工具栏 */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur border-b">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            {/* 标题输入 */}
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="输入作品标题..."
              className="flex-1 text-xl font-medium bg-transparent border-none outline-none placeholder:text-muted-foreground"
            />
            
            {/* 题材选择 */}
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value as Genre)}
              className="px-3 py-1.5 rounded-md border bg-background text-sm"
            >
              {Object.entries(genreLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
            
            {/* 小说章节按钮 */}
            {genre === 'novel' && (
              <Button 
                variant={showChapterPanel ? "default" : "outline"} 
                size="sm"
                onClick={() => setShowChapterPanel(!showChapterPanel)}
              >
                <BookOpen className="h-4 w-4 mr-1" />
                章节 ({chapters.length})
              </Button>
            )}
            
            {/* 剧本场景按钮 */}
            {genre === 'script' && (
              <Button 
                variant={showScriptPanel ? "default" : "outline"} 
                size="sm"
                onClick={() => setShowScriptPanel(!showScriptPanel)}
              >
                <Sparkles className="h-4 w-4 mr-1" />
                场景 ({scenes.length})
              </Button>
            )}
            
            {/* 保存按钮 */}
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? (
                <Cloud className="h-4 w-4 mr-1 animate-pulse" />
              ) : (
                <Save className="h-4 w-4 mr-1" />
              )}
              保存
            </Button>
            
            {/* 存草稿按钮 */}
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleSaveDraft}
              disabled={isSaving || !title.trim()}
            >
              <FileText className="h-4 w-4 mr-1" />
              存草稿
            </Button>
            
            {/* 旁注按钮 */}
            <Button 
              variant={showMarginalNotes ? "default" : "outline"} 
              size="sm"
              onClick={() => setShowMarginalNotes(!showMarginalNotes)}
            >
              <MessageSquare className="h-4 w-4 mr-1" />
              旁注 ({marginalNotes.length})
            </Button>
            
            {/* 发布按钮 */}
            <Button 
              size="sm"
              onClick={() => setShowPublishConfirm(true)}
              disabled={!content.trim()}
            >
              <Send className="h-4 w-4 mr-1" />
              发布
            </Button>
          </div>
          
          {/* 录制状态 */}
          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
            {isRecording ? (
              <div className="flex items-center gap-2 text-red-500">
                <Circle className="h-2 w-2 fill-current animate-pulse" />
                <span>录制中 {formatTime(recordingTime)}</span>
                <span>|</span>
                <span>{operationCount} 次操作</span>
              </div>
            ) : operationCount > 0 ? (
              <div className="flex items-center gap-2 text-green-500">
                <Check className="h-4 w-4" />
                <span>已录制 {operationCount} 次操作</span>
                <span>|</span>
                <span>总时长 {formatTime(recordingTime)}</span>
              </div>
            ) : (
              <span>开始写作以自动录制</span>
            )}
            
            <div className="ml-auto text-xs">

              {lastSaveTime && <span className="ml-2">上次保存: {lastSaveTime.toLocaleTimeString()}</span>}
            </div>
          </div>
        </div>
      </div>

      {/* 提示信息 */}
      {showAlert && (
        <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg shadow-lg ${
          alertType === 'error' ? 'bg-red-500 text-white' : 
          alertType === 'success' ? 'bg-green-500 text-white' : 
          'bg-blue-500 text-white'
        }`}>
          <div className="flex items-center gap-2">
            {alertType === 'error' && <AlertCircle className="h-4 w-4" />}
            {alertMessage}
          </div>
        </div>
      )}

      {/* 主内容 */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-0">
            {/* 题材提示 */}
            <div className="px-6 pt-6 pb-2">
              <Badge variant="outline" className="flex items-center gap-1 w-fit">
                {genreIcons[genre]}
                {genreLabels[genre]} · {genreDescriptions[genre]}
              </Badge>
            </div>
            
            {/* 小说章节面板 */}
            {genre === 'novel' && showChapterPanel && (
              <div className="px-6 pb-2">
                <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">章节管理</span>
                    <span className="text-xs text-muted-foreground">({chapters.length}章)</span>
                  </div>
                  
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={newChapterTitle}
                      onChange={(e) => setNewChapterTitle(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addChapter()}
                      placeholder="新章节标题..."
                      className="flex-1 px-3 py-1.5 rounded-md border bg-background text-sm"
                    />
                    <Button size="sm" onClick={addChapter}>添加</Button>
                    <Button size="sm" variant="outline" onClick={insertChapterDivider}>插入章节</Button>
                  </div>
                  
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {chapters.map((chapter, index) => (
                      <div 
                        key={chapter.id} 
                        className={`flex items-center gap-2 p-2 rounded-md cursor-pointer ${
                          currentChapterId === chapter.id ? 'bg-primary/10' : 'hover:bg-muted/50'
                        }`}
                        onClick={() => switchChapter(chapter.id)}
                      >
                        <span className="text-xs text-muted-foreground w-6">第{index + 1}章</span>
                        <span className="flex-1 text-sm truncate">{chapter.title}</span>
                        <button 
                          className="text-xs text-muted-foreground hover:text-red-500"
                          onClick={(e) => { e.stopPropagation(); deleteChapter(chapter.id); }}
                        >
                          删除
                        </button>
                      </div>
                    ))}
                    {chapters.length === 0 && (
                      <p className="text-xs text-muted-foreground/50">暂无章节，点击添加开始</p>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* 剧本场景面板 */}
            {genre === 'script' && showScriptPanel && (
              <div className="px-6 pb-2">
                <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">剧本工具</span>
                  </div>
                  
                  <div className="flex flex-wrap gap-2 mb-3">
                    <Button size="sm" variant="outline" onClick={() => insertAtCursor('\n【第一幕】\n')}>插入幕</Button>
                    <Button size="sm" variant="outline" onClick={() => insertAtCursor('\n【场景一】\n')}>插入场景</Button>
                    <Button size="sm" variant="outline" onClick={() => insertCharacterDialogue('')}>角色对话</Button>
                    <Button size="sm" variant="outline" onClick={insertStageDirection}>舞台指示</Button>
                  </div>
                  
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newSceneTitle}
                      onChange={(e) => setNewSceneTitle(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && insertSceneHeader(newSceneTitle)}
                      placeholder="输入场景标题后按回车插入..."
                      className="flex-1 px-3 py-1.5 rounded-md border bg-background text-sm"
                    />
                    <Button size="sm" onClick={() => insertSceneHeader(newSceneTitle)}>插入</Button>
                  </div>
                </div>
              </div>
            )}
            
            {/* 诗歌格式选择 */}
            {genre === 'poetry' && (
              <div className="px-6 pb-2">
                <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2 mb-2">
                    <Feather className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">诗歌格式</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {Object.entries(poetryTemplates).map(([key, template]) => (
                      <Button 
                        key={key}
                        size="sm" 
                        variant={poetryFormat === key ? "default" : "outline"}
                        onClick={() => applyPoetryTemplate(key)}
                      >
                        {template.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {/* 旁注面板 - 移到编辑区上方 */}
            {showMarginalNotes && (
              <div className="px-6 pb-2">
                <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2 mb-2">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">创作旁注</span>
                    <span className="text-xs text-muted-foreground">({marginalNotes.length})</span>
                  </div>
                  
                  <div className="space-y-1.5 mb-3 max-h-32 overflow-y-auto">
                    {marginalNotes.map((note, index) => (
                      <div key={index} className="flex items-start gap-2 text-sm">
                        <span className="text-muted-foreground shrink-0 text-xs">
                          [{formatTime(note.time)}]
                        </span>
                        <span className="text-muted-foreground/70">{note.content}</span>
                      </div>
                    ))}
                    
                    {marginalNotes.length === 0 && (
                      <p className="text-xs text-muted-foreground/50">暂无旁注</p>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={marginalNote}
                      onChange={(e) => setMarginalNote(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addMarginalNote()}
                      placeholder="记录创作灵感..."
                      className="flex-1 px-3 py-1.5 rounded-md border bg-background text-sm"
                    />
                    <Button size="sm" onClick={addMarginalNote}>
                      添加
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            {/* 快捷工具栏 */}
            <div className="px-6 pt-4 flex items-center justify-between border-b">
              <div className="flex items-center gap-1">
                {formatOptions.map((opt) => (
                  <Button
                    key={opt.label}
                    variant="ghost"
                    size="sm"
                    onClick={opt.action}
                    className="text-sm h-8 px-3"
                  >
                    {opt.label}
                  </Button>
                ))}
              </div>
              <div className="text-xs text-muted-foreground flex items-center gap-3">
                <span>{wordCount} 字</span>
                <span>{paragraphCount} 段</span>
                <span>约 {readingTime} 分钟</span>
              </div>
            </div>
            
            {/* 编辑器 */}
            <div className="relative">
              <textarea
                id="content-editor"
                ref={textareaRef}
                value={content}
                onChange={handleInput}
                onKeyDown={handleKeyDown}
                onPaste={handlePaste}
                placeholder="在此开始你的创作..."
                disabled={isPlaying}
                className="w-full min-h-[500px] p-6 bg-transparent border-0 outline-none resize-none font-serif text-lg leading-relaxed placeholder:text-muted-foreground/50"
                style={{ fontFamily: "'Noto Serif SC', 'Songti SC', serif" }}
              />
            </div>
          </CardContent>
        </Card>

        {/* 回放控制栏 */}
        {(isPlaying || replayProgress > 0) && (
          <Card className="mt-4">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Button variant="outline" size="icon" onClick={toggleReplayPause}>
                  {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                </Button>
                
                <Button variant="outline" size="icon" onClick={stopReplay}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
                
                <Button variant="ghost" size="icon" onClick={stepReplayBackward}>
                  <SkipBack className="h-4 w-4" />
                </Button>
                
                <div className="flex-1">
                  <Slider
                    value={[replayProgress]}
                    onValueChange={handleReplaySeek}
                    max={100}
                    step={0.1}
                  />
                </div>
                
                <Button variant="ghost" size="icon" onClick={stepReplayForward}>
                  <SkipForward className="h-4 w-4" />
                </Button>
                
                <Button variant="ghost" size="sm" onClick={cycleReplaySpeed}>
                  <Volume2 className="h-4 w-4 mr-1" />
                  {playbackSpeed}x
                </Button>
                
                <span className="text-sm text-muted-foreground font-mono min-w-[100px]">
                  {formatTime(currentReplayTime)} / {formatTime(recordingTime)}
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* 底部操作栏 */}
        <div className="mt-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* 回放按钮 */}
            {operationCount > 0 && !isPlaying && (
              <Button variant="outline" size="sm" onClick={startReplay}>
                <Play className="h-4 w-4 mr-1" />
                观看回放
              </Button>
            )}
          </div>
          
          <div className="text-sm text-muted-foreground flex items-center gap-4">
            <span>{wordCount} 字</span>
            <span>{paragraphCount} 段</span>
            <span>约 {readingTime} 分钟</span>
            {isRecording && <span className="text-primary">录制中: {formatTime(recordingTime)}</span>}
          </div>
        </div>
      </div>

      {/* 发布确认对话框 */}
      {showPublishConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
          <Card className="w-full max-w-md mx-4">
            <CardContent className="p-6">
              <h3 className="text-lg font-medium mb-4">确认发布</h3>
              <p className="text-muted-foreground mb-4">
                确定要发布「{title}」吗？
              </p>
              {/* 可见范围选择 */}
              <div className="mb-4">
                <label className="text-sm font-medium mb-2 block">可见范围</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setVisibility('public')}
                    className={`p-2 rounded-md text-sm border transition-colors ${
                      visibility === 'public' 
                        ? 'border-primary bg-primary/10 text-primary' 
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    公开
                  </button>
                  <button
                    type="button"
                    onClick={() => setVisibility('followers')}
                    className={`p-2 rounded-md text-sm border transition-colors ${
                      visibility === 'followers' 
                        ? 'border-primary bg-primary/10 text-primary' 
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    仅粉丝
                  </button>
                  <button
                    type="button"
                    onClick={() => setVisibility('private')}
                    className={`p-2 rounded-md text-sm border transition-colors ${
                      visibility === 'private' 
                        ? 'border-primary bg-primary/10 text-primary' 
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    私密
                  </button>
                </div>
              </div>
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setShowPublishConfirm(false)}
                >
                  取消
                </Button>
                <Button 
                  className="flex-1"
                  onClick={handlePublish}
                  disabled={isPublishing}
                >
                  {isPublishing ? '发布中...' : '确认发布'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
