'use client'

import { useState, useRef, useCallback, useEffect, useMemo } from 'react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { 
  Play, 
  Pause,
  RotateCcw,
  SkipBack,
  SkipForward,
  Volume2,
  X,
  Clock,
  Calendar,
} from 'lucide-react'

// ==================== 类型定义 ====================

type OperationType = 'input' | 'paste' | 'paste-truncated' | 'key' | 'snapshot'

interface Operation {
  t: number
  type: OperationType
  pos: number
  val: string
  data?: string
  key?: string
  length?: number
}

interface ReplayAction {
  t: number
  val: string
  pos: number
  delta?: string
  isDelete?: boolean
}

interface PlaybackPlayerProps {
  workId: string
  title: string
  content: string
  operations: Operation[]
  writingStartedAt?: string // ISO时间字符串
  writingDuration?: number   // 总写作时长（毫秒）
  onClose?: () => void
}

// ==================== 工具函数 ====================

const formatTimestamp = (ms: number) => {
  const totalSeconds = Math.floor(ms / 1000)
  const mins = Math.floor(totalSeconds / 60)
  const secs = totalSeconds % 60
  const millis = Math.floor(ms % 1000)
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${millis.toString().padStart(3, '0')}`
}

const formatDuration = (ms: number) => {
  const totalSeconds = Math.floor(ms / 1000)
  const hours = Math.floor(totalSeconds / 3600)
  const mins = Math.floor((totalSeconds % 3600) / 60)
  const secs = totalSeconds % 60
  if (hours > 0) {
    return `${hours}小时${mins}分钟`
  }
  if (mins > 0) {
    return `${mins}分钟${secs}秒`
  }
  return `${secs}秒`
}

const formatDateTime = (isoString?: string) => {
  if (!isoString) return ''
  const date = new Date(isoString)
  const year = date.getFullYear()
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  const hours = date.getHours().toString().padStart(2, '0')
  const minutes = date.getMinutes().toString().padStart(2, '0')
  return `${year}-${month}-${day} ${hours}:${minutes}`
}

// ==================== 组件 ====================

export function PlaybackPlayer({ 
  workId, 
  title, 
  content, 
  operations,
  writingStartedAt,
  writingDuration,
  onClose 
}: PlaybackPlayerProps) {
  // 状态
  const [isPlaying, setIsPlaying] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [currentContent, setCurrentContent] = useState('')
  const [progress, setProgress] = useState(0)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [totalOps, setTotalOps] = useState(0)
  const [currentTime, setCurrentTime] = useState(0)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)
  const [isVisible, setIsVisible] = useState(true)
  const [playbackTime, setPlaybackTime] = useState(0) // 回放已播放时长
  
  const speedOptions = [1, 2, 4, 8]
  
  // Refs
  const replayOpsRef = useRef<ReplayAction[]>([])
  const replayIndexRef = useRef(0)
  const timerRef = useRef<number | null>(null)
  const playbackSpeedRef = useRef(1)
  const isPlayingRef = useRef(false)
  const isPausedRef = useRef(false)
  const startTimestampRef = useRef(0)
  const editorRef = useRef<HTMLDivElement>(null)
  const executeStepRef = useRef<() => void>(() => {})
  
  // 总写作时长
  const totalDuration = useMemo(() => {
    if (writingDuration && writingDuration > 0) {
      return writingDuration
    }
    if (operations.length > 0) {
      return operations[operations.length - 1].t
    }
    return 0
  }, [writingDuration, operations])
  
  // 构建回放序列
  const buildReplayOps = useCallback((ops: Operation[]): ReplayAction[] => {
    if (ops.length === 0) return []
    
    const replayOps: ReplayAction[] = []
    let lastVal = ''
    
    for (const op of ops) {
      if (op.val !== undefined) {
        let delta = ''
        let isDelete = false
        
        if (op.val.length > lastVal.length) {
          delta = op.val.slice(lastVal.length)
        } else if (op.val.length < lastVal.length) {
          delta = lastVal.slice(op.val.length)
          isDelete = true
        }
        
        replayOps.push({
          t: op.t,
          val: op.val,
          pos: op.pos,
          delta,
          isDelete
        })
        
        lastVal = op.val
      }
    }
    
    return replayOps
  }, [])
  
  // 从正文生成回放
  const generateReplayFromContent = useCallback((text: string): ReplayAction[] => {
    if (!text) return []
    
    const replayOps: ReplayAction[] = []
    let currentVal = ''
    const estimatedInterval = 200
    
    for (let i = 0; i < text.length; i++) {
      currentVal += text[i]
      replayOps.push({
        t: i * estimatedInterval,
        val: currentVal,
        pos: i + 1,
        delta: text[i],
        isDelete: false
      })
    }
    
    return replayOps
  }, [])
  
  // 渲染内容（无光标）
  const renderContent = useCallback((text: string) => {
    return <span className="whitespace-pre-wrap">{text || ''}</span>
  }, [])
  
  // 执行回放步骤
  const executeStep = useCallback(() => {
    if (!isPlayingRef.current || isPausedRef.current) return
    
    const ops = replayOpsRef.current
    const index = replayIndexRef.current
    
    if (index >= ops.length) {
      // 回放结束
      const lastOp = ops[ops.length - 1]
      if (lastOp) {
        setCurrentContent(lastOp.val)
      }
      
      setIsPlaying(false)
      setIsPaused(false)
      isPlayingRef.current = false
      return
    }
    
    const currentOp = ops[index]
    const nextOp = ops[index + 1]
    
    // 更新内容
    setCurrentContent(currentOp.val)
    
    // 更新时间
    setCurrentTime(currentOp.t)
    
    // 更新进度
    const progressVal = ((index + 1) / ops.length) * 100
    setProgress(progressVal)
    setCurrentIndex(index + 1)
    
    replayIndexRef.current = index + 1
    
    // 计算延迟（真实时间间隔）
    let delay = 100
    if (nextOp) {
      const realInterval = nextOp.t - currentOp.t
      const adjustedInterval = realInterval / playbackSpeedRef.current
      delay = Math.max(10, Math.min(adjustedInterval, 1000 / playbackSpeedRef.current))
    }
    
    timerRef.current = window.setTimeout(() => executeStepRef.current(), delay)
  }, [])
  
  // 更新ref以指向最新函数
  useEffect(() => {
    executeStepRef.current = executeStep
  }, [executeStep])
  
  // 开始回放
  const startPlayback = useCallback(() => {
    let ops: ReplayAction[]
    
    if (operations.length > 0) {
      ops = buildReplayOps(operations)
    } else if (content) {
      ops = generateReplayFromContent(content)
    } else {
      return
    }
    
    if (ops.length === 0) return
    
    replayOpsRef.current = ops
    replayIndexRef.current = 0
    isPlayingRef.current = true
    isPausedRef.current = false
    playbackSpeedRef.current = playbackSpeed
    startTimestampRef.current = performance.now()
    
    setIsPlaying(true)
    setIsPaused(false)
    setProgress(0)
    setCurrentIndex(0)
    setTotalOps(ops.length)
    setCurrentContent('')
    
    executeStep()
  }, [operations, content, buildReplayOps, generateReplayFromContent, playbackSpeed, executeStep])
  
  // 停止回放
  const stopPlayback = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current)
      timerRef.current = null
    }
    
    isPlayingRef.current = false
    isPausedRef.current = false
    replayIndexRef.current = 0
    
    setIsPlaying(false)
    setIsPaused(false)
    setProgress(0)
    setCurrentIndex(0)
    setCurrentContent('')
  }, [])
  
  // 暂停/继续
  const togglePause = useCallback(() => {
    isPausedRef.current = !isPausedRef.current
    setIsPaused(isPausedRef.current)
    
    if (!isPausedRef.current) {
      executeStep()
    }
  }, [executeStep])
  
  // 调整速度
  const cycleSpeed = useCallback(() => {
    const currentIndex = speedOptions.indexOf(playbackSpeed)
    const nextIndex = (currentIndex + 1) % speedOptions.length
    const newSpeed = speedOptions[nextIndex]
    playbackSpeedRef.current = newSpeed
    setPlaybackSpeed(newSpeed)
  }, [playbackSpeed])
  
  // 跳转
  const handleSeek = useCallback((value: number[]) => {
    const pct = value[0]
    setProgress(pct)
    
    const ops = replayOpsRef.current
    if (ops.length === 0) return
    
    const index = Math.floor((pct / 100) * ops.length)
    replayIndexRef.current = index
    
    const op = ops[index]
    if (op) {
      setCurrentContent(op.val)
      setCurrentTime(op.t)
    }
    setCurrentIndex(index)
  }, [])
  
  // 步进
  const stepForward = useCallback(() => {
    const ops = replayOpsRef.current
    let index = replayIndexRef.current
    
    if (index < ops.length) {
      const op = ops[index]
      setCurrentContent(op.val)
      setCurrentTime(op.t)
      
      const progressVal = ((index + 1) / ops.length) * 100
      setProgress(progressVal)
      setCurrentIndex(index + 1)
      replayIndexRef.current = index + 1
    }
  }, [])
  
  const stepBackward = useCallback(() => {
    let index = replayIndexRef.current - 1
    if (index < 0) index = 0
    
    const ops = replayOpsRef.current
    const op = ops[index]
    if (op) {
      setCurrentContent(op.val)
      setCurrentTime(op.t)
      
      const progressVal = ((index + 1) / ops.length) * 100
      setProgress(progressVal)
      setCurrentIndex(index + 1)
      replayIndexRef.current = index
    }
  }, [])
  
  // 关闭
  const handleClose = useCallback(() => {
    stopPlayback()
    setIsVisible(false)
    setTimeout(() => onClose?.(), 300)
  }, [stopPlayback, onClose])
  
  // 清理
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current)
    }
  }, [])
  
  // 自动开始回放
  useEffect(() => {
    const timer = setTimeout(() => {
      startPlayback()
    }, 500)
    
    return () => clearTimeout(timer)
  }, [startPlayback])
  
  // 更新播放时长
  useEffect(() => {
    if (!isPlaying) return
    const interval = setInterval(() => {
      setPlaybackTime(prev => prev + 100)
    }, 100)
    return () => clearInterval(interval)
  }, [isPlaying])
  
  if (!isVisible) return null

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur flex flex-col">
      {/* 顶部栏 */}
      <div className="border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <h2 className="font-medium">
            「{title}」写作过程回放
          </h2>
          <span className="text-sm text-muted-foreground font-mono">
            {formatTimestamp(currentTime)}
          </span>
        </div>
        
        <Button variant="ghost" size="icon" onClick={handleClose}>
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      {/* 写作信息栏 */}
      <div className="border-b px-4 py-2 bg-muted/30">
        <div className="max-w-3xl mx-auto flex items-center justify-center gap-8 text-sm text-muted-foreground">
          {writingStartedAt && (
            <div className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              <span>开始于 {formatDateTime(writingStartedAt)}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <Clock className="h-4 w-4" />
            <span>总写作时长 {formatDuration(totalDuration)}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span>总字数 {content.length}</span>
          </div>
        </div>
      </div>
      
      {/* 控制栏 */}
      <div className="border-b px-4 py-3">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <Button variant="outline" size="icon" onClick={togglePause}>
            {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
          </Button>
          
          <Button variant="outline" size="icon" onClick={stopPlayback}>
            <RotateCcw className="h-4 w-4" />
          </Button>
          
          <Button variant="ghost" size="icon" onClick={stepBackward}>
            <SkipBack className="h-4 w-4" />
          </Button>
          
          <div className="flex-1">
            <Slider
              value={[progress]}
              onValueChange={handleSeek}
              max={100}
              step={0.1}
            />
          </div>
          
          <Button variant="ghost" size="icon" onClick={stepForward}>
            <SkipForward className="h-4 w-4" />
          </Button>
          
          <Button variant="ghost" size="sm" onClick={cycleSpeed}>
            <Volume2 className="h-4 w-4 mr-1" />
            {playbackSpeed}x
          </Button>
          
          <span className="text-sm text-muted-foreground font-mono min-w-[140px]">
            {currentIndex}/{totalOps} | {progress.toFixed(1)}%
          </span>
        </div>
      </div>
      
      {/* 回放内容 */}
      <div className="flex-1 overflow-auto p-8">
        <div className="max-w-2xl mx-auto">
          <div 
            ref={editorRef}
            className="relative min-h-[400px] p-6 bg-card/50 rounded-lg border"
          >
            {/* 文本内容 - 无光标 */}
            <div 
              className="font-serif text-lg leading-relaxed"
              style={{ fontFamily: "'Noto Serif SC', 'Songti SC', serif" }}
            >
              {renderContent(currentContent || '回放即将开始...')}
            </div>
          </div>
          
          {/* 统计信息 */}
          <div className="mt-4 flex items-center justify-center gap-6 text-sm text-muted-foreground">
            <span>字数：{currentContent.length}</span>
            <span>操作：{currentIndex}</span>
            <span>进度：{formatTimestamp(currentTime)} / {formatTimestamp(totalDuration)}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
