'use client'

import { useState, useEffect } from 'react'
import { Bell, Heart, Star, UserPlus, MessageCircle, X } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface Notification {
  id: string
  type: 'like' | 'favorite' | 'follow' | 'comment'
  workId?: string
  workTitle?: string
  fromUser: string
  fromUserId: string
  content?: string
  createdAt: string
  read: boolean
}

interface NotificationBellProps {
  className?: string
}

export function NotificationBell({ className }: NotificationBellProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [showPanel, setShowPanel] = useState(false)
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    loadNotifications()
    
    // 监听通知更新
    const handleStorage = () => loadNotifications()
    window.addEventListener('storage', handleStorage)
    window.addEventListener('wenhen_notification_update', handleStorage)
    
    return () => {
      window.removeEventListener('storage', handleStorage)
      window.removeEventListener('wenhen_notification_update', handleStorage)
    }
  }, [])

  const loadNotifications = () => {
    const stored = JSON.parse(localStorage.getItem('wenhen_notifications') || '[]')
    setNotifications(stored)
  }

  const unreadCount = notifications.filter(n => !n.read).length

  const handleToggle = () => {
    setIsOpen(!isOpen)
    if (!isOpen) {
      // 标记所有已读
      const updated = notifications.map(n => ({ ...n, read: true }))
      localStorage.setItem('wenhen_notifications', JSON.stringify(updated))
      setNotifications(updated)
    }
  }

  const handleClear = () => {
    localStorage.setItem('wenhen_notifications', JSON.stringify([]))
    setNotifications([])
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart className="h-4 w-4 text-red-500" />
      case 'favorite': return <Star className="h-4 w-4 text-yellow-500" />
      case 'follow': return <UserPlus className="h-4 w-4 text-green-500" />
      case 'comment': return <MessageCircle className="h-4 w-4 text-blue-500" />
      default: return <Bell className="h-4 w-4" />
    }
  }

  const getMessage = (notification: Notification) => {
    switch (notification.type) {
      case 'like': return `赞了你的作品「${notification.workTitle}」`
      case 'favorite': return `收藏了你的作品「${notification.workTitle}」`
      case 'follow': return `关注了你`
      case 'comment': return `评论了你的作品「${notification.workTitle}」：${notification.content}`
      default: return '有新消息'
    }
  }

  return (
    <div className={`relative ${className}`}>
      <button
        onClick={handleToggle}
        className="relative p-2 rounded-full hover:bg-muted transition-colors"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* 通知面板 */}
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 top-full mt-2 w-80 bg-background border rounded-lg shadow-lg z-50 max-h-96 overflow-hidden flex flex-col">
            {/* 头部 */}
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <h3 className="font-medium">消息通知</h3>
              <div className="flex items-center gap-2">
                {notifications.length > 0 && (
                  <button 
                    onClick={handleClear}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    清空
                  </button>
                )}
                <button 
                  onClick={() => setIsOpen(false)}
                  className="text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* 通知列表 */}
            <div className="flex-1 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="py-8 text-center text-muted-foreground text-sm">
                  暂无消息通知
                </div>
              ) : (
                <div className="divide-y">
                  {notifications.map((notification) => (
                    <a
                      key={notification.id}
                      href={notification.workId ? `/read/${notification.workId}` : '#'}
                      className="block px-4 py-3 hover:bg-muted/50 transition-colors"
                      onClick={() => setIsOpen(false)}
                    >
                      <div className="flex items-start gap-3">
                        <div className="mt-1">
                          {getIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">
                            <span className="font-medium">{notification.fromUser}</span>
                            {' '}
                            {getMessage(notification)}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(notification.createdAt).toLocaleDateString()} {new Date(notification.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
