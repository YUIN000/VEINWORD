'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { NotificationBell } from './notification-bell'
import { 
  Moon, 
  Sun, 
  Feather, 
  PenSquare, 
  Library, 
  Home,
  User,
  Search,
  Settings,
  LogOut,
  Menu,
  X,

} from 'lucide-react'
import { useAuth } from '@/contexts/auth-context'

export function MainNav() {
  const pathname = usePathname()
  const { user, signOut } = useAuth()
  const isAuthenticated = !!user
  const [isDark, setIsDark] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false)

  // 监听滚动
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // 主题切换
  const toggleTheme = () => {
    const html = document.documentElement
    if (isDark) {
      html.classList.remove('dark')
      localStorage.setItem('theme', 'light')
    } else {
      html.classList.add('dark')
      localStorage.setItem('theme', 'dark')
    }
    setIsDark(!isDark)
  }

  // 初始化主题
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme')
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark')
      setIsDark(true)
    }
  }, [])

  // 导航链接
  const navLinks = [
    { href: '/', label: '首页', icon: Home },
    { href: '/search', label: '搜索', icon: Search },
  ]

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled 
          ? "bg-background/95 backdrop-blur-md shadow-sm border-b" 
          : "bg-transparent"
      )}
    >
      <nav className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
              <Feather className="h-5 w-5 text-accent" />
            </div>
            <div>
              <span className="font-serif font-bold text-lg tracking-tight">VEINWORD</span>
              <span className="text-xs text-muted-foreground ml-2 hidden sm:inline">文字落下的痕迹</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon
              const isActive = pathname === link.href
              return (
                <Link key={link.href} href={link.href}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className={cn(
                      "gap-2",
                      isActive && "bg-accent/10 text-accent"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {link.label}
                  </Button>
                </Link>
              )
            })}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="relative"
            >
              <Sun className={cn(
                "h-5 w-5 transition-all duration-300",
                isDark ? "opacity-0 rotate-90 scale-0" : "opacity-100 rotate-0 scale-100"
              )} />
              <Moon className={cn(
                "absolute h-5 w-5 transition-all duration-300",
                isDark ? "opacity-100 rotate-0 scale-100" : "opacity-0 -rotate-90 scale-0"
              )} />
            </Button>

            {isAuthenticated ? (
              <>
                {/* 写文章按钮 */}
                <Link href="/write">
                  <Button size="sm" className="gap-2">
                    <PenSquare className="h-4 w-4" />
                    <span className="hidden sm:inline">创作</span>
                  </Button>
                </Link>

                {/* 通知 */}
                {isAuthenticated && (
                  <NotificationBell />
                )}

                {/* 用户菜单 */}
                <div className="relative">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full"
                    onClick={() => {
                      setIsUserMenuOpen(!isUserMenuOpen)
                      // 关闭移动端菜单
                      setIsMobileMenuOpen(false)
                    }}
                  >
                    <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                      <span className="text-sm font-medium text-accent">
                        {user?.username?.charAt(0).toUpperCase() || 'U'}
                      </span>
                    </div>
                  </Button>

                  {/* 下拉菜单 */}
                  <div className={cn(
                    "absolute right-0 top-full mt-2 w-56 py-2 bg-card/95 backdrop-blur-md rounded-lg shadow-xl border transition-all duration-200 z-[60]",
                    isUserMenuOpen ? "opacity-100 visible" : "opacity-0 invisible"
                  )}>
                    <div className="px-4 py-2 border-b border-border">
                      <p className="font-medium">{user?.username}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                    
                    <div className="py-1">
                      <Link href="/profile" onClick={() => setIsUserMenuOpen(false)}>
                        <Button variant="ghost" className="w-full justify-start gap-2 h-auto py-2">
                          <User className="h-4 w-4" />
                          个人主页
                        </Button>
                      </Link>
                      <Link href="/settings" onClick={() => setIsUserMenuOpen(false)}>
                        <Button variant="ghost" className="w-full justify-start gap-2 h-auto py-2">
                          <Settings className="h-4 w-4" />
                          设置
                        </Button>
                      </Link>
                    </div>

                    <div className="border-t border-border pt-1">
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start gap-2 h-auto py-2 text-red-500 hover:text-red-500 hover:bg-red-500/10"
                        onClick={() => {
                          setIsUserMenuOpen(false)
                          signOut()
                        }}
                      >
                        <LogOut className="h-4 w-4" />
                        退出登录
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="ghost" size="sm">登录</Button>
                </Link>
                <Link href="/register">
                  <Button size="sm">注册</Button>
                </Link>
              </>
            )}

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => {
                setIsMobileMenuOpen(!isMobileMenuOpen)
                setIsUserMenuOpen(false)
              }}
            >
              {isMobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border bg-background">
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => {
                const Icon = link.icon
                const isActive = pathname === link.href
                return (
                  <Link key={link.href} href={link.href} onClick={() => setIsMobileMenuOpen(false)}>
                    <Button
                      variant={isActive ? 'secondary' : 'ghost'}
                      className="w-full justify-start gap-2"
                    >
                      <Icon className="h-4 w-4" />
                      {link.label}
                    </Button>
                  </Link>
                )
              })}
            </div>
          </div>
        )}
      </nav>
    </header>
  )
}
