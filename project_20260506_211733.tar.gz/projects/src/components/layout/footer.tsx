'use client'

import Link from 'next/link'
import { Feather, Heart } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Logo & Slogan */}
          <div className="flex flex-col items-center md:items-start gap-2">
            <Link href="/" className="flex items-center gap-2">
              <Feather className="h-6 w-6 text-accent" />
              <span className="text-lg font-serif font-semibold text-foreground">
                VEINWORD
              </span>
            </Link>
            <p className="text-sm text-muted-foreground font-serif italic">
              文字落下的痕迹
            </p>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm">
            <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
              关于我们
            </Link>
            <Link href="/guidelines" className="text-muted-foreground hover:text-foreground transition-colors">
              创作公约
            </Link>
            <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
              隐私政策
            </Link>
            <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
              服务条款
            </Link>
          </div>

          {/* Copyright */}
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <span>© 2026 VEINWORD</span>
          </div>
        </div>

        {/* Decorative Divider */}
        <div className="mt-6 flex items-center justify-center gap-2 text-muted-foreground/30">
          <span className="h-px w-12 bg-current" />
          <span className="text-xs font-serif">庚续文脉，以笔为痕</span>
          <span className="h-px w-12 bg-current" />
        </div>
      </div>
    </footer>
  )
}
