'use client'

import { Noto_Serif_SC } from 'next/font/google'

const notoSerifSC = Noto_Serif_SC({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-serif-sc',
  display: 'swap',
})

export function FontLoader() {
  return (
    <style jsx global>{`
      :root {
        --font-serif: var(--font-serif-sc), 'Noto Serif SC', Georgia, serif;
      }
    `}</style>
  )
}
