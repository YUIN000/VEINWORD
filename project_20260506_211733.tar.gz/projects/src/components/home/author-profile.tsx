'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { createClient } from '@/storage/database/supabase-client-browser'
import { useAuth } from '@/contexts/auth-context'
import { cn } from '@/lib/utils'
import { 
  Feather, 
  BookOpen, 
  Play, 
  Clock, 
  Eye,
  Heart,
  Calendar,
  User,
  Loader2,
  ArrowLeft,
  Star,
  BookMarked,
  Plus,
  Check,
} from 'lucide-react'

type Genre = 'poetry' | 'essay' | 'story' | 'novel' | 'letter' | 'script'

interface Work {
  id: string
  title: string
  genre: Genre
  excerpt: string
  content?: string
  author: string
  authorId: string
  wordCount: number
  playCount: number
  likeCount: number
  favoriteCount?: number
  viewCount?: number
  updatedAt: string
  createdAt: string
  hasPlayback: boolean
  isFeatured: boolean
  status: 'draft' | 'published' | 'private'
  tags: string[]
}

interface AuthorProfileData {
  id: string
  username: string
  bio: string
  avatar_url?: string
  created_at: string
}

const genreLabels: Record<Genre, string> = {
  poetry: '诗歌',
  essay: '随笔',
  story: '短故事',
  novel: '小说',
  letter: '书信',
  script: '剧本',
}

interface AuthorProfileProps {
  authorId: string
}

export function AuthorProfile({ authorId }: AuthorProfileProps) {
  const router = useRouter()
  const { user, profile } = useAuth()
  const [author, setAuthor] = useState<AuthorProfileData | null>(null)
  const [works, setWorks] = useState<Work[]>([])
  const [loading, setLoading] = useState(true)
  const [isFollowing, setIsFollowing] = useState(false)
  const [followingLoading, setFollowingLoading] = useState(false)
  const [stats, setStats] = useState({
    totalWorks: 0,
    totalWords: 0,
    totalPlays: 0,
  })

  // 加载作者信息和作品
  const loadAuthorData = useCallback(async () => {
    const supabase = createClient()
    
    try {
      // 获取作者信息
      const { data: authorData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authorId)
        .single()
      
      if (authorData) {
        setAuthor(authorData)
      }
      
      // 获取作者作品
      const { data: worksData } = await supabase
        .from('works')
        .select('*')
        .eq('user_id', authorId)
        .eq('status', 'published')
        .order('updated_at', { ascending: false })
      
      if (worksData) {
        const mappedWorks = worksData.map((w: any) => ({
          id: w.id,
          title: w.title,
          genre: w.genre as Genre,
          excerpt: w.content?.substring(0, 100) + (w.content?.length > 100 ? '...' : ''),
          author: authorData?.username || '佚名',
          authorId: w.user_id,
          wordCount: w.word_count || 0,
          playCount: w.play_count || 0,
          likeCount: w.like_count || 0,
          favoriteCount: w.favorite_count || 0,
          viewCount: w.view_count || 0,
          updatedAt: w.updated_at,
          createdAt: w.created_at,
          hasPlayback: Array.isArray(w.operations) && w.operations.length > 0,
          isFeatured: w.is_featured || false,
          status: w.status || 'published',
          tags: w.tags || [],
        }))
        
        setWorks(mappedWorks)
        
        // 计算统计
        const totalWords = mappedWorks.reduce((sum, w) => sum + w.wordCount, 0)
        const totalPlays = mappedWorks.reduce((sum, w) => sum + w.playCount, 0)
        setStats({
          totalWorks: mappedWorks.length,
          totalWords,
          totalPlays,
        })
      }
    } catch (error) {
      console.error('Failed to load author data:', error)
    } finally {
      setLoading(false)
    }
  }, [authorId])

  useEffect(() => {
    loadAuthorData()
  }, [loadAuthorData])

  // 检查是否已关注
  useEffect(() => {
    if (!user || !profile) return
    
    // 从 localStorage 读取关注列表
    const followedAuthors = JSON.parse(localStorage.getItem(`wenhen_following_${user.id}`) || '[]')
    setIsFollowing(followedAuthors.includes(authorId))
  }, [user, profile, authorId])

  // 关注/取消关注作者
  const handleFollow = async () => {
    if (!user || !profile) {
      router.push('/login')
      return
    }
    
    setFollowingLoading(true)
    
    try {
      const storageKey = `wenhen_following_${user.id}`
      const followedAuthors = JSON.parse(localStorage.getItem(storageKey) || '[]')
      
      if (isFollowing) {
        // 取消关注
        const updated = followedAuthors.filter((id: string) => id !== authorId)
        localStorage.setItem(storageKey, JSON.stringify(updated))
        setIsFollowing(false)
      } else {
        // 关注
        followedAuthors.push(authorId)
        localStorage.setItem(storageKey, JSON.stringify(followedAuthors))
        setIsFollowing(true)
        
        // 发送通知
        const notifications = JSON.parse(localStorage.getItem(`wenhen_notifications_${authorId}`) || '[]')
        notifications.unshift({
          id: Date.now().toString(),
          type: 'follow',
          from: profile.username,
          fromId: user.id,
          avatar: profile.avatar_url || '',
          message: '关注了你',
          createdAt: new Date().toISOString(),
          read: false,
        })
        localStorage.setItem(`wenhen_notifications_${authorId}`, JSON.stringify(notifications))
      }
    } catch (error) {
      console.error('关注失败:', error)
    } finally {
      setFollowingLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!author) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <User className="h-16 w-16 text-muted-foreground" />
        <h1 className="text-2xl font-serif">作者不存在</h1>
        <Button onClick={() => router.push('/')}>返回首页</Button>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50">
        <div className="container mx-auto px-4 py-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => router.back()}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            返回
          </Button>
          
          <div className="flex items-start gap-6">
            {/* Avatar */}
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-accent/20 to-accent/5 border-2 border-accent/30 flex items-center justify-center overflow-hidden">
              {author.avatar_url ? (
                <img src={author.avatar_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <User className="h-10 w-10 text-accent" />
              )}
            </div>
            
            {/* Info */}
            <div className="flex-1">
              <div className="flex items-center gap-4 mb-2">
                <h1 className="text-2xl font-serif font-bold">@{author.username}</h1>
                {user && user.id !== authorId && (
                  <Button
                    variant={isFollowing ? 'outline' : 'default'}
                    size="sm"
                    onClick={handleFollow}
                    disabled={followingLoading}
                    className="ml-auto"
                  >
                    {followingLoading ? (
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    ) : isFollowing ? (
                      <>
                        <Check className="h-4 w-4 mr-1" />
                        已关注
                      </>
                    ) : (
                      <>
                        <Plus className="h-4 w-4 mr-1" />
                        关注
                      </>
                    )}
                  </Button>
                )}
              </div>
              {author.bio && (
                <p className="text-muted-foreground mb-4">{author.bio}</p>
              )}
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  加入于 {new Date(author.created_at).toLocaleDateString('zh-CN')}
                </span>
              </div>
            </div>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="bg-card rounded-lg p-4 text-center border border-border/50">
              <div className="text-2xl font-serif font-bold text-accent">{stats.totalWorks}</div>
              <div className="text-sm text-muted-foreground">作品</div>
            </div>
            <div className="bg-card rounded-lg p-4 text-center border border-border/50">
              <div className="text-2xl font-serif font-bold text-accent">{stats.totalWords.toLocaleString()}</div>
              <div className="text-sm text-muted-foreground">字数</div>
            </div>
            <div className="bg-card rounded-lg p-4 text-center border border-border/50">
              <div className="text-2xl font-serif font-bold text-accent">{stats.totalPlays.toLocaleString()}</div>
              <div className="text-sm text-muted-foreground">阅读</div>
            </div>
          </div>
        </div>
      </header>

      {/* Works */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-serif font-semibold">作品列表</h2>
          <Badge variant="secondary">{works.length} 篇</Badge>
        </div>

        {works.length === 0 ? (
          <Card className="paper-texture">
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-serif mb-2">暂无作品</h3>
              <p className="text-muted-foreground text-sm">作者还没有发布任何作品</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {works.map((work) => (
              <Link key={work.id} href={`/read/${work.id}`}>
                <Card className="paper-texture hover:shadow-lg transition-all duration-300 group h-full cursor-pointer border-border/50 hover:border-accent/30">
                  <CardContent className="p-5">
                    {/* Genre Badge */}
                    <div className="mb-3">
                      <Badge variant="outline" className="text-xs font-normal">
                        {genreLabels[work.genre]}
                      </Badge>
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-serif font-semibold mb-2 group-hover:text-accent transition-colors line-clamp-1">
                      {work.title}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4 font-serif leading-relaxed">
                      {work.excerpt}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-3 border-t border-border/50">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Eye className="h-3 w-3" />
                        <span>{work.playCount}</span>
                      </div>
                      
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Heart className="h-3 w-3" />
                          <span>{work.likeCount}</span>
                        </span>
                        {work.hasPlayback && (
                          <span className="flex items-center gap-1 text-accent/70">
                            <Play className="h-3 w-3" />
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
