'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  Star, 
  Eye, 
  BookOpen, 
  Clock,
  Play,
  Loader2,
  User,
  ChevronRight,
  Feather,
  Bookmark,
  BookmarkCheck,
  Search,
  PenSquare,
  PlayCircle,
  Sparkles,
  Moon,
  Sun,
  Shield,
  Settings
} from 'lucide-react'
import { cn } from '@/lib/utils'

// 题材类型
type Genre = 'poetry' | 'essay' | 'short_story' | 'novel' | 'letter' | 'script'

const genreLabels: Record<Genre, string> = {
  poetry: '诗歌',
  essay: '随笔',
  short_story: '短故事',
  novel: '小说',
  letter: '书信',
  script: '剧本',
}

// 作品类型
interface Work {
  id: string
  title: string
  excerpt: string
  genre: Genre
  author: string
  authorId: string
  wordCount: number
  playCount: number
  likeCount: number
  favoriteCount: number
  updatedAt: string
  hasPlayback: boolean
  tags: string[]
}

// 模拟推荐作品
const mockFeaturedWorks: Work[] = [
  {
    id: '1',
    title: '春江花月夜',
    excerpt: '春江潮水连海平，海上明月共潮生。滟滟随波千万里，何处春江无月明！',
    genre: 'poetry',
    author: '张若虚',
    authorId: '1',
    wordCount: 252,
    playCount: 12580,
    likeCount: 856,
    favoriteCount: 234,
    updatedAt: '2024-03-15',
    hasPlayback: true,
    tags: ['唐诗', '夜景', '抒情'],
  },
  {
    id: '2',
    title: '雨巷',
    excerpt: '撑着油纸伞，独自彷徨在悠长、悠长又寂寥的雨巷，我希望逢着一个丁香一样地结着愁怨的姑娘。',
    genre: 'poetry',
    author: '戴望舒',
    authorId: '2',
    wordCount: 186,
    playCount: 8920,
    likeCount: 623,
    favoriteCount: 189,
    updatedAt: '2024-03-10',
    hasPlayback: false,
    tags: ['现代诗', '雨巷', '姑娘'],
  },
  {
    id: '3',
    title: '那个夏天的记忆',
    excerpt: '那年夏天，我遇见了她。她穿着白色的连衣裙，在阳光下笑得像朵花。',
    genre: 'short_story',
    author: '小城故事',
    authorId: '3',
    wordCount: 3560,
    playCount: 4520,
    likeCount: 312,
    favoriteCount: 98,
    updatedAt: '2024-02-28',
    hasPlayback: true,
    tags: ['青春', '爱情', '夏天'],
  },
  {
    id: '4',
    title: '致青春',
    excerpt: '青春是一本太仓促的书，我们含着泪，一读再读。',
    genre: 'essay',
    author: '追梦人',
    authorId: '4',
    wordCount: 1250,
    playCount: 6780,
    likeCount: 445,
    favoriteCount: 156,
    updatedAt: '2024-02-20',
    hasPlayback: true,
    tags: ['青春', '感悟', '成长'],
  },
]

// 题材统计
const genreStats = [
  { genre: 'poetry', label: '诗歌', count: 1234, color: 'from-amber-500 to-orange-500' },
  { genre: 'essay', label: '随笔', count: 2345, color: 'from-emerald-500 to-teal-500' },
  { genre: 'short_story', label: '短故事', count: 1567, color: 'from-blue-500 to-cyan-500' },
  { genre: 'novel', label: '小说', count: 890, color: 'from-purple-500 to-pink-500' },
  { genre: 'letter', label: '书信', count: 456, color: 'from-rose-500 to-red-500' },
  { genre: 'script', label: '剧本', count: 234, color: 'from-indigo-500 to-blue-500' },
]

// 数字格式化
function formatNumber(num: number | undefined | null): string {
  if (num == null) return '0'
  if (num >= 10000) {
    return (num / 10000).toFixed(1) + 'w'
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'k'
  }
  return num.toString()
}

// 日期格式化
function formatDate(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  
  if (days === 0) return '今天'
  if (days === 1) return '昨天'
  if (days < 7) return `${days}天前`
  if (days < 30) return `${Math.floor(days / 7)}周前`
  return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })
}

// 特色作品卡片
function FeaturedWorkCard({ 
  work, 
  onLike, 
  onFavorite,
  isLiked,
  isFavorited
}: { 
  work: Work
  onLike: (id: string, liked: boolean) => void
  onFavorite: (id: string, favorited: boolean) => void
  isLiked: boolean
  isFavorited: boolean
}) {
  const router = useRouter()
  
  return (
    <Link href={`/read/${work.id}`}>
      <Card className="group overflow-hidden hover:shadow-xl transition-all duration-500">
        <div className="relative">
          {/* 背景装饰 */}
          <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-accent/5" />
          
          <CardContent className="relative p-6">
            {/* 题材标签 */}
            <div className="flex items-center justify-between mb-4">
              <Badge 
                variant="outline" 
                className="genre-tag font-medium"
              >
                {genreLabels[work.genre]}
              </Badge>
            </div>

            {/* 标题 */}
            <h3 className="text-xl font-serif font-bold mb-3 group-hover:text-accent transition-colors line-clamp-1">
              {work.title}
            </h3>

            {/* 摘要 */}
            <p className="text-sm text-muted-foreground line-clamp-3 mb-4 font-serif leading-relaxed">
              {work.excerpt}
            </p>

            {/* 标签 */}
            {work.tags.length > 0 && (
              <div className="flex gap-2 mb-4">
                {work.tags.slice(0, 3).map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}

            {/* 作者和统计 */}
            <div className="flex items-center justify-between pt-4 border-t border-border/50">
              <button
                onClick={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  router.push(`/author/${work.authorId}`)
                }}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-accent"
              >
                <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center">
                  <User className="h-3 w-3 text-accent" />
                </div>
                <span>{work.author}</span>
              </button>
              
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <BookOpen className="h-3 w-3" />
                  {formatNumber(work.wordCount)}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="h-3 w-3" />
                  {formatNumber(work.playCount)}
                </span>
                <span className="flex items-center gap-1">
                  <Star className="h-3 w-3" />
                  {formatNumber(work.likeCount)}
                </span>
              </div>
            </div>

            {/* 操作按钮 */}
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/30">
              <button
                onClick={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  onLike(work.id, !isLiked)
                }}
                className={cn(
                  "flex items-center gap-1 text-sm px-3 py-1.5 rounded-full transition-colors",
                  isLiked 
                    ? "bg-red-500/10 text-red-500" 
                    : "bg-muted hover:bg-red-500/10 hover:text-red-500"
                )}
              >
                <Star className={cn("h-4 w-4", isLiked && "fill-yellow-500 text-yellow-500")} />
                <span>{formatNumber(work.likeCount)}</span>
              </button>
              
              <button
                onClick={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  onFavorite(work.id, !isFavorited)
                }}
                className={cn(
                  "flex items-center gap-1 text-sm px-3 py-1.5 rounded-full transition-colors",
                  isFavorited 
                    ? "bg-accent/10 text-accent" 
                    : "bg-muted hover:bg-accent/10 hover:text-accent"
                )}
              >
                {isFavorited ? (
                  <BookmarkCheck className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                ) : (
                  <Bookmark className="h-4 w-4" />
                )}
                <span>收藏</span>
              </button>
            </div>
          </CardContent>
        </div>
      </Card>
    </Link>
  )
}

export function FeaturedWorks() {
  const router = useRouter()
  const [works, setWorks] = useState<Work[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [likedWorks, setLikedWorks] = useState<Set<string>>(new Set())
  const [favoritedWorks, setFavoritedWorks] = useState<Set<string>>(new Set())

  // 加载推荐作品
  useEffect(() => {
    const loadWorks = async () => {
      setIsLoading(true)
      try {
        const response = await fetch('/api/works?limit=4&sort=popular')
        if (response.ok) {
          const data = await response.json()
          setWorks(data.works || [])
        } else {
          setWorks(mockFeaturedWorks)
        }
      } catch (error) {
        console.error('Failed to load featured works:', error)
        setWorks(mockFeaturedWorks)
      } finally {
        setIsLoading(false)
      }
    }

    loadWorks()
  }, [])

  // 处理点赞
  const handleLike = async (workId: string, liked: boolean) => {
    setLikedWorks(prev => {
      const newSet = new Set(prev)
      if (liked) newSet.add(workId)
      else newSet.delete(workId)
      return newSet
    })

    setWorks(prev => prev.map(work => {
      if (work.id === workId) {
        return { ...work, likeCount: liked ? work.likeCount + 1 : work.likeCount - 1 }
      }
      return work
    }))

    try {
      await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workId, liked }),
      })
    } catch (error) {
      console.error('Failed to update like:', error)
    }
  }

  // 处理收藏
  const handleFavorite = async (workId: string, favorited: boolean) => {
    setFavoritedWorks(prev => {
      const newSet = new Set(prev)
      if (favorited) newSet.add(workId)
      else newSet.delete(workId)
      return newSet
    })

    setWorks(prev => prev.map(work => {
      if (work.id === workId) {
        return { ...work, favoriteCount: favorited ? work.favoriteCount + 1 : work.favoriteCount - 1 }
      }
      return work
    }))

    try {
      await fetch('/api/favorites', {
        method: favorited ? 'POST' : 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workId }),
      })
    } catch (error) {
      console.error('Failed to update favorite:', error)
    }
  }

  return (
    <>
    <section className="py-12">
      <div className="container mx-auto px-4">
        {/* 标题 */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
              <Feather className="h-5 w-5 text-accent" />
            </div>
            <div>
              <h2 className="text-2xl font-serif font-bold">精选作品</h2>
              <p className="text-sm text-muted-foreground">发现优质的创作</p>
            </div>
          </div>
          
          <Link href="/library">
            <Button variant="ghost" className="gap-2">
              查看更多
              <ChevronRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        {/* 题材分类 */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-8">
          {genreStats.map((stat) => (
            <Link key={stat.genre} href={`/library?genre=${stat.genre}`}>
              <Card className={cn(
                "p-4 hover:shadow-lg transition-all duration-300 cursor-pointer group border-2 border-border/20 hover:border-accent/50"
              )}>
                <p className="font-medium text-sm">{stat.label}</p>
              </Card>
            </Link>
          ))}
        </div>

        {/* 作品列表 */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6">
                  <div className="h-6 bg-muted rounded w-1/3 mb-3" />
                  <div className="h-4 bg-muted rounded w-full mb-2" />
                  <div className="h-4 bg-muted rounded w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {works.map((work) => (
              <FeaturedWorkCard
                key={work.id}
                work={work}
                onLike={handleLike}
                onFavorite={handleFavorite}
                isLiked={likedWorks.has(work.id)}
                isFavorited={favoritedWorks.has(work.id)}
              />
            ))}
          </div>
        )}
      </div>
    </section>

    {/* 快速入口 */}
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Link href="/write">
            <Card className="p-6 hover:shadow-lg transition-all cursor-pointer group border-2 border-border/20 hover:border-accent/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <PenSquare className="h-6 w-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-serif font-semibold">开始创作</h3>
                  <p className="text-sm text-muted-foreground">记录你的文字痕迹</p>
                </div>
              </div>
            </Card>
          </Link>
          
          <Link href="/library">
            <Card className="p-6 hover:shadow-lg transition-all cursor-pointer group border-2 border-border/20 hover:border-primary/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif font-semibold">探索作品</h3>
                  <p className="text-sm text-muted-foreground">发现优质创作</p>
                </div>
              </div>
            </Card>
          </Link>
          
          <Link href="/profile">
            <Card className="p-6 hover:shadow-lg transition-all cursor-pointer group border-2 border-border/20 hover:border-secondary/50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center group-hover:bg-secondary/20 transition-colors">
                  <User className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-serif font-semibold">个人中心</h3>
                  <p className="text-sm text-muted-foreground">管理你的作品</p>
                </div>
              </div>
            </Card>
          </Link>
        </div>
      </div>
    </section>
  </>
  )
}

// ============ Hero Section ============
export function HeroSection() {
  const [isDark, setIsDark] = useState(false)
  
  useEffect(() => {
    setIsDark(document.documentElement.classList.contains('dark'))
  }, [])

  return (
    <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden pt-16">
      {/* 背景装饰 */}
      <div className="absolute inset-0 overflow-hidden">
        {/* 渐变背景 */}
        <div className="absolute inset-0 bg-gradient-to-b from-accent/5 via-transparent to-transparent" />
        
        {/* 装饰线条 */}
        <div className="absolute top-1/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        <div className="absolute bottom-1/4 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        
        {/* 浮动装饰 */}
        <div className="absolute top-20 left-1/4 w-2 h-2 rounded-full bg-accent/30 animate-pulse" />
        <div className="absolute top-40 right-1/3 w-3 h-3 rounded-full bg-accent/20 animate-pulse delay-1000" />
        <div className="absolute bottom-32 left-1/3 w-2 h-2 rounded-full bg-accent/40 animate-pulse delay-500" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Logo */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center">
              <Feather className="h-8 w-8 text-accent" />
            </div>
          </div>

          {/* 标题 */}
          <h1 className="text-5xl md:text-6xl font-serif font-bold mb-4 tracking-tight">
            <span className="text-foreground">
              VEINWORD
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground font-serif mb-4">
            文字落下的痕迹
          </p>
          
          <p className="text-base text-muted-foreground/70 max-w-xl mx-auto mb-10">
            记录每一段创作旅程，保存每一次灵感迸发的瞬间。在这里，你的文字将被珍藏。
          </p>

          {/* 搜索框 */}
          <div className="max-w-xl mx-auto mb-10">
            <Link href="/search">
              <div className="relative group">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground group-hover:text-accent transition-colors" />
                <Input
                  type="text"
                  placeholder="搜索作品、作者或标签..."
                  className="pl-12 pr-4 h-14 rounded-full bg-card border-2 border-border/50 focus:border-accent transition-colors text-lg"
                  readOnly
                />
              </div>
            </Link>
          </div>

          {/* CTA 按钮 */}
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link href="/write">
              <Button size="lg" className="gap-2 rounded-full px-8">
                <PenSquare className="h-5 w-5" />
                开始创作
              </Button>
            </Link>
            <Link href="/library">
              <Button size="lg" variant="outline" className="gap-2 rounded-full px-8">
                <Library className="h-5 w-5" />
                浏览作品
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

// ============ Features Section ============
export function FeaturesSection() {
  const features = [
    {
      icon: PlayCircle,
      title: '写作回放',
      description: '完整记录每一次创作过程，真实还原写作时的灵感与思考',
    },
    {
      icon: Shield,
      title: '防粘贴复制',
      description: '保护原创精神，鼓励真实创作，拒绝批量复制粘贴',
    },
    {
      icon: Settings,
      title: '阅读定制',
      description: '自由调节字体、字号、行距和背景色，打造专属阅读体验',
    },
    {
      icon: Sparkles,
      title: '旁注笔记',
      description: '记录创作过程中的灵感碎片和碎碎念，不让灵感溜走',
    },
  ]

  return (
    <section className="py-16 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold mb-4">为什么选择 VEINWORD</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            我们专注于为创作者提供最好的写作和阅读体验
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Card 
                key={index} 
                className="p-6 hover:shadow-lg transition-all duration-300 group"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 mb-4 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Icon className="h-6 w-6 text-accent" />
                </div>
                <h3 className="font-serif font-semibold text-lg mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}

// ============ Import Library for Hero Section ============
function Library(props: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={props.className}
    >
      <path d="m16 6 4 14" />
      <path d="M12 6v14" />
      <path d="M8 8v12" />
      <path d="M4 4v16" />
    </svg>
  )
}
