'use client'

import { useState, useEffect, useCallback, use } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { createClient } from '@/storage/database/supabase-client-browser'
import { useAuth } from '@/contexts/auth-context'
import { cn } from '@/lib/utils'
import { 
  Feather, 
  BookOpen, 
  Play, 
  Clock, 
  Edit3, 
  Star,
  Settings,
  Eye,
  Plus,
  Calendar,
  Trash2,
  BookMarked,
  User,
  LogOut,
  Save,
  Search,
  Filter,
  Loader2,
  AlertCircle,
  X,
  EyeOff,
  StarOff,
  CheckCircle2,
  Upload,
  Image,
  FileText,
  Trash,
} from 'lucide-react'

type Genre = 'poetry' | 'essay' | 'story' | 'novel' | 'letter' | 'script'

interface Work {
  id: string
  title: string
  genre: Genre
  excerpt: string
  content?: string
  author: string
  authorId: string
  wordCount: number
  playCount: number
  likeCount: number
  favoriteCount?: number
  viewCount?: number
  updatedAt: string
  createdAt: string
  hasPlayback: boolean
  isFeatured: boolean
  status: 'draft' | 'published' | 'private'
  tags: string[]
  operations?: Record<string, unknown>[]
}

interface Favorite {
  id: string
  work_id: string
  created_at: string
  works: Work
}

// Raw Supabase response type
interface RawFavorite {
  id: string
  work_id: string
  created_at: string
  works: unknown
}

interface Profile {
  id: string
  username: string
  bio: string
  avatar_url?: string
  created_at: string
}

const genreLabels: Record<Genre, string> = {
  poetry: '诗歌',
  essay: '随笔',
  story: '短故事',
  novel: '小说',
  letter: '书信',
  script: '剧本',
}

// 题材引导语
const genrePrompts: Record<Genre, string> = {
  poetry: '用凝练的语言抒发情感，营造意境...',
  essay: '记录生活感悟，自由书写...',
  story: '讲述一个完整的故事，有开端、发展、结局...',
  novel: '展开长篇叙事，塑造人物与情节...',
  letter: '以书信格式，表达情感或思想...',
  script: '按照剧本格式，分幕分场创作...',
}

// 预设头像 - 莫兰迪色系
const PRESET_AVATARS = [
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNFQ0VFRkYiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjREM5QkMzIi8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNGQ0VFRjIiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjN0I5N0M0Ii8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNGNUZGRjQiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjN0I5Q0M0Ii8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNDN0QwREIiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjNUI3NUYxIi8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiM5NkI1Q0IiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjQzc5M0Y2Ii8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNDNERDQ0IiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjN0I3MkMyIi8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNBQ0NBRkIiLz48Y2lyY2xlIGN4PSIxMjgiIGN5PSIxMjgiIHI9IjgwIiBmaWxsPSIjNUI2NUQ4Ii8+PC9zdmc+',
  'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjU2IiBoZWlnaHQ9IjI1NiIgdmlld0JveD0iMCAwIDI1NiAyNTYiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTI4IiBjeT0iMTI4IiByPSIxMjgiIGZpbGw9IiNERUREMCIvPjxjaXJjbGUgY3g9IjEyOCIgY3k9IjEyOCIgcj0iODAiIGZpbGw9IiM3QjZFQzQiLz48L3N2Zz4=',
]

export function ProfileContent() {
  const router = useRouter()
  const { user, profile, loading: authLoading, signOut, refreshProfile, updateProfile } = useAuth()
  const [activeTab, setActiveTab] = useState('works')
  const [works, setWorks] = useState<Work[]>([])
  const [favorites, setFavorites] = useState<Favorite[]>([])
  const [loading, setLoading] = useState(true)
  
  // 个人资料编辑
  const [editUsername, setEditUsername] = useState('')
  const [editBio, setEditBio] = useState('')
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState('')
  const [saveSuccess, setSaveSuccess] = useState(false)
  
  // 筛选
  const [searchQuery, setSearchQuery] = useState('')
  const [filterGenre, setFilterGenre] = useState<Genre | 'all'>('all')
  const [sortBy, setSortBy] = useState<'updated_at' | 'created_at' | 'word_count' | 'play_count'>('updated_at')
  
  // 删除确认
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null)
  const [deletingWorkId, setDeletingWorkId] = useState<string | null>(null)
  
  // 取消收藏
  const [removingFavoriteId, setRemovingFavoriteId] = useState<string | null>(null)

  // 阅读设置
  const [readingFont, setReadingFont] = useState('Noto Serif SC')
  const [readingFontSize, setReadingFontSize] = useState(18)
  const [readingLineHeight, setReadingLineHeight] = useState(1.8)
  const [readingBackground, setReadingBackground] = useState('paper')
  
  // 保存阅读设置
  const [savingSettings, setSavingSettings] = useState(false)
  
  // 头像选择
  const [showAvatarPicker, setShowAvatarPicker] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState('')
  
  // 关注的作者
  const [followingAuthors, setFollowingAuthors] = useState<Profile[]>([])
  const [loadingFollowing, setLoadingFollowing] = useState(false)

  // 初始化编辑表单
  useEffect(() => {
    if (profile) {
      setEditUsername(profile.username || '')
      setEditBio(profile.bio || '')
    }
  }, [profile])

  // 加载用户数据
  const loadUserData = useCallback(async () => {
    if (!user) {
      setLoading(false)
      return
    }

    const supabase = createClient()
    
    try {
      // 从 localStorage 加载作品
      const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
        .filter((w: any) => w.authorId === user.id)
        .map((w: any) => ({
          id: w.id,
          title: w.title,
          genre: (w.genre || 'essay') as Genre,
          excerpt: (w.content || '').substring(0, 100) + ((w.content?.length || 0) > 100 ? '...' : ''),
          content: w.content,
          author: w.author || user.username || '佚名',
          authorId: w.authorId || user.id,
          wordCount: w.wordCount || w.content?.length || 0,
          playCount: w.playCount || 0,
          likeCount: w.likeCount || 0,
          favoriteCount: w.favoriteCount || 0,
          viewCount: w.viewCount || 0,
          updatedAt: w.date || new Date().toISOString(),
          createdAt: w.date || new Date().toISOString(),
          hasPlayback: Array.isArray(w.operations) && w.operations.length > 0,
          isFeatured: false,
          status: (w.status || 'published') as 'draft' | 'published' | 'private',
          tags: w.tags || [],
          operations: w.operations || [],
        }))
      
      // 并行加载 API 作品和收藏
      const [worksRes, favoritesRes] = await Promise.all([
        supabase
          .from('works')
          .select('*')
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false }),
        supabase
          .from('work_favorites')
          .select(`
            id,
            work_id,
            created_at,
            works:works(*)
          `)
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
      ])

      // 合并 localStorage 和 API 的作品
      if (worksRes.data) {
        const apiWorks = worksRes.data.map(w => ({
          id: w.id,
          title: w.title,
          genre: w.genre as Genre,
          excerpt: w.content?.substring(0, 100) + (w.content?.length > 100 ? '...' : ''),
          content: w.content,
          author: profile?.username || '佚名',
          authorId: w.user_id,
          wordCount: w.word_count || 0,
          playCount: w.play_count || 0,
          likeCount: w.like_count || 0,
          favoriteCount: w.favorite_count || 0,
          viewCount: w.view_count || 0,
          updatedAt: w.updated_at,
          createdAt: w.created_at,
          hasPlayback: Array.isArray(w.operations) && w.operations.length > 0,
          isFeatured: w.is_featured || false,
          status: w.status || 'draft',
          tags: w.tags || [],
          operations: w.operations || [],
        }))
        
        // 合并并去重
        const allWorks = [...localWorks, ...apiWorks]
        const uniqueWorks = allWorks.reduce((acc: Work[], work) => {
          if (!acc.find(w => w.id === work.id)) {
            acc.push(work)
          }
          return acc
        }, [])
        
        setWorks(uniqueWorks)
      } else {
        setWorks(localWorks)
      }

      if (favoritesRes.data) {
        const rawFavorites = favoritesRes.data as RawFavorite[]
        setFavorites(
          rawFavorites
            .filter((f): f is RawFavorite & { works: Work } => 
              f.works !== null && typeof f.works === 'object' && !Array.isArray(f.works)
            )
            .map(f => ({
              id: f.id,
              work_id: f.work_id,
              created_at: f.created_at,
              works: f.works,
            }))
        )
      }
    } catch (error) {
      console.error('加载用户数据失败:', error)
      // 出错时只显示本地作品
      const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
        .filter((w: any) => w.authorId === user.id)
        .map((w: any) => ({
          id: w.id,
          title: w.title,
          genre: (w.genre || 'essay') as Genre,
          excerpt: (w.content || '').substring(0, 100) + ((w.content?.length || 0) > 100 ? '...' : ''),
          content: w.content,
          author: w.author || user.username || '佚名',
          authorId: w.authorId || user.id,
          wordCount: w.wordCount || w.content?.length || 0,
          playCount: w.playCount || 0,
          likeCount: w.likeCount || 0,
          favoriteCount: w.favoriteCount || 0,
          viewCount: w.viewCount || 0,
          updatedAt: w.date || new Date().toISOString(),
          createdAt: w.date || new Date().toISOString(),
          hasPlayback: Array.isArray(w.operations) && w.operations.length > 0,
          isFeatured: false,
          status: (w.status || 'published') as 'draft' | 'published' | 'private',
          tags: w.tags || [],
          operations: w.operations || [],
        }))
      setWorks(localWorks)
      
      // 加载关注的作者
      setLoadingFollowing(true)
      try {
        const followedIds = JSON.parse(localStorage.getItem(`wenhen_following_${user.id}`) || '[]')
        if (followedIds.length > 0) {
          const { data: profilesData } = await supabase
            .from('profiles')
            .select('*')
            .in('id', followedIds)
          
          if (profilesData) {
            setFollowingAuthors(profilesData)
          }
        } else {
          setFollowingAuthors([])
        }
      } catch (error) {
        console.error('加载关注的作者失败:', error)
        setFollowingAuthors([])
      } finally {
        setLoadingFollowing(false)
      }
    } finally {
      setLoading(false)
    }
  }, [user, profile])

  useEffect(() => {
    if (!authLoading) {
      loadUserData()
    }
  }, [authLoading, loadUserData])

  // 监听收藏更新事件
  useEffect(() => {
    const handleFavoritesUpdate = () => {
      loadUserData()
    }
    window.addEventListener('favorites_updated', handleFavoritesUpdate)
    return () => window.removeEventListener('favorites_updated', handleFavoritesUpdate)
  }, [loadUserData])

  // 监听作品发布事件
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'wenhen_work_published') {
        loadUserData()
      }
    }
    
    window.addEventListener('storage', handleStorageChange)
    
    // 轮询检查本地存储变化
    const checkPublished = () => {
      const published = localStorage.getItem('wenhen_work_published')
      if (published) {
        loadUserData()
        localStorage.removeItem('wenhen_work_published')
      }
    }
    
    const interval = setInterval(checkPublished, 1000)
    
    return () => {
      window.removeEventListener('storage', handleStorageChange)
      clearInterval(interval)
    }
  }, [loadUserData])

  // 保存个人资料
  const handleSaveProfile = async () => {
    if (!user) return
    
    if (!editUsername.trim()) {
      setSaveError('用户名不能为空')
      return
    }
    
    setSaving(true)
    setSaveError('')
    setSaveSuccess(false)
    
    const updatedData = {
      username: editUsername.trim(),
      bio: editBio.trim(),
      updated_at: new Date().toISOString(),
    }
    
    try {
      // Update localStorage first (for demo mode)
      await updateProfile(updatedData)
      
      // Then try to update Supabase (if available)
      const supabase = createClient()
      await supabase
        .from('profiles')
        .update(updatedData)
        .eq('id', user.id)
      
      setSaveSuccess(true)
      // 保存成功后自动返回主页并刷新
      localStorage.setItem('wenhen_profile_updated', Date.now().toString())
      setTimeout(() => {
        router.push('/')
      }, 800)
    } catch (error: unknown) {
      console.error('保存失败:', error)
      setSaveError('保存失败，请重试')
      setSaving(false)
    }
  }

  // 选择预设头像
  const handleAvatarSelect = async (avatarUrl: string) => {
    if (!user) return
    
    setSaving(true)
    setSaveError("")
    
    try {
      await updateProfile({ avatar_url: avatarUrl })
      setSaveSuccess(true)
      setShowAvatarPicker(false)
      setTimeout(() => setSaveSuccess(false), 3000)
    } catch (error: unknown) {
      console.error("头像设置失败:", error)
      setSaveError("设置失败，请重试")
    } finally {
      setSaving(false)
    }
  }

  // 删除作品
  const handleDeleteWork = async (workId: string) => {
    if (!user) return
    
    setDeletingWorkId(workId)
    const supabase = createClient()
    
    try {
      const { error } = await supabase
        .from('works')
        .delete()
        .eq('id', workId)
        .eq('user_id', user.id)
      
      if (error) throw error
      
      setWorks(prev => prev.filter(w => w.id !== workId))
      setShowDeleteConfirm(null)
    } catch (error) {
      console.error('删除失败:', error)
    } finally {
      setDeletingWorkId(null)
    }
  }

  // 取消收藏
  const handleRemoveFavorite = async (favoriteId: string) => {
    if (!user) return
    
    setRemovingFavoriteId(favoriteId)
    const supabase = createClient()
    
    try {
      const { error } = await supabase
        .from('work_favorites')
        .delete()
        .eq('id', favoriteId)
        .eq('user_id', user.id)
      
      if (error) throw error
      
      setFavorites(prev => prev.filter(f => f.id !== favoriteId))
    } catch (error) {
      console.error('取消收藏失败:', error)
    } finally {
      setRemovingFavoriteId(null)
    }
  }

  // 取消关注作者
  const handleUnfollow = (authorId: string) => {
    if (!user) return
    
    const storageKey = `wenhen_following_${user.id}`
    const followedAuthors = JSON.parse(localStorage.getItem(storageKey) || '[]')
    const updated = followedAuthors.filter((id: string) => id !== authorId)
    localStorage.setItem(storageKey, JSON.stringify(updated))
    setFollowingAuthors(prev => prev.filter(a => a.id !== authorId))
  }

  // 计算统计数据
  const stats = {
    totalWorks: works.length,
    totalWords: works.reduce((sum, w) => sum + w.wordCount, 0),
    totalPlays: works.reduce((sum, w) => sum + w.playCount, 0),
    totalLikes: works.reduce((sum, w) => sum + w.likeCount, 0),
    totalFavorites: works.reduce((sum, w) => sum + (w.favoriteCount || 0), 0),
  }

  // 过滤和排序作品
  const filteredWorks = works
    .filter(w => {
      if (filterGenre !== 'all' && w.genre !== filterGenre) return false
      if (searchQuery && !w.title.toLowerCase().includes(searchQuery.toLowerCase())) return false
      return true
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'word_count':
          return b.wordCount - a.wordCount
        case 'play_count':
          return b.playCount - a.playCount
        case 'created_at':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        default:
          return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
      }
    })

  // 格式化时间
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  // 格式化日期
  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  // 格式化数字
  const formatNumber = (num: number) => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + '万'
    }
    return num.toString()
  }

  // 计算回放时长
  const calculateDuration = (operations: unknown[]) => {
    if (!operations || operations.length === 0) return 0
    const ops = operations as Array<{ t: number }>
    const lastOp = ops[ops.length - 1]
    return Math.ceil((lastOp.t || 0) / 1000)
  }

  // 未登录状态
  if (!authLoading && !user) {
    return (
      <div className="min-h-screen bg-background pt-16 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardHeader className="text-center">
            <CardTitle>请先登录</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">登录后可查看和管理您的作品</p>
            <Link href="/login">
              <Button className="w-full">前往登录</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pt-16">
      {/* Profile Header */}
      <div className="bg-gradient-to-b from-accent/5 to-background border-b border-border/50">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
            {/* Avatar */}
            <div className="relative">
              <div className="w-24 h-24 rounded-full bg-accent/20 flex items-center justify-center border-2 border-accent/30 overflow-hidden">
                {profile?.avatar_url ? (
                  <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <User className="h-12 w-12 text-accent" />
                )}
              </div>
              {/* 头像不需要显示原创标识 */}
            </div>

            {/* User Info */}
            <div className="flex-1 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start gap-3">
                <h1 className="text-2xl font-serif font-bold text-foreground">
                  {profile?.username || '未设置用户名'}
                </h1>
                <Link href="/settings">
                  <Button variant="ghost" size="icon" title="编辑资料">
                    <Edit3 className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
              <p className="text-muted-foreground mt-2 max-w-2xl">
                {profile?.bio || '还没有个人简介'}
              </p>
              <div className="flex items-center justify-center md:justify-start gap-4 mt-3 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  加入于 {profile?.created_at ? formatDate(profile.created_at) : '未知'}
                </span>
              </div>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap justify-center md:justify-end gap-4">
              <div className="text-center px-4 py-2 bg-card/50 rounded-lg">
                <div className="text-2xl font-bold text-accent">{stats.totalWorks}</div>
                <div className="text-xs text-muted-foreground">作品</div>
              </div>
              <div className="text-center px-4 py-2 bg-card/50 rounded-lg">
                <div className="text-2xl font-bold text-accent">{formatNumber(stats.totalWords)}</div>
                <div className="text-xs text-muted-foreground">字数</div>
              </div>
              <div className="text-center px-4 py-2 bg-card/50 rounded-lg">
                <div className="text-2xl font-bold text-accent">{formatNumber(stats.totalPlays)}</div>
                <div className="text-xs text-muted-foreground">阅读</div>
              </div>
              <div className="text-center px-4 py-2 bg-card/50 rounded-lg">
                <div className="text-2xl font-bold text-accent">{formatNumber(stats.totalLikes)}</div>
                <div className="text-xs text-muted-foreground">获赞</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Tabs */}
      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-card/50 mb-6">
            <TabsTrigger value="works" className="gap-2">
              <BookOpen className="h-4 w-4" />
              我的作品
              <Badge variant="secondary" className="ml-1">{stats.totalWorks}</Badge>
            </TabsTrigger>
            <TabsTrigger value="drafts" className="gap-2">
              <FileText className="h-4 w-4" />
              草稿箱
              <Badge variant="secondary" className="ml-1" id="draft-count">-</Badge>
            </TabsTrigger>
            <TabsTrigger value="favorites" className="gap-2">
              <Star className="h-4 w-4" />
              我的收藏
              <Badge variant="secondary" className="ml-1">{favorites.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="following" className="gap-2">
              <Feather className="h-4 w-4" />
              关注的作者
              <Badge variant="secondary" className="ml-1">{followingAuthors.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-2">
              <Settings className="h-4 w-4" />
              设置
            </TabsTrigger>
          </TabsList>

          {/* 我的作品 */}
          <TabsContent value="works" className="space-y-4">
            {/* 工具栏 */}
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              <div className="flex flex-wrap gap-2 items-center">
                {/* 搜索 */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="搜索作品..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-4 py-2 w-48"
                  />
                </div>

                {/* 题材筛选 */}
                <select
                  value={filterGenre}
                  onChange={(e) => setFilterGenre(e.target.value as Genre | 'all')}
                  className="px-3 py-2 rounded-md border border-border bg-background text-sm"
                >
                  <option value="all">全部题材</option>
                  {Object.entries(genreLabels).map(([key, label]) => (
                    <option key={key} value={key}>{label}</option>
                  ))}
                </select>

                {/* 排序 */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                  className="px-3 py-2 rounded-md border border-border bg-background text-sm"
                >
                  <option value="updated_at">按更新时间</option>
                  <option value="created_at">按创建时间</option>
                  <option value="word_count">按字数</option>
                  <option value="play_count">按阅读量</option>
                </select>
              </div>

              <Link href="/write">
                <Button size="sm" className="gap-2">
                  <Plus className="h-4 w-4" />
                  新建作品
                </Button>
              </Link>
            </div>

            {/* 作品列表 */}
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredWorks.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <BookOpen className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                  <p className="text-muted-foreground">
                    {searchQuery || filterGenre !== 'all' ? '没有找到符合条件的作品' : '还没有作品，开始创作吧'}
                  </p>
                  <Link href="/write" className="mt-4 inline-block">
                    <Button size="sm" className="gap-2">
                      <Plus className="h-4 w-4" />
                      新建作品
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {filteredWorks.map((work) => (
                  <Card key={work.id} className="group hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          {/* 标题和状态 */}
                          <div className="flex items-center gap-2 mb-2">
                            <Link 
                              href={`/read/${work.id}`}
                              className="text-lg font-serif font-bold hover:text-accent truncate"
                            >
                              {work.title}
                            </Link>
                            <Badge variant="outline" className="shrink-0">
                              {genreLabels[work.genre]}
                            </Badge>
                            {work.status === 'draft' && (
                              <Badge variant="secondary" className="shrink-0">
                                草稿
                              </Badge>
                            )}
                            {work.status === 'private' && (
                              <Badge variant="secondary" className="shrink-0">
                                <EyeOff className="h-3 w-3 mr-1" />
                                私密
                              </Badge>
                            )}
                          </div>
                          
                          {/* 摘要 */}
                          <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
                            {work.excerpt || genrePrompts[work.genre]}
                          </p>
                          
                          {/* 标签 */}
                          {work.tags && work.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-3">
                              {work.tags.map((tag, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                          
                          {/* 统计 */}
                          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Feather className="h-3 w-3" />
                              {work.wordCount} 字
                            </span>
                            <span className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {formatNumber(work.viewCount || 0)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3" />
                              {formatNumber(work.likeCount)}
                            </span>
                            <span className="flex items-center gap-1">
                              <BookMarked className="h-3 w-3" />
                              {formatNumber(work.favoriteCount || 0)}
                            </span>
                            {work.hasPlayback && (
                              <span className="flex items-center gap-1 text-accent">
                                <Play className="h-3 w-3" />
                                {formatTime(calculateDuration(work.operations || []))}
                              </span>
                            )}
                            <span className="text-xs">
                              {formatDate(work.updatedAt)}
                            </span>
                          </div>
                        </div>

                        {/* 操作 */}
                        <div className="flex flex-col gap-2 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                          {work.hasPlayback && (
                            <Link href={`/write?playback=${work.id}`}>
                              <Button variant="ghost" size="icon" title="查看回放">
                                <Play className="h-4 w-4" />
                              </Button>
                            </Link>
                          )}
                          <Link href={`/write?id=${work.id}`}>
                            <Button variant="ghost" size="icon" title="编辑">
                              <Edit3 className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            title="删除"
                            onClick={() => setShowDeleteConfirm(work.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 草稿箱 */}
          <TabsContent value="drafts" className="space-y-4">
            <DraftsContent />
          </TabsContent>

          {/* 我的收藏 */}
          <TabsContent value="favorites" className="space-y-4">
            {favorites.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Star className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                  <p className="text-muted-foreground">还没有收藏任何作品</p>
                  <Link href="/library" className="mt-4 inline-block">
                    <Button size="sm" variant="outline" className="gap-2">
                      <BookOpen className="h-4 w-4" />
                      去作品库看看
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {favorites.map((fav) => (
                  <Card key={fav.id} className="group hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <Link 
                              href={`/read/${fav.works.id}`}
                              className="text-lg font-serif font-bold hover:text-accent"
                            >
                              {fav.works.title}
                            </Link>
                            <Badge variant="outline">
                              {genreLabels[fav.works.genre as Genre] || fav.works.genre}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            by {fav.works.author}
                          </p>
                          <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
                            {fav.works.excerpt}
                          </p>
                          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Feather className="h-3 w-3" />
                              {fav.works.wordCount} 字
                            </span>
                            <span className="flex items-center gap-1">
                              <Star className="h-3 w-3" />
                              {formatNumber(fav.works.likeCount)}
                            </span>
                            <span className="text-xs">
                              收藏于 {formatDate(fav.created_at)}
                            </span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 shrink-0">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleRemoveFavorite(fav.id)}
                            disabled={removingFavoriteId === fav.id}
                            title="取消收藏"
                          >
                            <StarOff className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 关注的作者 */}
          <TabsContent value="following" className="space-y-4">
            {loadingFollowing ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : followingAuthors.length === 0 ? (
              <Card className="paper-texture">
                <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                  <Feather className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-serif mb-2">暂无关注的作者</h3>
                  <p className="text-muted-foreground text-sm">去发现喜欢的作者并关注他们吧</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {followingAuthors.map((author) => (
                  <Card key={author.id} className="paper-texture hover:shadow-lg transition-all duration-300 border-border/50">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center overflow-hidden">
                          {author.avatar_url ? (
                            <img src={author.avatar_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <User className="h-6 w-6 text-accent" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <Link href={`/author/${author.id}`} className="font-serif font-semibold hover:text-accent transition-colors block truncate">
                            @{author.username}
                          </Link>
                          {author.bio && (
                            <p className="text-sm text-muted-foreground truncate">{author.bio}</p>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleUnfollow(author.id)}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 设置 */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  个人资料设置
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* 头像选择 */}
                <div>
                  <label className="text-sm font-medium mb-2 block">头像</label>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center border-2 border-border overflow-hidden">
                      {profile?.avatar_url ? (
                        <img src={profile.avatar_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <User className="h-8 w-8 text-accent" />
                      )}
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setShowAvatarPicker(!showAvatarPicker)}>
                      <User className="h-4 w-4 mr-1" />
                      选择头像
                    </Button>
                  </div>
                  {showAvatarPicker && (
                    <div className="mt-3 grid grid-cols-4 gap-2 p-3 bg-muted/30 rounded-lg">
                      {PRESET_AVATARS.map((avatar, index) => (
                        <button
                          key={index}
                          onClick={() => handleAvatarSelect(avatar)}
                          className={cn(
                            "w-12 h-12 rounded-full overflow-hidden border-2 transition-all hover:scale-110",
                            profile?.avatar_url === avatar ? "border-primary" : "border-transparent"
                          )}
                          disabled={saving}
                        >
                          <img src={avatar} alt="" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                {saveError && (
                  <p className="text-sm text-destructive flex items-center gap-1">
                    <AlertCircle className="h-4 w-4" />
                    {saveError}
                  </p>
                )}
                {saveSuccess && (
                  <p className="text-sm text-green-600 flex items-center gap-1">
                    <CheckCircle2 className="h-4 w-4" />
                    设置成功
                  </p>
                )}
                
                <div className="border-t border-border pt-4 mt-4">
                  <div className="mb-4">
                    <label className="text-sm font-medium mb-1 block">用户名</label>
                    <Input
                      value={editUsername}
                      onChange={(e) => setEditUsername(e.target.value)}
                      placeholder="设置用户名"
                    />
                  </div>
                  <div className="mb-4">
                    <label className="text-sm font-medium mb-1 block">个人简介</label>
                    <Textarea
                      value={editBio}
                      onChange={(e) => setEditBio(e.target.value)}
                      placeholder="介绍一下自己..."
                      rows={3}
                    />
                  </div>
                  <Button onClick={handleSaveProfile} disabled={saving}>
                    {saving && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                    保存资料
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  阅读器设置
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">字体</label>
                  <div className="flex flex-wrap gap-2">
                    {['Noto Serif SC', 'Noto Sans SC', 'Ma Shan Zheng', 'ZCOOL XiaoWei'].map((font) => (
                      <Button
                        key={font}
                        variant={readingFont === font ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setReadingFont(font)}
                      >
                        {font}
                      </Button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    字号：{readingFontSize}px
                  </label>
                  <Input
                    type="range"
                    min={14}
                    max={28}
                    value={readingFontSize}
                    onChange={(e) => setReadingFontSize(Number(e.target.value))}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    行距：{readingLineHeight.toFixed(1)}
                  </label>
                  <Input
                    type="range"
                    min={1.2}
                    max={2.5}
                    step={0.1}
                    value={readingLineHeight}
                    onChange={(e) => setReadingLineHeight(Number(e.target.value))}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">阅读背景</label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { id: 'paper', name: '宣纸白', bg: '#F5F1E8', color: '#2C2416' },
                      { id: 'night', name: '月夜深蓝', bg: '#1A1D29', color: '#E8E4D9' },
                      { id: 'dark', name: '墨染黑', bg: '#0D0D0D', color: '#D4C5A9' },
                      { id: 'light', name: '素雅灰', bg: '#F0EDE8', color: '#333333' },
                    ].map((theme) => (
                      <button
                        key={theme.id}
                        onClick={() => setReadingBackground(theme.id)}
                        className={`px-3 py-2 rounded-md border-2 transition-all ${
                          readingBackground === theme.id 
                            ? 'border-accent scale-105' 
                            : 'border-border hover:border-accent/50'
                        }`}
                        style={{ backgroundColor: theme.bg, color: theme.color }}
                      >
                        <span className="text-xs font-medium">{theme.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <Button 
                  onClick={async () => {
                    setSavingSettings(true)
                    try {
                      const supabase = createClient()
                      await supabase.from('reading_settings').upsert({
                        user_id: user?.id,
                        font_family: readingFont,
                        font_size: readingFontSize,
                        line_height: readingLineHeight,
                        background_color: readingBackground,
                      })
                      setSavingSettings(false)
                    } catch {
                      setSavingSettings(false)
                    }
                  }}
                  disabled={savingSettings}
                >
                  {savingSettings && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                  保存阅读设置
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LogOut className="h-5 w-5" />
                  账户操作
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button variant="destructive" onClick={() => signOut()}>
                  退出登录
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* 删除确认对话框 */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-sm w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-destructive" />
                确认删除
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                确定要删除这份作品吗？此操作不可恢复。
              </p>
              <div className="flex gap-2 justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => setShowDeleteConfirm(null)}
                  disabled={deletingWorkId !== null}
                >
                  取消
                </Button>
                <Button 
                  variant="destructive"
                  onClick={() => handleDeleteWork(showDeleteConfirm)}
                  disabled={deletingWorkId !== null}
                >
                  {deletingWorkId === showDeleteConfirm ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                      删除中...
                    </>
                  ) : (
                    '确认删除'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

// 草稿箱组件
function DraftsContent() {
  const [drafts, setDrafts] = useState<Array<{
    key: string
    title: string
    content: string
    genre: Genre
    savedAt: string
  }>>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    loadDrafts()
  }, [])

  const loadDrafts = useCallback(() => {
    setLoading(true)
    try {
      // 从localStorage加载所有草稿
      const allDrafts: typeof drafts = []
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i)
        if (key && key.startsWith('wenhen_draft_')) {
          const draftData = localStorage.getItem(key)
          if (draftData) {
            const data = JSON.parse(draftData)
            allDrafts.push({
              key,
              title: data.title || '无标题',
              content: data.content || '',
              genre: data.genre || 'essay',
              savedAt: data.savedAt || new Date().toISOString()
            })
          }
        }
      }
      // 按保存时间倒序排列
      allDrafts.sort((a, b) => new Date(b.savedAt).getTime() - new Date(a.savedAt).getTime())
      setDrafts(allDrafts)
      
      // 更新草稿数量显示
      const countBadge = document.getElementById('draft-count')
      if (countBadge) {
        countBadge.textContent = allDrafts.length.toString()
      }
    } catch (error) {
      console.error('加载草稿失败:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  const handleDeleteDraft = (key: string) => {
    localStorage.removeItem(key)
    loadDrafts()
  }

  const handleContinueDraft = (key: string) => {
    // 跳转到写作页面继续编辑
    const workId = key.replace('wenhen_draft_', '')
    router.push(`/write?id=${workId}`)
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const genreLabels: Record<Genre, string> = {
    poetry: '诗歌',
    essay: '随笔',
    story: '短故事',
    novel: '小说',
    letter: '书信',
    script: '剧本',
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-muted-foreground" />
        </CardContent>
      </Card>
    )
  }

  if (drafts.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
          <p className="text-muted-foreground">草稿箱是空的</p>
          <Link href="/write" className="mt-4 inline-block">
            <Button size="sm" variant="outline" className="gap-2">
              <Feather className="h-4 w-4" />
              开始创作
            </Button>
          </Link>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">共 {drafts.length} 篇草稿</p>
      <div className="grid gap-4">
        {drafts.map((draft) => (
          <Card key={draft.key} className="group hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline">{genreLabels[draft.genre]}</Badge>
                    <span className="text-xs text-muted-foreground">
                      保存于 {formatDate(draft.savedAt)}
                    </span>
                  </div>
                  <h3 className="font-medium text-lg mb-2 truncate">
                    {draft.title || '无标题'}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {draft.content || '暂无内容'}
                  </p>
                  <div className="text-xs text-muted-foreground mt-2">
                    {draft.content.length} 字
                  </div>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleContinueDraft(draft.key)}
                  >
                    <Edit3 className="h-4 w-4 mr-1" />
                    继续编辑
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleDeleteDraft(draft.key)}
                    className="text-destructive hover:text-destructive"
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
