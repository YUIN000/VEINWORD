'use client'

import { useState, useEffect, useMemo, useCallback } from 'react'
import { useSearchParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Filter, 
  SortAsc, 
  Grid, 
  List,
  Search,
  Star,
  Heart,
  Eye,
  BookOpen,
  Clock,
  Loader2,
  User,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

// 题材类型
type Genre = 'all' | 'poetry' | 'essay' | 'short_story' | 'novel' | 'letter' | 'script'

const genreLabels: Record<Genre, string> = {
  all: '全部',
  poetry: '诗歌',
  essay: '随笔',
  short_story: '短故事',
  novel: '小说',
  letter: '书信',
  script: '剧本',
}

// 排序类型
type SortBy = 'latest' | 'popular' | 'hot'

const sortLabels: Record<SortBy, string> = {
  latest: '最新',
  popular: '最多浏览',
  hot: '最热',
}

// 作品类型
interface Work {
  id: string
  title: string
  content: string
  excerpt: string
  genre: Genre
  author: string
  authorId: string
  wordCount: number
  playCount: number
  likeCount: number
  favoriteCount: number
  createdAt: string
  updatedAt: string
  hasPlayback: boolean
  tags: string[]
}

// 模拟数据
const mockWorks: Work[] = [
  {
    id: '1',
    title: '春江花月夜',
    content: '春江潮水连海平，海上明月共潮生。滟滟随波千万里，何处春江无月明！',
    excerpt: '春江潮水连海平，海上明月共潮生...',
    genre: 'poetry',
    author: '张若虚',
    authorId: '1',
    wordCount: 252,
    playCount: 12580,
    likeCount: 856,
    favoriteCount: 234,
    createdAt: '2024-03-15',
    updatedAt: '2024-03-15',
    hasPlayback: true,
    tags: ['唐诗', '夜景', '抒情'],
  },
  {
    id: '2',
    title: '雨巷',
    content: '撑着油纸伞，独自彷徨在悠长、悠长又寂寥的雨巷，我希望逢着一个丁香一样地结着愁怨的姑娘。',
    excerpt: '撑着油纸伞，独自彷徨在悠长、悠长又寂寥的雨巷...',
    genre: 'poetry',
    author: '戴望舒',
    authorId: '2',
    wordCount: 186,
    playCount: 8920,
    likeCount: 623,
    favoriteCount: 189,
    createdAt: '2024-03-10',
    updatedAt: '2024-03-10',
    hasPlayback: false,
    tags: ['现代诗', '雨巷', '姑娘'],
  },
  {
    id: '3',
    title: '那个夏天的记忆',
    content: '那年夏天，我遇见了她。她穿着白色的连衣裙，在阳光下笑得像朵花。',
    excerpt: '那年夏天，我遇见了她。她穿着白色的连衣裙...',
    genre: 'short_story',
    author: '小城故事',
    authorId: '3',
    wordCount: 3560,
    playCount: 4520,
    likeCount: 312,
    favoriteCount: 98,
    createdAt: '2024-02-28',
    updatedAt: '2024-03-01',
    hasPlayback: true,
    tags: ['青春', '爱情', '夏天'],
  },
  {
    id: '4',
    title: '致青春',
    content: '青春是一本太仓促的书，我们含着泪，一读再读。',
    excerpt: '青春是一本太仓促的书，我们含着泪，一读再读...',
    genre: 'essay',
    author: '追梦人',
    authorId: '4',
    wordCount: 1250,
    playCount: 6780,
    likeCount: 445,
    favoriteCount: 156,
    createdAt: '2024-02-20',
    updatedAt: '2024-02-20',
    hasPlayback: true,
    tags: ['青春', '感悟', '成长'],
  },
  {
    id: '5',
    title: '给未来的自己',
    content: '亲爱的自己，当你读到这封信时，希望你已经成为了想成为的人。',
    excerpt: '亲爱的自己，当你读到这封信时，希望你已经成为了想成为的人...',
    genre: 'letter',
    author: '时光旅人',
    authorId: '5',
    wordCount: 890,
    playCount: 3200,
    likeCount: 267,
    favoriteCount: 89,
    createdAt: '2024-02-15',
    updatedAt: '2024-02-15',
    hasPlayback: false,
    tags: ['书信', '未来', '自我'],
  },
  {
    id: '6',
    title: '咖啡馆的重逢',
    content: '第一幕 咖啡馆\n\n[场景] 现代都市风格咖啡馆，窗边座位...',
    excerpt: '第一幕 咖啡馆\n\n[场景] 现代都市风格咖啡馆...',
    genre: 'script',
    author: '剧作家',
    authorId: '6',
    wordCount: 4500,
    playCount: 2100,
    likeCount: 178,
    favoriteCount: 67,
    createdAt: '2024-02-10',
    updatedAt: '2024-02-10',
    hasPlayback: true,
    tags: ['剧本', '都市', '重逢'],
  },
]

// 工作卡片组件
export function WorkCard({ 
  work, 
  onLike, 
  onFavorite,
  isLiked,
  isFavorited,
}: { 
  work: Work
  onLike: (id: string, liked: boolean) => void
  onFavorite: (id: string, favorited: boolean) => void
  isLiked: boolean
  isFavorited: boolean
}) {
  return (
    <Card className="work-card group hover:shadow-lg transition-all duration-300">
      <CardContent className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <Badge variant="secondary" className="genre-tag">
            {genreLabels[work.genre]}
          </Badge>
        </div>

        {/* Title */}
        <Link href={`/read/${work.id}`}>
          <h3 className="text-lg font-serif font-semibold mb-1 group-hover:text-accent transition-colors line-clamp-1">
            {work.title}
          </h3>
        </Link>
        <Link href={`/author/${work.authorId}`} className="text-xs text-muted-foreground mb-2 hover:text-accent">
          @{work.author || '文痕君'}
        </Link>

        {/* Excerpt */}
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4 font-serif leading-relaxed">
          {work.excerpt}
        </p>

        {/* Footer - Only play count */}
        <div className="flex items-center justify-between pt-3 border-t border-border/50">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Eye className="h-3 w-3" />
            <span>{work.playCount}</span>
          </div>
          
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Heart className={cn("h-3 w-3", isLiked && "fill-red-500 text-red-500")} />
              <span>{work.likeCount}</span>
            </span>
            <span className="flex items-center gap-1">
              <Star className={cn("h-3 w-3", isFavorited && "fill-yellow-500 text-yellow-500")} />
              <span>{work.favoriteCount}</span>
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export function WorkLibrary() {
  const searchParams = useSearchParams()
  const [works, setWorks] = useState<Work[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedGenre, setSelectedGenre] = useState<Genre>(
    (searchParams.get('genre') as Genre) || 'all'
  )
  const [sortBy, setSortBy] = useState<SortBy>('latest')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [searchQuery, setSearchQuery] = useState('')
  const [likedWorks, setLikedWorks] = useState<Set<string>>(new Set())
  const [favoritedWorks, setFavoritedWorks] = useState<Set<string>>(new Set())
  const [lastPublished, setLastPublished] = useState<string | null>(null)

  // 加载数据
  const loadWorks = useCallback(async () => {
    setIsLoading(true)
    try {
      // 从API获取作品
      const params = new URLSearchParams({
        genre: selectedGenre,
        sortBy: sortBy,
      })
      
      const response = await fetch(`/api/works?${params}`)
      if (response.ok) {
        const data = await response.json()
        // 将API数据映射到Work接口
        const mappedWorks: Work[] = (data.works || []).map((w: any) => ({
          id: w.id,
          title: w.title,
          content: w.content || '',
          excerpt: (w.content || '').substring(0, 100) + '...',
          genre: w.genre as Genre,
          author: w.profiles?.username || '匿名',
          authorId: w.user_id,
          wordCount: w.word_count || 0,
          playCount: w.play_count || 0,
          likeCount: w.like_count || 0,
          favoriteCount: w.favorite_count || 0,
          createdAt: w.created_at,
          updatedAt: w.updated_at,
          hasPlayback: false,
          tags: w.tags || [],
        }))
        
        // 合并 localStorage 中的作品
        const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
        const mergedWorks = [...localWorks, ...mappedWorks]
        
        // 去重
        const uniqueWorks = mergedWorks.reduce((acc: Work[], work) => {
          if (!acc.find(w => w.id === work.id)) {
            acc.push(work)
          }
          return acc
        }, [])
        
        setWorks(uniqueWorks)
      } else {
        // API错误时只显示本地作品
        const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
        setWorks(localWorks)
      }
    } catch (error) {
      console.error('Failed to load works:', error)
      // 出错时只显示本地作品
      const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
      setWorks(localWorks)
    } finally {
      setIsLoading(false)
    }
  }, [selectedGenre, sortBy])

  // 监听作品发布事件
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'wenhen_work_published') {
        setLastPublished(e.newValue)
      }
    }
    
    window.addEventListener('storage', handleStorageChange)
    
    // 轮询检查本地存储变化
    const checkPublished = () => {
      const published = localStorage.getItem('wenhen_work_published')
      if (published && published !== lastPublished) {
        setLastPublished(published)
      }
    }
    
    const interval = setInterval(checkPublished, 1000)
    
    return () => {
      window.removeEventListener('storage', handleStorageChange)
      clearInterval(interval)
    }
  }, [lastPublished])

  // 当有新的发布时刷新数据
  useEffect(() => {
    if (lastPublished) {
      loadWorks()
      localStorage.removeItem('wenhen_work_published')
    }
  }, [lastPublished, loadWorks])

  // 初始加载
  useEffect(() => {
    loadWorks()
  }, [loadWorks])

  // 过滤作品
  const filteredWorks = works.filter(work => {
    // 按题材筛选
    if (selectedGenre !== 'all' && work.genre !== selectedGenre) {
      return false
    }
    // 按搜索词筛选
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        work.title.toLowerCase().includes(query) ||
        work.content.toLowerCase().includes(query) ||
        work.author.toLowerCase().includes(query) ||
        work.tags.some(tag => tag.toLowerCase().includes(query))
      )
    }
    return true
  })

  // 处理点赞
  const handleLike = async (workId: string, liked: boolean) => {
    // 更新本地状态
    setLikedWorks(prev => {
      const newSet = new Set(prev)
      if (liked) {
        newSet.add(workId)
      } else {
        newSet.delete(workId)
      }
      return newSet
    })

    // 更新作品计数
    setWorks(prev => prev.map(work => {
      if (work.id === workId) {
        return {
          ...work,
          likeCount: liked ? work.likeCount + 1 : work.likeCount - 1
        }
      }
      return work
    }))

    // 调用API
    try {
      await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workId, liked }),
      })
    } catch (error) {
      console.error('Failed to update like:', error)
    }
  }

  // 处理收藏
  const handleFavorite = async (workId: string, favorited: boolean) => {
    // 更新本地状态
    setFavoritedWorks(prev => {
      const newSet = new Set(prev)
      if (favorited) {
        newSet.add(workId)
      } else {
        newSet.delete(workId)
      }
      return newSet
    })

    // 更新作品计数
    setWorks(prev => prev.map(work => {
      if (work.id === workId) {
        return {
          ...work,
          favoriteCount: favorited ? work.favoriteCount + 1 : work.favoriteCount - 1
        }
      }
      return work
    }))

    // 调用API
    try {
      await fetch('/api/favorites', {
        method: favorited ? 'POST' : 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workId }),
      })
      // 通知其他组件刷新收藏列表
      window.dispatchEvent(new CustomEvent('favorites_updated', { detail: { workId, favorited } }))
    } catch (error) {
      console.error('Failed to update favorite:', error)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card/50 border-b">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-2xl font-serif font-bold mb-4">作品库</h1>
          
          {/* 搜索和筛选 */}
          <div className="flex flex-col md:flex-row gap-4">
            {/* 搜索框 */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="搜索作品..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>

            {/* 排序 */}
            <div className="flex items-center gap-2">
              <SortAsc className="h-4 w-4 text-muted-foreground" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortBy)}
                className="px-3 py-2 rounded-lg border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-accent"
              >
                {Object.entries(sortLabels).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>

            {/* 视图切换 */}
            <div className="flex items-center gap-1 border border-input rounded-lg overflow-hidden">
              <button
                onClick={() => setViewMode('grid')}
                className={cn(
                  "p-2 transition-colors",
                  viewMode === 'grid' ? "bg-accent text-accent-foreground" : "bg-background hover:bg-muted"
                )}
              >
                <Grid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={cn(
                  "p-2 transition-colors",
                  viewMode === 'list' ? "bg-accent text-accent-foreground" : "bg-background hover:bg-muted"
                )}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 题材筛选 */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          <Filter className="h-4 w-4 text-muted-foreground flex-shrink-0" />
          {Object.entries(genreLabels).map(([value, label]) => (
            <button
              key={value}
              onClick={() => setSelectedGenre(value as Genre)}
              className={cn(
                "px-4 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors",
                selectedGenre === value 
                  ? "bg-accent text-accent-foreground" 
                  : "bg-muted hover:bg-muted/80"
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* 作品列表 */}
      <div className="container mx-auto px-4 py-6">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-5">
                  <div className="h-6 bg-muted rounded w-1/3 mb-3" />
                  <div className="h-4 bg-muted rounded w-full mb-2" />
                  <div className="h-4 bg-muted rounded w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredWorks.length === 0 ? (
          <div className="text-center py-12">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">暂无作品</h3>
            <p className="text-muted-foreground text-sm">
              {searchQuery ? '尝试使用不同的关键词' : '还没有作品，试试其他题材'}
            </p>
          </div>
        ) : (
          <>
            <div className="text-sm text-muted-foreground mb-4">
              共 {filteredWorks.length} 部作品
            </div>
            <div className={cn(
              viewMode === 'grid' 
                ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
                : "space-y-4"
            )}>
              {filteredWorks.map((work) => (
                <WorkCard
                  key={work.id}
                  work={work}
                  onLike={handleLike}
                  onFavorite={handleFavorite}
                  isLiked={likedWorks.has(work.id)}
                  isFavorited={favoritedWorks.has(work.id)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

export type { Work, Genre, SortBy }
