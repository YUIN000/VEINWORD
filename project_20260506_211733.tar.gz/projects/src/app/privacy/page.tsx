'use client'

import Link from 'next/link'
import { ArrowLeft, Feather } from 'lucide-react'

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link 
            href="/" 
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>返回首页</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="flex items-center gap-3 mb-8">
          <Feather className="h-8 w-8 text-accent" />
          <h1 className="text-3xl font-serif font-bold">隐私政策</h1>
        </div>

        <div className="prose prose-stone dark:prose-invert max-w-none space-y-6 font-serif">
          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">引言</h2>
            <p className="text-muted-foreground leading-relaxed">
              VEINWORD（「我们」）非常重视用户的隐私和个人信息保护。本隐私政策旨在向您说明我们如何收集、使用、存储和保护您的个人信息，以及您享有的相关权利。请您在使用我们的服务前，仔细阅读并了解本政策。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">一、信息收集</h2>
            <p className="text-muted-foreground mb-4">我们收集的信息包括：</p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span><strong className="text-foreground">注册信息</strong>：用户名、邮箱地址（用于账号注册和登录验证）。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span><strong className="text-foreground">个人资料</strong>：头像、昵称、个人简介（您自愿提供的信息）。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span><strong className="text-foreground">创作内容</strong>：您发布的作品、评论、回放数据等您主动创作的内容。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span><strong className="text-foreground">使用信息</strong>：浏览记录、收藏、关注等互动数据。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">5.</span>
                <span><strong className="text-foreground">设备信息</strong>：设备类型、浏览器类型等基本信息（用于优化服务体验）。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">二、信息使用</h2>
            <p className="text-muted-foreground mb-4">我们收集的信息将用于：</p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>提供、维护和改进我们的服务</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>处理您的注册、登录和账号管理</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>展示您的作品和创作内容</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>发送服务通知、消息提醒</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>统计分析和产品优化</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">三、信息存储</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>您的个人信息将存储在我们的服务器上。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>我们会采取必要的安全措施保护您的信息，防止数据被非法访问、篡改或泄露。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>您的作品内容将永久保存，除非您主动删除账号。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>您的账号注销后，我们将删除或匿名化您的个人信息。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">四、信息共享</h2>
            <p className="text-muted-foreground mb-4">除以下情况外，我们不会与第三方共享您的个人信息：</p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>获得您的明确同意后</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>根据法律法规、法律程序或政府要求</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>保护 VEINWORD 或其他用户的权利和安全</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">五、您的权利</h2>
            <p className="text-muted-foreground mb-4">您对自己的个人信息享有以下权利：</p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span><strong className="text-foreground">访问权</strong>：查看您的个人信息</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span><strong className="text-foreground">更正权</strong>：修改不准确的个人信息</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span><strong className="text-foreground">删除权</strong>：删除您的账号或特定信息</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span><strong className="text-foreground">注销权</strong>：随时注销您的账号</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">六、Cookie 使用</h2>
            <p className="text-muted-foreground leading-relaxed">
              我们使用 Cookie 和类似技术来记住您的偏好设置、优化用户体验。您可以通过浏览器设置拒绝 Cookie，但这可能会影响部分功能的正常使用。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">七、未成年人保护</h2>
            <p className="text-muted-foreground leading-relaxed">
              我们非常重视对未成年人信息的保护。如果您是未满18周岁的未成年人，请在监护人的陪同下阅读本政策，并在监护人同意的情况下使用我们的服务。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">八、政策更新</h2>
            <p className="text-muted-foreground leading-relaxed">
              我们可能会不时更新本隐私政策。更新后的政策将在本页面发布，请定期查阅。如有重大变更，我们将通过站内通知或邮件等方式告知您。
            </p>
            <p className="text-sm text-muted-foreground/70 mt-4">
              最后更新日期：2026年1月
            </p>
          </section>

          <section className="text-center py-8">
            <p className="text-lg font-serif italic text-muted-foreground">
              「守护文字，守护隐私」
            </p>
            <p className="text-sm text-muted-foreground/70 mt-2">
              如有疑问，请联系：privacy@veinword.com
            </p>
          </section>
        </div>
      </main>
    </div>
  )
}
