'use client'

import { WritingEditor } from '@/components/editor'

export default function WritePage() {
  return <WritingEditor />
}
