'use client'

import Link from 'next/link'
import { ArrowLeft, Feather } from 'lucide-react'

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link 
            href="/" 
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>返回首页</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="flex items-center gap-3 mb-8">
          <Feather className="h-8 w-8 text-accent" />
          <h1 className="text-3xl font-serif font-bold">关于我们</h1>
        </div>

        <div className="prose prose-stone dark:prose-invert max-w-none space-y-6 font-serif">
          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">关于 VEINWORD</h2>
            <p className="text-muted-foreground leading-relaxed">
              VEINWORD，中文名「文痕」，意为「文字落下的痕迹」。我们是一个专注于中文创意写作的平台，致力于为每一位热爱文字的人提供一个纯粹、优雅的创作与阅读空间。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">我们的理念</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span><strong className="text-foreground">尊重原创</strong>：每一篇作品都是创作者心血的结晶，我们尊重每一位作者的知识产权。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span><strong className="text-foreground">纯粹体验</strong>：去除繁杂的功能干扰，让文字成为主角，还原最纯粹的阅读与写作体验。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span><strong className="text-foreground">文脉传承</strong>：以古典文学为底蕴，融合现代审美，庚续中华文脉。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span><strong className="text-foreground">创作赋能</strong>：通过回放录制、旁注记录等创新功能，帮助作者捕捉灵感、记录创作过程。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">支持多种体裁</h2>
            <p className="text-muted-foreground mb-4">
              我们为不同类型的创作提供专业支持：
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {['诗歌', '小说', '随笔', '短故事', '剧本', '书信'].map((genre) => (
                <div key={genre} className="bg-background/50 rounded-md px-4 py-2 text-center text-sm text-muted-foreground">
                  {genre}
                </div>
              ))}
            </div>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">联系我们</h2>
            <p className="text-muted-foreground">
              如果您有任何问题、建议或合作意向，欢迎通过以下方式联系我们：
            </p>
            <div className="mt-4 text-muted-foreground">
              <p>邮箱：doubley999@qq.com</p>
            </div>
          </section>

          <section className="text-center py-8">
            <p className="text-lg font-serif italic text-muted-foreground">
              「庚续文脉，以笔为痕」
            </p>
            <p className="text-sm text-muted-foreground/70 mt-2">
              VEINWORD 团队 · 2026
            </p>
          </section>
        </div>
      </main>
    </div>
  )
}
