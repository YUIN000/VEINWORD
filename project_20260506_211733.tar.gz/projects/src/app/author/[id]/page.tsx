import { AuthorProfile } from '@/components/home'
import { use } from 'react'

export default function AuthorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  return <AuthorProfile authorId={id} />
}
