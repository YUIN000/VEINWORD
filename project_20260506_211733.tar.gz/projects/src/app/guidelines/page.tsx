'use client'

import Link from 'next/link'
import { ArrowLeft, Feather } from 'lucide-react'

export default function GuidelinesPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link 
            href="/" 
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>返回首页</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="flex items-center gap-3 mb-8">
          <Feather className="h-8 w-8 text-accent" />
          <h1 className="text-3xl font-serif font-bold">创作公约</h1>
        </div>

        <div className="prose prose-stone dark:prose-invert max-w-none space-y-6 font-serif">
          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">前言</h2>
            <p className="text-muted-foreground leading-relaxed">
              VEINWORD 是一个专注于中文创意写作的平台，旨在为创作者和读者提供一个健康、积极的交流环境。为了维护良好的社区氛围，我们制定以下创作公约，请所有用户共同遵守。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">一、尊重原创</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>所有发布作品必须为用户原创，或已获得原作者授权的转载。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>禁止抄袭、盗用他人作品，一经发现将严肃处理。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>引用他人作品时，请注明出处，尊重知识产权。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>如需转载他人作品，请通过站内消息联系原作者获得授权。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">二、内容规范</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>禁止发布违反法律法规、公序良俗的内容。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>禁止发布涉及暴力、色情、血腥等不适宜内容。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>禁止发布虚假信息、诈骗内容或垃圾广告。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>禁止发布侵犯他人隐私、名誉的内容。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">5.</span>
                <span>鼓励积极向上、富有创意的作品，传播正能量。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">三、互动礼仪</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>评论他人作品时，请保持礼貌和尊重。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>提出意见或建议时，请注意表达方式，友善交流。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>禁止人身攻击、恶意诋毁或骚扰其他用户。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>关注他人作品时，请真诚以待，良性互动。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">四、账号管理</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>请使用真实的个人信息注册账号，方便其他用户识别。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>妥善保管账号密码，不要将账号借给他人使用。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>一个用户仅限注册一个账号，禁止多账号操作。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>如发现账号异常，请及时联系我们。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">五、违规处理</h2>
            <p className="text-muted-foreground leading-relaxed">
              对于违反本公约的行为，VEINWORD 将根据违规程度采取以下措施：警告、删除内容、限制账号功能、暂时封禁账号、永久注销账号等。我们承诺公平、公正地处理每一例违规事件。
            </p>
          </section>

          <section className="text-center py-8">
            <p className="text-lg font-serif italic text-muted-foreground">
              「以文会友，以诚相待」
            </p>
            <p className="text-sm text-muted-foreground/70 mt-2">
              让我们共同维护 VEINWORD 的良好创作氛围
            </p>
          </section>
        </div>
      </main>
    </div>
  )
}
