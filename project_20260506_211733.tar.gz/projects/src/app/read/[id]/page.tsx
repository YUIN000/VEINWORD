'use client'

import { useState, useEffect } from 'react'
import { use } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { ReaderContent } from '@/components/reader'
import { Loader2, Pencil, Trash2, MessageCircle, Send, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/auth-context'

interface Comment {
  id: string
  author: string
  authorId: string
  content: string
  createdAt: string
}

interface WorkData {
  id: string
  title: string
  content: string
  author: string
  authorId?: string
  genre: string
  wordCount: number
  playCount: number
  likeCount: number
  visibility?: string
  createdAt: string
  hasPlayback: boolean
  operations?: any[]
}

export default function ReadPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const { user } = useAuth()
  const [work, setWork] = useState<WorkData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  const isAuthor = user && work && (user.id === work.authorId || user.id === work.authorId?.split('-').slice(-1)[0])

  useEffect(() => {
    async function loadWork() {
      setLoading(true)
      setError(null)
      
      try {
        // 1. 先检查 localStorage
        const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
        const localWork = localWorks.find((w: any) => w.id === id)
        
        if (localWork) {
          setWork({
            id: localWork.id,
            title: localWork.title,
            content: localWork.content,
            author: localWork.author || '佚名',
            authorId: localWork.authorId,
            genre: localWork.genre || '随笔',
            wordCount: localWork.wordCount || localWork.content?.length || 0,
            playCount: localWork.playCount || 0,
            likeCount: localWork.likeCount || 0,
            visibility: localWork.visibility,
            createdAt: localWork.date || new Date().toISOString(),
            hasPlayback: Array.isArray(localWork.operations) && localWork.operations.length > 0,
            operations: localWork.operations,
          })
          setLoading(false)
          // 加载评论
          loadComments(id)
          return
        }
        
        // 2. 如果 localStorage 没有，从 API 获取
        const response = await fetch(`/api/works/${id}`)
        if (response.ok) {
          const data = await response.json()
          if (data.work) {
            const w = data.work
            setWork({
              id: w.id,
              title: w.title,
              content: w.content,
              author: w.profiles?.username || '佚名',
              authorId: w.user_id,
              genre: w.genre === 'poetry' ? '诗歌' : 
                     w.genre === 'essay' ? '随笔' : 
                     w.genre === 'story' ? '短故事' : 
                     w.genre === 'novel' ? '小说' : 
                     w.genre === 'letter' ? '书信' : 
                     w.genre === 'script' ? '剧本' : '随笔',
              wordCount: w.word_count || 0,
              playCount: w.play_count || 0,
              likeCount: w.like_count || 0,
              visibility: w.visibility,
              createdAt: w.created_at,
              hasPlayback: Array.isArray(w.operations) && w.operations.length > 0,
              operations: w.operations,
            })
            setLoading(false)
            loadComments(id)
            return
          }
        }
        
        setError('作品不存在')
      } catch (err) {
        console.error('Failed to load work:', err)
        setError('加载失败')
      } finally {
        setLoading(false)
      }
    }
    
    loadWork()
  }, [id])

  // 加载评论
  const loadComments = (workId: string) => {
    const allComments = JSON.parse(localStorage.getItem('wenhen_comments') || '[]')
    const workComments = allComments.filter((c: any) => c.workId === workId)
    setComments(workComments)
  }

  // 提交评论
  const handleSubmitComment = async () => {
    if (!newComment.trim() || !user) return
    
    setIsSubmitting(true)
    try {
      const comment: Comment = {
        id: `comment-${Date.now()}`,
        author: user.username,
        authorId: user.id,
        content: newComment.trim(),
        createdAt: new Date().toISOString(),
      }
      
      const allComments = JSON.parse(localStorage.getItem('wenhen_comments') || '[]')
      allComments.push({ ...comment, workId: id })
      localStorage.setItem('wenhen_comments', JSON.stringify(allComments))
      
      // 添加通知
      if (work && work.authorId !== user.id) {
        const notifications = JSON.parse(localStorage.getItem('wenhen_notifications') || '[]')
        notifications.unshift({
          id: `notif-${Date.now()}`,
          type: 'comment',
          workId: id,
          workTitle: work.title,
          fromUser: user.username,
          fromUserId: user.id,
          content: newComment.trim().substring(0, 50),
          createdAt: new Date().toISOString(),
          read: false,
        })
        localStorage.setItem('wenhen_notifications', JSON.stringify(notifications))
      }
      
      setComments([...comments, comment])
      setNewComment('')
    } finally {
      setIsSubmitting(false)
    }
  }

  // 删除作品
  const handleDelete = () => {
    // 从 localStorage 删除
    const localWorks = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
    const filtered = localWorks.filter((w: any) => w.id !== id)
    localStorage.setItem('wenhen_works', JSON.stringify(filtered))
    
    // 删除相关评论
    const allComments = JSON.parse(localStorage.getItem('wenhen_comments') || '[]')
    const filteredComments = allComments.filter((c: any) => c.workId !== id)
    localStorage.setItem('wenhen_comments', JSON.stringify(filteredComments))
    
    // 触发刷新
    localStorage.setItem('wenhen_work_published', Date.now().toString())
    
    router.push('/')
  }

  // 跳转到编辑页面
  const handleEdit = () => {
    if (work) {
      // 将作品数据存入sessionStorage，通过URL传递作品ID
      sessionStorage.setItem('edit_work', JSON.stringify(work))
      router.push(`/write?edit=${work.id}`)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !work) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4">
        <h1 className="text-2xl font-serif">{error || '作品不存在'}</h1>
        <Link href="/" className="text-accent hover:underline">返回首页</Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* 顶部操作栏 */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="text-accent hover:underline">返回首页</Link>
          <div className="flex items-center gap-2">
            {/* 评论按钮 */}
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="gap-1"
            >
              <MessageCircle className="h-4 w-4" />
              <span>{comments.length}</span>
            </Button>
            
            {/* 作者操作按钮 */}
            {isAuthor && (
              <>
                <Button variant="ghost" size="sm" onClick={handleEdit} className="gap-1">
                  <Pencil className="h-4 w-4" />
                  <span>编辑</span>
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowDeleteConfirm(true)}
                  className="gap-1 text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 评论面板 */}
      {showComments && (
        <div className="border-b bg-muted/30">
          <div className="container mx-auto px-4 py-4 max-w-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">评论 ({comments.length})</h3>
              <button onClick={() => setShowComments(false)} className="text-muted-foreground hover:text-foreground">
                <X className="h-4 w-4" />
              </button>
            </div>
            
            {/* 评论列表 */}
            <div className="space-y-4 mb-4 max-h-96 overflow-y-auto">
              {comments.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">暂无评论，快来抢沙发~</p>
              ) : (
                comments.map((comment) => (
                  <div key={comment.id} className="bg-background rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{comment.author}</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(comment.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm">{comment.content}</p>
                  </div>
                ))
              )}
            </div>
            
            {/* 评论输入框 */}
            {user ? (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSubmitComment()}
                  placeholder="写评论..."
                  className="flex-1 px-3 py-2 rounded-md border bg-background text-sm"
                />
                <Button 
                  size="sm" 
                  onClick={handleSubmitComment}
                  disabled={isSubmitting || !newComment.trim()}
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <p className="text-center text-sm text-muted-foreground py-2">
                <Link href="/login" className="text-primary hover:underline">登录</Link>后发表评论
              </p>
            )}
          </div>
        </div>
      )}

      {/* 删除确认对话框 */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
          <div className="bg-background rounded-lg p-6 max-w-sm mx-4">
            <h3 className="text-lg font-medium mb-2">确认删除</h3>
            <p className="text-muted-foreground mb-4">确定要删除「{work.title}」吗？此操作不可撤销。</p>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setShowDeleteConfirm(false)}>
                取消
              </Button>
              <Button variant="destructive" className="flex-1" onClick={handleDelete}>
                删除
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* 作品内容 */}
      <ReaderContent {...work} />
    </div>
  )
}
