'use client'

import { useState, useEffect, useCallback, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Search, 
  Feather, 
  Clock, 
  Eye, 
  Heart,
  BookOpen,
  User,
  Sparkles,
  Filter,
  SortAsc,
  X,
  ArrowLeft,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

// 题材类型
type Genre = 'all' | 'poetry' | 'essay' | 'story' | 'novel' | 'letter' | 'script' | 'diary'

const genreLabels: Record<Genre, string> = {
  all: '全部',
  poetry: '诗歌',
  essay: '随笔',
  story: '短故事',
  novel: '小说',
  letter: '书信',
  script: '剧本',
  diary: '日记',
}

// 排序类型
type SortBy = 'relevance' | 'latest' | 'popular' | 'hot'

const sortLabels: Record<SortBy, string> = {
  relevance: '相关度',
  latest: '最新',
  popular: '最多浏览',
  hot: '最热',
}

// 搜索结果类型
interface SearchResult {
  id: string
  title: string
  content: string
  excerpt: string
  genre: Genre
  author: string
  authorId: string
  wordCount: number
  playCount: number
  likeCount: number
  createdAt: string
  updatedAt: string
  tags: string[]
}

// 模拟搜索数据
const mockSearchResults: SearchResult[] = [
  {
    id: '1',
    title: '春江花月夜',
    content: '春江潮水连海平，海上明月共潮生。滟滟随波千万里，何处春江无月明！',
    excerpt: '春江潮水连海平，海上明月共潮生...',
    genre: 'poetry',
    author: '张若虚',
    authorId: '1',
    wordCount: 252,
    playCount: 12580,
    likeCount: 856,
    createdAt: '2024-03-15',
    updatedAt: '2024-03-15',
    tags: ['唐诗', '夜景', '抒情'],
  },
  {
    id: '2',
    title: '雨巷',
    content: '撑着油纸伞，独自彷徨在悠长、悠长又寂寥的雨巷，我希望逢着一个丁香一样地结着愁怨的姑娘。',
    excerpt: '撑着油纸伞，独自彷徨在悠长、悠长又寂寥的雨巷...',
    genre: 'poetry',
    author: '戴望舒',
    authorId: '2',
    wordCount: 186,
    playCount: 8920,
    likeCount: 623,
    createdAt: '2024-03-10',
    updatedAt: '2024-03-10',
    tags: ['现代诗', '雨巷', '姑娘'],
  },
  {
    id: '3',
    title: '那个夏天的记忆',
    content: '那年夏天，我遇见了她。她穿着白色的连衣裙，在阳光下笑得像朵花。',
    excerpt: '那年夏天，我遇见了她。她穿着白色的连衣裙...',
    genre: 'story',
    author: '小城故事',
    authorId: '3',
    wordCount: 3560,
    playCount: 4520,
    likeCount: 312,
    createdAt: '2024-02-28',
    updatedAt: '2024-03-01',
    tags: ['青春', '爱情', '夏天'],
  },
]

function SearchPageContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  
  const initialQuery = searchParams.get('q') || ''
  
  const [query, setQuery] = useState(initialQuery)
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [selectedGenre, setSelectedGenre] = useState<Genre>('all')
  const [sortBy, setSortBy] = useState<SortBy>('relevance')
  const [hasSearched, setHasSearched] = useState(false)

  // 执行搜索
  const performSearch = useCallback(async (searchQuery: string, genre: Genre, sort: SortBy) => {
    if (!searchQuery.trim()) {
      setResults([])
      setHasSearched(false)
      return
    }

    setIsLoading(true)
    setHasSearched(true)

    try {
      // 获取用户发布的作品
      const localWorks = (() => {
        try {
          const works = JSON.parse(localStorage.getItem('wenhen_works') || '[]')
          return works.filter((w: { visibility: string }) => w.visibility === 'public')
        } catch { return [] }
      })()

      // 将localStorage作品转换为搜索结果格式
      const localResults: SearchResult[] = localWorks
        .filter((w: { title: string; content: string; genre: Genre }) => 
          w.title.includes(searchQuery) || w.content.includes(searchQuery)
        )
        .map((w: { id: string; title: string; content: string; genre: Genre; author: string; authorId: string; date: string; visibility: string }) => ({
          id: w.id,
          title: w.title,
          content: w.content,
          excerpt: w.content.slice(0, 50) + '...',
          genre: w.genre,
          author: w.author,
          authorId: w.authorId || '',
          wordCount: w.content.length,
          playCount: 0,
          likeCount: 0,
          createdAt: w.date,
          updatedAt: w.date,
          tags: [],
        }))

      const params = new URLSearchParams({
        q: searchQuery,
        ...(genre !== 'all' && { genre }),
        sort,
      })

      const response = await fetch(`/api/search?${params}`)
      const data = await response.json()

      if (response.ok) {
        // 合并API结果和本地结果
        const apiResults = (data.results || []).filter((r: SearchResult) => r.genre !== genre || genre === 'all')
        setResults([...localResults, ...apiResults])
      } else {
        // 如果API失败，使用本地数据和模拟数据
        const filtered = mockSearchResults.filter(item => 
          item.title.includes(searchQuery) || 
          item.content.includes(searchQuery) ||
          item.tags.some(tag => tag.includes(searchQuery))
        )
        setResults([...localResults, ...filtered])
      }
    } catch (error) {
      // 使用模拟数据作为后备
      const filtered = mockSearchResults.filter(item => 
        item.title.includes(searchQuery) || 
        item.content.includes(searchQuery) ||
        item.tags.some(tag => tag.includes(searchQuery))
      )
      setResults(filtered)
    } finally {
      setIsLoading(false)
    }
  }, [])

  // 初始搜索
  useEffect(() => {
    if (initialQuery) {
      performSearch(initialQuery, selectedGenre, sortBy)
    }
  }, [initialQuery, performSearch, selectedGenre, sortBy])

  // 处理搜索提交
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    
    // 更新URL
    const params = new URLSearchParams()
    if (query) params.set('q', query)
    router.push(`/search?${params.toString()}`)
    
    performSearch(query, selectedGenre, sortBy)
  }

  // 清除搜索
  const clearSearch = () => {
    setQuery('')
    setResults([])
    setHasSearched(false)
    router.push('/search')
  }

  // 格式化数字
  const formatNumber = (num: number) => {
    if (num >= 10000) {
      return (num / 10000).toFixed(1) + 'w'
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k'
    }
    return num.toString()
  }

  // 格式化日期
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    
    if (days === 0) return '今天'
    if (days === 1) return '昨天'
    if (days < 7) return `${days}天前`
    if (days < 30) return `${Math.floor(days / 7)}周前`
    if (days < 365) return `${Math.floor(days / 30)}月前`
    return `${Math.floor(days / 365)}年前`
  }

  return (
    <div className="min-h-screen bg-background pt-16">
      {/* 搜索头部 */}
      <div className="sticky top-16 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <Button variant="ghost" size="icon" onClick={() => router.push('/')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">搜索</h1>
          </div>
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="搜索作品、作者、标签..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-10 pr-10"
                autoFocus
              />
              {query && (
                <button
                  type="button"
                  onClick={clearSearch}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <Button type="submit">搜索</Button>
          </form>
        </div>
      </div>

      {/* 搜索内容 */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* 筛选和排序 */}
        {hasSearched && (
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2 overflow-x-auto">
              {Object.entries(genreLabels).map(([value, label]) => (
                <Badge
                  key={value}
                  variant={selectedGenre === value ? 'default' : 'outline'}
                  className={cn(
                    'cursor-pointer transition-colors',
                    selectedGenre === value ? 'bg-accent' : 'hover:bg-accent/10'
                  )}
                  onClick={() => setSelectedGenre(value as Genre)}
                >
                  {label}
                </Badge>
              ))}
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortBy)}
                className="text-sm bg-transparent border-none outline-none cursor-pointer"
              >
                {Object.entries(sortLabels).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
          </div>
        )}

        {/* 搜索结果 */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="pt-6">
                  <div className="h-6 bg-muted rounded w-1/3 mb-2" />
                  <div className="h-4 bg-muted rounded w-full mb-2" />
                  <div className="h-4 bg-muted rounded w-2/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : hasSearched && results.length === 0 ? (
          <div className="text-center py-12">
            <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">未找到相关作品</h3>
            <p className="text-muted-foreground text-sm">
              尝试使用不同的关键词，或检查筛选条件
            </p>
          </div>
        ) : !hasSearched ? (
          <div className="text-center py-12">
            <Sparkles className="h-12 w-12 text-accent mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">开始搜索</h3>
            <p className="text-muted-foreground text-sm">
              输入关键词搜索作品、作者或标签
            </p>
            
            {/* 热门搜索 */}
            <div className="mt-8">
              <h4 className="text-sm font-medium mb-3">热门标签</h4>
              <div className="flex flex-wrap justify-center gap-2">
                {['青春', '爱情', '回忆', '孤独', '梦想', '远方', '春天', '夜晚'].map((tag) => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className="cursor-pointer hover:bg-accent/10"
                    onClick={() => {
                      setQuery(tag)
                      performSearch(tag, selectedGenre, sortBy)
                    }}
                  >
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground mb-4">
              找到 {results.length} 个结果
            </div>
            
            {results.map((result) => (
              <Link key={result.id} href={`/read/${result.id}`}>
                <Card className="hover:bg-accent/5 transition-colors cursor-pointer">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-serif font-medium text-lg hover:text-accent transition-colors">
                          {result.title}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                          <User className="h-3 w-3" />
                          <span>{result.author}</span>
                          <span>·</span>
                          <Badge variant="outline" className="text-xs">
                            {genreLabels[result.genre as Genre]}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {result.excerpt}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <BookOpen className="h-3 w-3" />
                        {result.wordCount}字
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {formatNumber(result.playCount)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="h-3 w-3" />
                        {formatNumber(result.likeCount)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDate(result.updatedAt)}
                      </span>
                    </div>
                    
                    {result.tags.length > 0 && (
                      <div className="flex gap-1 mt-3">
                        {result.tags.slice(0, 3).map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">加载中...</div>
      </div>
    }>
      <SearchPageContent />
    </Suspense>
  )
}
