import { Suspense } from 'react'
import { WorkLibrary } from '@/components/home'
import { Loader2 } from 'lucide-react'

export default function LibraryPage() {
  return (
    <div className="container mx-auto px-4 py-8 pt-20">
      <div className="mb-8">
        <h1 className="text-3xl font-serif font-bold mb-2">作品库</h1>
        <p className="text-muted-foreground">发现优质原创作品，感受文字的力量</p>
      </div>
      <Suspense fallback={
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      }>
        <WorkLibrary />
      </Suspense>
    </div>
  )
}
