import type { Metadata } from 'next'
import './globals.css'
import { MainNav, Footer } from '@/components/layout'
import { AuthProvider } from '@/contexts/auth-context'
import { FontLoader } from '@/components/font-loader'

export const metadata: Metadata = {
  title: 'VEINWORD - 文字落下的痕迹',
  description: '一个复古高级风格的写作阅读平台，支持写作过程回放，让每一笔都有迹可循。',
  keywords: ['写作', '阅读', '创作', '文学作品', '写作回放'],
  authors: [{ name: 'VEINWORD' }],
  icons: {
    icon: '/favicon.ico',
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="zh-CN">
      <body className="min-h-screen flex flex-col">
        <AuthProvider>
          <FontLoader />
          <MainNav />
          <main className="flex-1">{children}</main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  )
}
