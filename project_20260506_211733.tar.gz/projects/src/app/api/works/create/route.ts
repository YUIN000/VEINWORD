import { createClient } from '@/storage/database/supabase-server'

// 创建新作品
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, title, content, genre, operations, tags, username } = body

    if (!userId || !title || !content || !genre) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 })
    }

    const supabase = createClient()
    
    // 先确保用户 profile 存在
    const { data: existingProfile } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .single()
    
    if (!existingProfile) {
      // 创建 profile
      await supabase.from('profiles').insert({
        id: userId,
        username: username || '匿名用户',
        email: '',
        bio: '',
        created_at: new Date().toISOString(),
      })
    }
    
    const wordCount = content.length
    
    const { data, error } = await supabase
      .from('works')
      .insert({
        user_id: userId,
        title: title.trim(),
        content: content,
        genre: genre,
        status: 'published',
        word_count: wordCount,
        play_count: 0,
        like_count: 0,
        favorite_count: 0,
        view_count: 0,
        operations: operations || [],
        tags: tags || [],
        is_featured: false,
      })
      .select()
      .single()
    
    if (error) {
      console.error('Supabase error:', error)
      return Response.json({ error: error.message }, { status: 500 })
    }
    
    return Response.json({ work: data })
  } catch (error) {
    console.error('创建作品失败:', error)
    return Response.json({ error: '创建作品失败' }, { status: 500 })
  }
}
