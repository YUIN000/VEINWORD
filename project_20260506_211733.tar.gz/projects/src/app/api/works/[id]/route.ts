import { createClient } from '@/storage/database/supabase-server'

// 获取单个作品
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    const supabase = createClient()
    
    const { data: work, error } = await supabase
      .from('works')
      .select(`
        *,
        profiles (
          id,
          username,
          avatar_key,
          bio
        ),
        operations
      `)
      .eq('id', id)
      .single()
    
    if (error || !work) {
      return Response.json({ error: '作品不存在' }, { status: 404 })
    }
    
    // 检查访问权限
    if (work.status !== 'published' && work.user_id !== userId) {
      return Response.json({ error: '无权访问' }, { status: 403 })
    }
    
    // 增加浏览数
    if (userId !== work.user_id) {
      await supabase.rpc('increment_plays', { work_id: id })
    }
    
    return Response.json({ work })
  } catch (error) {
    console.error('获取作品失败:', error)
    return Response.json({ error: '获取作品失败' }, { status: 500 })
  }
}

// 更新作品
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { userId, title, content, genre, tags, status, operations } = body
    
    const supabase = createClient()
    
    // 检查作品归属
    const { data: existing } = await supabase
      .from('works')
      .select('user_id')
      .eq('id', id)
      .single()
    
    if (!existing || existing.user_id !== userId) {
      return Response.json({ error: '无权修改' }, { status: 403 })
    }
    
    const updateData: Record<string, unknown> = {}
    if (title !== undefined) updateData.title = title
    if (content !== undefined) updateData.content = content
    if (genre !== undefined) updateData.genre = genre
    if (tags !== undefined) updateData.tags = tags
    if (status !== undefined) updateData.status = status
    if (operations !== undefined) updateData.operations = operations
    
    if (content !== undefined) {
      updateData.word_count = content.replace(/\s/g, '').length
    }
    
    updateData.updated_at = new Date().toISOString()
    
    const { data: work, error } = await supabase
      .from('works')
      .update(updateData)
      .eq('id', id)
      .select()
      .single()
    
    if (error) throw error
    
    return Response.json({ work, success: true })
  } catch (error) {
    console.error('更新作品失败:', error)
    return Response.json({ error: '更新作品失败' }, { status: 500 })
  }
}

// 删除作品
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    const supabase = createClient()
    
    // 检查作品归属
    const { data: existing } = await supabase
      .from('works')
      .select('user_id')
      .eq('id', id)
      .single()
    
    if (!existing || existing.user_id !== userId) {
      return Response.json({ error: '无权删除' }, { status: 403 })
    }
    
    const { error } = await supabase
      .from('works')
      .delete()
      .eq('id', id)
    
    if (error) throw error
    
    return Response.json({ success: true })
  } catch (error) {
    console.error('删除作品失败:', error)
    return Response.json({ error: '删除作品失败' }, { status: 500 })
  }
}
