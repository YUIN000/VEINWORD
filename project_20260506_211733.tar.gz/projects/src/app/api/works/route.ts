import { createClient } from '@/storage/database/supabase-server'

// 获取作品列表
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const genre = searchParams.get('genre')
    const status = searchParams.get('status')
    const search = searchParams.get('search')
    const sortBy = searchParams.get('sortBy') || 'created_at'
    const sortOrder = searchParams.get('sortOrder') || 'desc'
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')
    
    const supabase = createClient()
    
    let query = supabase
      .from('works')
      .select(`
        *,
        profiles (
          id,
          username,
          avatar_key
        )
      `)
      .eq('status', 'published')
    
    if (userId) {
      query = query.eq('user_id', userId)
    }
    
    if (genre && genre !== 'all') {
      query = query.eq('genre', genre)
    }
    
    if (status) {
      query = query.eq('status', status)
    }
    
    if (search) {
      query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`)
    }
    
    // 映射排序参数到数据库列名
    const sortColumnMap: Record<string, string> = {
      'latest': 'created_at',
      'popular': 'play_count',
      'most_liked': 'like_count'
    }
    const sortColumn = sortColumnMap[sortBy || 'latest'] || 'created_at'
    
    query = query
      .order(sortColumn, { ascending: sortOrder === 'asc' })
      .range(offset, offset + limit - 1)
    
    const { data: works, error } = await query
    
    if (error) throw error
    
    return Response.json({ works: works || [] })
  } catch (error) {
    console.error('获取作品列表失败:', error)
    return Response.json({ error: '获取作品列表失败' }, { status: 500 })
  }
}

// 创建作品
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { 
      userId, 
      title, 
      content, 
      genre, 
      tags, 
      status,
      operations 
    } = body
    
    if (!userId || !title) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    // 计算字数
    const wordCount = content ? content.replace(/\s/g, '').length : 0
    
    // 创建作品
    const { data: work, error } = await supabase
      .from('works')
      .insert({
        user_id: userId,
        title,
        content: content || '',
        genre: genre || 'essay',
        tags: tags || [],
        status: status || 'draft',
        word_count: wordCount,
        operations: operations || []
      })
      .select()
      .single()
    
    if (error) throw error
    
    return Response.json({ work, success: true })
  } catch (error) {
    console.error('创建作品失败:', error)
    return Response.json({ error: '创建作品失败' }, { status: 500 })
  }
}
