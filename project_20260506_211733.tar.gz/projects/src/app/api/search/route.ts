import { createClient } from '@/storage/database/supabase-server'

// 搜索作品
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')
    const genre = searchParams.get('genre')
    const sortBy = searchParams.get('sortBy') || 'created_at'
    const sortOrder = searchParams.get('sortOrder') || 'desc'
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')
    
    if (!query) {
      return Response.json({ error: '缺少搜索关键词' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    let dbQuery = supabase
      .from('works')
      .select(`
        *,
        profiles (
          id,
          username,
          avatar_key
        )
      `)
      .eq('status', 'published')
      .or(`title.ilike.%${query}%,content.ilike.%${query}%`)
    
    if (genre) {
      dbQuery = dbQuery.eq('genre', genre)
    }
    
    dbQuery = dbQuery
      .order(sortBy, { ascending: sortOrder === 'asc' })
      .range(offset, offset + limit - 1)
    
    const { data: works, error } = await dbQuery
    
    if (error) throw error
    
    // 获取总数
    let countQuery = supabase
      .from('works')
      .select('id', { count: 'exact', head: true })
      .eq('status', 'published')
      .or(`title.ilike.%${query}%,content.ilike.%${query}%`)
    
    if (genre) {
      countQuery = countQuery.eq('genre', genre)
    }
    
    const { count } = await countQuery
    
    return Response.json({ 
      works: works || [], 
      total: count || 0,
      query 
    })
  } catch (error) {
    console.error('搜索失败:', error)
    return Response.json({ error: '搜索失败' }, { status: 500 })
  }
}
