import { createClient } from '@/storage/database/supabase-server'

// 获取用户设置
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return Response.json({ error: '缺少用户ID' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    const { data: settings, error } = await supabase
      .from('reading_settings')
      .select('*')
      .eq('user_id', userId)
      .single()
    
    if (error && error.code !== 'PGRST116') {
      throw error
    }
    
    // 返回默认设置
    return Response.json({ 
      settings: settings || {
        fontFamily: 'Noto Serif SC',
        fontSize: 18,
        lineHeight: 1.8,
        backgroundColor: '#F5F1E8'
      }
    })
  } catch (error) {
    console.error('获取设置失败:', error)
    return Response.json({ error: '获取设置失败' }, { status: 500 })
  }
}

// 更新用户设置
export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { userId, fontFamily, fontSize, lineHeight, backgroundColor } = body
    
    if (!userId) {
      return Response.json({ error: '缺少用户ID' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    const updateData: Record<string, unknown> = {
      font_family: fontFamily,
      font_size: fontSize,
      line_height: lineHeight,
      background_color: backgroundColor,
      updated_at: new Date().toISOString()
    }
    
    // 检查是否已有设置
    const { data: existing } = await supabase
      .from('reading_settings')
      .select('id')
      .eq('user_id', userId)
      .single()
    
    let result
    if (existing) {
      // 更新
      const { data, error } = await supabase
        .from('reading_settings')
        .update(updateData)
        .eq('user_id', userId)
        .select()
        .single()
      
      if (error) throw error
      result = data
    } else {
      // 创建
      const { data, error } = await supabase
        .from('reading_settings')
        .insert({
          user_id: userId,
          ...updateData
        })
        .select()
        .single()
      
      if (error) throw error
      result = data
    }
    
    return Response.json({ settings: result, success: true })
  } catch (error) {
    console.error('更新设置失败:', error)
    return Response.json({ error: '更新设置失败' }, { status: 500 })
  }
}
