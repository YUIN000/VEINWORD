import { createClient } from '@/storage/database/supabase-server'

// 获取收藏列表
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    
    if (!userId) {
      return Response.json({ error: '缺少用户ID' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    const { data: favorites, error } = await supabase
      .from('favorites')
      .select(`
        *,
        works (
          id,
          title,
          content,
          genre,
          excerpt,
          word_count,
          play_count,
          like_count,
          created_at,
          updated_at,
          user_id,
          profiles (
            username,
            avatar_key
          )
        )
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
    
    if (error) throw error
    
    return Response.json({ favorites })
  } catch (error) {
    console.error('获取收藏列表失败:', error)
    return Response.json({ error: '获取收藏列表失败' }, { status: 500 })
  }
}

// 添加收藏
export async function POST(request: Request) {
  try {
    const { userId, workId } = await request.json()
    
    if (!userId || !workId) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    // 检查是否已经收藏
    const { data: existing } = await supabase
      .from('favorites')
      .select('id')
      .eq('user_id', userId)
      .eq('work_id', workId)
      .single()
    
    if (existing) {
      return Response.json({ error: '已经收藏过了', alreadyFavorited: true })
    }
    
    const { data, error } = await supabase
      .from('favorites')
      .insert({ user_id: userId, work_id: workId })
      .select()
      .single()
    
    if (error) throw error
    
    return Response.json({ favorite: data, success: true })
  } catch (error) {
    console.error('添加收藏失败:', error)
    return Response.json({ error: '添加收藏失败' }, { status: 500 })
  }
}

// 取消收藏
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const workId = searchParams.get('workId')
    
    if (!userId || !workId) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    const { error } = await supabase
      .from('favorites')
      .delete()
      .eq('user_id', userId)
      .eq('work_id', workId)
    
    if (error) throw error
    
    return Response.json({ success: true })
  } catch (error) {
    console.error('取消收藏失败:', error)
    return Response.json({ error: '取消收藏失败' }, { status: 500 })
  }
}
