import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/storage/database/supabase-client'

export async function POST(request: NextRequest) {
  try {
    const { username, email, password } = await request.json()

    if (!email || !password || !username) {
      return NextResponse.json(
        { error: '请提供用户名、邮箱和密码' },
        { status: 400 }
      )
    }

    if (username.length < 2 || username.length > 20) {
      return NextResponse.json(
        { error: '用户名长度应在2-20个字符之间' },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: '密码长度至少为6位' },
        { status: 400 }
      )
    }

    const supabase = createClient()

    // 检查用户名是否已被使用
    const { data: existingUser, error: checkError } = await supabase
      .from('profiles')
      .select('id')
      .eq('username', username)
      .single()

    if (existingUser) {
      return NextResponse.json(
        { error: '用户名已被使用，请选择其他用户名' },
        { status: 409 }
      )
    }

    // 注册用户
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
        },
      },
    })

    if (authError) {
      return NextResponse.json(
        { error: authError.message },
        { status: 400 }
      )
    }

    if (!authData.user) {
      return NextResponse.json(
        { error: '注册失败，请稍后重试' },
        { status: 500 }
      )
    }

    // 创建用户profile
    const { error: profileError } = await supabase
      .from('profiles')
      .insert({
        id: authData.user.id,
        username,
        bio: '',
      })

    if (profileError) {
      console.error('创建profile失败:', profileError)
    }

    return NextResponse.json({
      success: true,
      message: '注册成功！请登录',
      user: {
        id: authData.user.id,
        email: authData.user.email,
        username,
      },
    })
  } catch (error) {
    console.error('注册错误:', error)
    return NextResponse.json(
      { error: '注册失败，请稍后重试' },
      { status: 500 }
    )
  }
}
