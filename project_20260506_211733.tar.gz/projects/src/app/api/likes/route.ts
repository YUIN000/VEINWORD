import { createClient } from '@/storage/database/supabase-server'

// 点赞/取消点赞
export async function POST(request: Request) {
  try {
    const { userId, workId, action } = await request.json()
    
    if (!userId || !workId || !action) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    if (action === 'like') {
      // 添加点赞
      const { data: existing } = await supabase
        .from('likes')
        .select('id')
        .eq('user_id', userId)
        .eq('work_id', workId)
        .single()
      
      if (existing) {
        return Response.json({ alreadyLiked: true })
      }
      
      const { data, error } = await supabase
        .from('likes')
        .insert({ user_id: userId, work_id: workId })
        .select()
        .single()
      
      if (error) throw error
      
      // 更新作品的点赞数
      await supabase.rpc('increment_likes', { work_id: workId })
      
      return Response.json({ like: data, success: true, liked: true })
    } else if (action === 'unlike') {
      // 取消点赞
      await supabase
        .from('likes')
        .delete()
        .eq('user_id', userId)
        .eq('work_id', workId)
      
      // 更新作品的点赞数
      await supabase.rpc('decrement_likes', { work_id: workId })
      
      return Response.json({ success: true, liked: false })
    }
    
    return Response.json({ error: '无效的操作' }, { status: 400 })
  } catch (error) {
    console.error('点赞操作失败:', error)
    return Response.json({ error: '点赞操作失败' }, { status: 500 })
  }
}

// 获取点赞状态
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const workId = searchParams.get('workId')
    
    if (!userId || !workId) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 })
    }
    
    const supabase = createClient()
    
    const { data } = await supabase
      .from('likes')
      .select('id')
      .eq('user_id', userId)
      .eq('work_id', workId)
      .single()
    
    return Response.json({ liked: !!data })
  } catch (error) {
    console.error('获取点赞状态失败:', error)
    return Response.json({ error: '获取点赞状态失败' }, { status: 500 })
  }
}
