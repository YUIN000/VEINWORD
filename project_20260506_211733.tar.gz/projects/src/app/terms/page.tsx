'use client'

import Link from 'next/link'
import { ArrowLeft, Feather } from 'lucide-react'

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Link 
            href="/" 
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>返回首页</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="flex items-center gap-3 mb-8">
          <Feather className="h-8 w-8 text-accent" />
          <h1 className="text-3xl font-serif font-bold">服务条款</h1>
        </div>

        <div className="prose prose-stone dark:prose-invert max-w-none space-y-6 font-serif">
          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">引言</h2>
            <p className="text-muted-foreground leading-relaxed">
              欢迎使用 VEINWORD！在使用我们的服务之前，请仔细阅读本服务条款（以下称「本条款」）。您访问或使用 VEINWORD 的任何服务，即表示您同意接受本条款的约束。如果您不同意本条款的任何内容，请停止使用我们的服务。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">一、服务说明</h2>
            <p className="text-muted-foreground leading-relaxed">
              VEINWORD 是一个中文创意写作与阅读平台，提供以下服务：
            </p>
            <ul className="space-y-2 mt-4 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>作品发布与展示</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>创作回放录制</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>作品阅读与互动</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>作者关注与收藏</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✦</span>
                <span>评论与交流</span>
              </li>
            </ul>
            <p className="text-muted-foreground leading-relaxed mt-4">
              我们保留随时修改、暂停或终止服务的权利，并将尽可能提前通知用户。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">二、用户注册</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>您需要注册账号才能使用部分功能。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>您应提供真实、准确的个人信息，并及时更新。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>您有责任妥善保管账号信息，因个人疏忽导致的损失由您自行承担。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>您同意对账号下所有活动负责，包括但不限于发布内容、评论等。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">三、用户内容</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span><strong className="text-foreground">所有权</strong>：您保留对您在 VEINWORD 上发布内容的所有权。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span><strong className="text-foreground">授权</strong>：您发布内容即表示授予 VEINWORD 在全球范围内、非独占、免费的使用权，用于展示和推广平台。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span><strong className="text-foreground">保证</strong>：您保证拥有所发布内容的完整权利，不侵犯他人知识产权。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span><strong className="text-foreground">删除</strong>：您可以随时删除您的内容，删除后相关内容将从平台移除。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">四、使用限制</h2>
            <p className="text-muted-foreground mb-4">您在使用 VEINWORD 时不得：</p>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">✗</span>
                <span>发布违反法律法规、公序良俗的内容</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✗</span>
                <span>侵犯他人知识产权、隐私权或其他合法权益</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✗</span>
                <span>进行任何商业广告、推销或垃圾信息传播</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✗</span>
                <span>试图破解、入侵或破坏平台系统</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">✗</span>
                <span>使用自动化工具批量操作或爬取数据</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">五、知识产权</h2>
            <p className="text-muted-foreground leading-relaxed">
              VEINWORD 的名称、标识、界面设计、程序代码等均受知识产权保护，未经授权不得使用。用户原创作品版权归用户所有，但用户在平台发布即表示同意授予平台必要的展示权利。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">六、服务变更与终止</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>我们有权根据业务发展调整服务内容或功能。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>如用户严重违反本条款，我们有权暂停或终止其账号。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>用户可随时注销账号，注销后我们将删除相关个人信息。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>如因不可抗力导致服务无法继续，我们不承担责任，但会尽力减少用户损失。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">七、免责声明</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent">1.</span>
                <span>用户发布的内容不代表 VEINWORD 的观点或立场。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">2.</span>
                <span>我们对用户之间的交流互动不承担责任。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">3.</span>
                <span>因用户自身原因导致的损失，由用户自行承担。</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent">4.</span>
                <span>我们不对服务做任何明示或暗示的保证，包括但不限于适销性、特定用途适用性等。</span>
              </li>
            </ul>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">八、争议解决</h2>
            <p className="text-muted-foreground leading-relaxed">
              本条款的解释和执行均适用中华人民共和国法律。如因本条款产生争议，双方应友好协商解决；协商不成的，任何一方可向被告住所地人民法院提起诉讼。
            </p>
          </section>

          <section className="bg-card rounded-lg p-6 border border-border/50">
            <h2 className="text-xl font-semibold mb-4 text-foreground">九、联系我们</h2>
            <p className="text-muted-foreground leading-relaxed">
              如您对本条款有任何疑问或建议，请通过以下方式联系我们：
            </p>
            <div className="mt-4 text-muted-foreground">
              <p>邮箱：doubley999@qq.com</p>
            </div>
          </section>

          <section className="text-center py-8">
            <p className="text-sm text-muted-foreground/70">
              本服务条款最后更新于 2026 年 1 月
            </p>
          </section>
        </div>
      </main>
    </div>
  )
}
