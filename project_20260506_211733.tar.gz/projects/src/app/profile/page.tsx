import { ProfileContent } from '@/components/home'

export default function ProfilePage() {
  return <ProfileContent />
}
