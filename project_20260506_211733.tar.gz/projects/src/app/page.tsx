import { HeroSection, FeaturedWorks, FeaturesSection } from '@/components/home'

export default function HomePage() {
  return (
    <div className="flex flex-col pt-16">
      <HeroSection />
      <div className="container mx-auto px-4 py-12 space-y-16">
        <FeaturedWorks />
        <FeaturesSection />
      </div>
    </div>
  )
}
