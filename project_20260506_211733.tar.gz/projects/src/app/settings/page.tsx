import SettingsContent from '@/components/settings/settings-content'

export default function SettingsPage() {
  return <div className="pt-16"><SettingsContent /></div>
}
