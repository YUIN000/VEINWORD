# 文痕 (WenHen) - 项目规范文档

## 项目概述

**项目名称**：文痕
**项目介绍**：文字落下的痕迹
**项目类型**：复古高级风格写作阅读平台

## 核心功能

### 1. 写作编辑器
- **回放录制**：自动记录写作过程，支持回放功能（类似画世界）
- **防粘贴**：禁止大篇幅粘贴复制，仅允许10字及以内
- **旁注模式**：记录创作过程中的碎碎念、灵感笔记
- **题材适配**：不同题材（诗歌、随笔、短故事、小说、书信、剧本、日记）有不同功能

### 2. 阅读器
- **字体调节**：支持多种字体选择
- **行距调节**：自定义行间距
- **背景色调节**：多种阅读背景主题
- **阅读体验**：参考番茄小说、晋江文学城

### 3. 个人主页
- **作品展示**：个人作品库
- **创作统计**：写作时长、作品数量等
- **回放收藏**：收藏喜欢的写作回放

### 4. 作品库
- **分类筛选**：按题材、标签、时间筛选
- **搜索功能**：标题、内容搜索
- **排序功能**：按时间、热度排序

## 技术栈

- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI 组件**: shadcn/ui (基于 Radix UI)
- **Styling**: Tailwind CSS 4
- **数据库**: Supabase (PostgreSQL)
- **对象存储**: S3 Compatible Storage

## 数据库模型

### 用户表 (users)
- id: UUID (主键)
- username: string (用户名)
- email: string (邮箱)
- avatar_key: string (头像存储key)
- bio: text (个人简介)
- created_at: timestamp
- updated_at: timestamp

### 作品表 (works)
- id: UUID (主键)
- user_id: UUID (外键 -> users)
- title: string (作品标题)
- content: text (作品内容)
- genre: enum (诗歌/随笔/短故事/小说/书信/剧本/日记)
- tags: string[] (标签)
- status: enum (草稿/已发布/私密)
- is_ai_free: boolean (声明原创)
- word_count: integer (字数)
- play_count: integer (阅读数)
- created_at: timestamp
- updated_at: timestamp

### 回放记录表 (writing_plays)
- id: UUID (主键)
- work_id: UUID (外键 -> works)
- user_id: UUID (外键 -> users)
- play_data: jsonb (回放数据序列)
- duration: integer (回放时长/秒)
- created_at: timestamp

### 旁注表 (marginal_notes)
- id: UUID (主键)
- work_id: UUID (外键 -> works)
- content: text (旁注内容)
- timestamp: integer (创作时间点/毫秒)
- created_at: timestamp

### 阅读设置表 (reading_settings)
- id: UUID (主键)
- user_id: UUID (外键 -> users)
- font_family: string (字体)
- font_size: integer (字号)
- line_height: float (行距)
- background_color: string (背景色)
- updated_at: timestamp

## 目录结构

```
src/
├── app/
│   ├── (auth)/              # 认证相关页面
│   │   ├── login/
│   │   └── register/
│   ├── (main)/               # 主要功能页面
│   │   ├── home/             # 首页
│   │   ├── write/            # 写作页面
│   │   ├── read/[id]/        # 阅读页面
│   │   ├── library/          # 作品库
│   │   └── profile/          # 个人主页
│   ├── api/                  # API路由
│   │   ├── auth/
│   │   ├── works/
│   │   └── plays/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── ui/                   # shadcn/ui组件
│   ├── editor/               # 编辑器组件
│   ├── reader/               # 阅读器组件
│   ├── layout/               # 布局组件
│   └── home/                 # 首页组件
├── hooks/                    # 自定义hooks
├── lib/                      # 工具库
│   ├── supabase.ts
│   └── utils.ts
└── server.ts
```

## 风格设计

### 复古高级风格
- **色彩**：以深墨色、宣纸白、古典金为主色调
- **字体**：使用衬线字体（如 Noto Serif SC）作为正文
- **装饰**：简约的边框装饰，墨迹效果
- **交互**：优雅的过渡动画

### 阅读器主题
1. **宣纸白**：背景 #F5F1E8，文字 #2C2416
2. **月夜深蓝**：背景 #1A1D29，文字 #E8E4D9
3. **墨染黑**：背景 #0D0D0D，文字 #D4C5A9
4. **素雅灰**：背景 #F0EDE8，文字 #333333

## 验证清单

### 代码静态检查
- [x] ESLint 检查
- [x] TypeScript 类型检查

### 功能测试
- [x] 用户注册/登录
- [x] 作品创建/编辑/删除
- [x] 回放录制/回放
- [x] 旁注添加/编辑
- [x] 阅读器设置
- [x] 作品筛选

### 安全检查
- [x] 粘贴字数限制
- [x] 用户权限验证
- [x] SQL注入防护
- [x] XSS防护
